package com.base.common.constant

object AppConstant {
    const val SUPPORT_NUMBER = "0914607788"
    const val MAX_COUNT_DOWN = 60

    const val HEADER_ACCEPT = "Accept"
    const val HEADER_AUTHORIZATION = "Access-Token"
    const val HEADER_USER_AGENT = "User-Agent"
    const val HEADER_ACCEPT_LANGUAGE = "Accept-Language"
    const val HEADER_CONTENT_TYPE = "Content-type"

    //------
    // Header Values
    //------
    const val HEADER_ACCEPT_VALUE = "application/json"
    const val HEADER_AUTHORIZATION_VALUE = "Bearer %s"

    // ERROR
    const val EMPTY_USERNAME = "Họ và tên trống hoặc không đúng định dạng. Xin vui lòng nhập lại chuỗi 1~16 ký tự."
    const val WRONG_USERNAME = "Họ và tên trống hoặc không đúng định dạng. Xin vui lòng nhập lại chuỗi 1~16 ký tự."
    const val EMPTY_PHONE = "Yêu cầu nhập sdt."
    const val WRONG_PHONE = "Số điện thoại không chính xác. Xin vui lòng nhập lại."
    const val EMPTY_PASS = "Yêu cầu nhập mật khẩu."
    const val WRONG_PASS = "Định dạng mật khẩu không chính xác. Xin vui lòng nhập lại chuỗi 6~10 ký tự chữ và số."
    const val WRONG_NEW_PASS = "Định dạng mật khẩu mới không chính xác. Xin vui lòng nhập lại chuỗi 6~10 ký tự chữ và số."
    const val PASS_LIMIT = "Mật khẩu ít nhất 6 kí tự."
    const val EMPTY_ROLE = "Yêu cầu nhập role."
    const val PASS_MATCH = "Mật khẩu xác nhận không chính xác. Xin vui lòng nhập lại."
    const val PASS_N_MATCH = "Mật khẩu mới xác nhận không chính xác. "
    const val EMPTY_REF = "Mã quản lý không chính xác. Xin vui lòng nhập lại."
    const val EMPTY_TERM = "Yêu cầu đồng ý Điều khoản và Điều kiện."
    const val EMPTY_AVATAR= "Xin vui lòng chọn ảnh đại diện."
    const val SESSION_TIMEOUT = "401"
    const val INTERNAL_ERROR = "500"
    const val TOKEN_EXPIRED = "440"
    const val UPDATE_APP = "426"
    const val CALL_ERROR = "422"
    const val UPDATE_APP_TAG = "UPDATE"
    const val CODE_N_MATCH = "Mã quản lý không chính xác.\nXin vui lòng nhập lại."
    const val RECODE_N_MATCH = "Mã quản lý mới xác nhận không chính xác.\nXin vui lòng nhập lại."
    const val NEWCODE_EMPTY = "Xin vui lòng nhập mã quản lý mới."
    const val NEWCODE_INVALID = "Mã quản lý mới không hợp lệ.\nXin vui lòng nhập mã quản lý mới."
    const val RECEIVER_INVALID = "Định dạng mã số không chính xác. \n Xin vui lòng nhập lại."


    enum class Role(val roleName: String) {
        Manager("Quản lý Sự kiện"),
        Owner("Quản lý Ca sĩ"),
        Staff("Ca sĩ");

        companion object {
            fun from(s: String?): Role? {
                if (s == null) return Staff
                return values().find { it.name == s }
            }
        }
    }

    enum class BarActionType {
        Add,
        Edit,
        View
    }

    enum class DialogState {
        Close,
        Call,
        Back
    }

    enum class Activity {
        Offline,
        Online,
        Selecting,
        Moving,
        Ondesk
    }

    enum class Status(val status: String, val des: String) {
        New("Cuộc gọi đến", "Bạn nhận được cuộc gọi mới. Xin vui lòng chọn Từ chối hoặc Đông ý trong vòng 2 phút"),
        Approve("Nhận cuộc gọi", "Bạn đã đồng ý cuộc gọi này. Xin vui lòng di chuyển tới cơ sở trong vòng 20 phút"),
        Cancel("Từ chối cuộc gọi", "Bạn đã từ chối cuộc gọi"),
        Rejected("Bị từ chối", "Cuộc gọi này đã kết thúc. Bạn đã bị từ chối"),
        Processing("Đang hát", "Bạn đã được chọn. Xin vui lòng chọn Kết thúc khi hoàn thành bài hát"),
        Missed("Nhỡ", "Cuộc gọi đã kết thúc. Bạn đã không trả lời trong vòng 2 phút"),
        Complete("Kết thúc", "Bạn đã hoàn thành cuộc gọi này. Xin cảm ơn");

        companion object {
            fun from(s: String?): Status? {
                if (s == null) return New
                return values().find { it.name == s }
            }
        }

    }
}