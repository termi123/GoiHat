package com.base.common.base.viewmodel

import androidx.lifecycle.*
import com.base.common.data.event.Event
import com.base.common.data.result.ApiResult
import com.base.common.data.result.ErrorApi
import com.base.common.utils.rx.bus.RxBus

abstract class BaseViewModel : ObservableViewModel() {
    val loadingStatus: MutableLiveData<Boolean> = MutableLiveData()
    val errorResponse: MutableLiveData<ErrorApi?> = MutableLiveData()
    var eventNavigator = MutableLiveData<Event<Int>>()
    lateinit var lifecycleOwner: LifecycleOwner

    fun <T> handleCommonApi(result: ApiResult<T>?, needCheckToken: Boolean = true): T? {
        result?.let {
            loadingStatus.value = result.isLoading
            if (result.isSuccess) {
                return result.getOrNull()
            }
            if (result.isFailure) {
                errorResponse.value = result.errorApiOrNull(needCheckToken)
            }
        }
        return null
    }

    fun registerToListenToEvent(lifecycleOwner: LifecycleOwner, observer: Observer<Event<Int>>) {
        this.lifecycleOwner = lifecycleOwner
        eventNavigator.observe(lifecycleOwner, observer)
        observerData()
    }

    open fun observerData() {

    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    fun removeObserver() {
        if (::lifecycleOwner.isInitialized) {
            eventNavigator.removeObservers(lifecycleOwner)
        }
    }

    fun sendEvent(event: Int) = eventNavigator.postValue(Event(event))

    fun  publishRxEvent(classEvent : Any) = RxBus.publish(classEvent)
}