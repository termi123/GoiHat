package com.base.common.base.fragment

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.annotation.LayoutRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.databinding.DataBindingUtil
import androidx.databinding.Observable
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.base.common.BR
import com.base.common.base.activity.BaseMVVMActivity
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import io.reactivex.disposables.CompositeDisposable
import timber.log.Timber


abstract class BaseMVVMFragment<T : ViewDataBinding, V : BaseViewModel> : Fragment() {

    protected var mRootView: View? = null
    protected var viewDataBinding: T? = null
    protected var isNeedLoading = true
    /**
     * @return layout resource id
     */
    @get:LayoutRes
    abstract val layoutId: Int

    abstract val viewModel: V

//    /**
//     * Override for set view model type
//     *
//     * @return view model type for get instance
//     */
//    abstract val viewModelType: Class<V>

    /**
     * @return layout binding variable
     */
    private val bindingVariable = BR.viewModel
    private var compositeDisposable = CompositeDisposable()

    override fun onCreate(@Nullable savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    open fun onReceiverMessage(sender: Observable?, propertyId: Int){}

    override fun onCreateView(
        @NonNull inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        adjustFontScale(resources.configuration)
        viewDataBinding = DataBindingUtil.inflate(inflater, layoutId, container, false)
        mRootView = viewDataBinding!!.root
        return mRootView
    }

    open fun adjustFontScale(configuration: Configuration) {
        configuration.fontScale = 1.0.toFloat()
        val metrics = resources.displayMetrics
        val wm =
            activity?.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getMetrics(metrics)
        metrics.scaledDensity = configuration.fontScale * metrics.density
        activity?.resources?.updateConfiguration(configuration, metrics)
    }

    override fun onViewCreated(@NonNull view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewDataBinding!!.executePendingBindings()
        observerData()
        initDispose()
        viewDataBinding!!.lifecycleOwner = this
        viewDataBinding!!.setVariable(bindingVariable, viewModel)
    }

    private fun initDispose() {
        compositeDisposable.add(RxBus.listen(RxEvent.EventCloseDialog::class.java).subscribe{
            handleEventCloseDialog(it)
        })

        compositeDisposable.add(RxBus.listen(RxEvent.EventDialog::class.java).subscribe{
            handleEventDialog(it)
        })
    }

    open fun <T> addDisposable(classType : Class<T>, handler : (T) -> Unit){
        compositeDisposable.add(RxBus.listen(classType).subscribe({
            
            handler(it)
        },{
            Timber.e(it)
        }))
    }

    open fun handleEventCloseDialog(event : RxEvent.EventCloseDialog){}

    open fun handleEventDialog(event : RxEvent.EventDialog?) {}


    open fun observerData() {
        viewModel.registerToListenToEvent(viewLifecycleOwner, Observer { event ->
            run {
                event?.contentIfNotHandled?.let {
                    onReceiverMessage(viewModel, it)
                    event.isHasBeenHandled = true
                }
            }
        })
        viewModel.loadingStatus.observe(viewLifecycleOwner, Observer { loading ->
            run {
                loadingHandler()
                if (loading == null || activity == null || !isNeedLoading) return@run
                if (activity is BaseMVVMActivity<*, *>) {
                    if (loading) {
                        (activity as BaseMVVMActivity<*, *>).showDialogLoading()
                    } else {
                        if ((activity as BaseMVVMActivity<*, *>).loadingDialog.isShowing)
                            (activity as BaseMVVMActivity<*, *>).loadingDialog.dismiss()
                    }
                }
            }
        })

        viewModel.errorResponse.observe(this, Observer {
            it?.let { errorApi ->
                if (activity is BaseMVVMActivity<*, *>) {
                    when (errorApi.errorCode) {
                        AppConstant.SESSION_TIMEOUT -> (activity as BaseMVVMActivity<*, *>).onSessionTimeOut(errorApi.message)
                        else ->  (activity as BaseMVVMActivity<*, *>).showDialogMessage(MessageDialog("Thông báo", errorApi.message, tag = errorApi.errorCode))
                    }
                }
            }
        })
    }

    open fun loadingHandler() {

    }

    open fun showDialogMessage(message: MessageDialog) {}


    open fun onSessionTimeOut(message: String) {

    }

}