package com.base.common.utils.rx.bus

import com.base.common.constant.AppConstant

class RxEvent {

    data class EventCloseDialog(val dialogState: AppConstant.DialogState, val tag : String?)

    data class EventDialog(val tag : String?,val data : Any)

    data class EventMultipleDialog(val tag : String?,val data : Any,val data2 : Any)

    class EventReloadDetail()

    class EventNegativeClick(val tag : String?)

    class GetStaffRecentActivity()

    data class EventReload(var orderId: String, var isNew: Boolean)

    data class BarEvent(var type : AppConstant.BarActionType = AppConstant.BarActionType.Add, var id : String = "")

    class UpdateProfileEvent()

    class GetProfileEvent()

    data class ShowOrderDetail(var id: String)

    data class SelectFee(var fee: String)

    class CallFinish()

    class ShowSingerList()

}