package com.base.common.data.result

import android.text.TextUtils
import com.google.gson.JsonObject
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ErrorApi(
    @Expose
    @SerializedName("message")
    var message: String,
    @Expose
    @SerializedName("error_code")
    var errorCode: String,
    @Expose
    @SerializedName("datas")
    var datas: JsonObject? = null
) {

    fun mapErrorCode(): String {
        if (TextUtils.isEmpty(errorCode)) return ""
        message = convertErrorCode(errorCode)
        return message
    }
}

data class ErrorApi2(
    @Expose
    @SerializedName("message")
    var message: String,
    @Expose
    @SerializedName("error_code")
    var errorCode: String
) {

    fun mapErrorCode() {
        if (TextUtils.isEmpty(errorCode)) return
        message = convertErrorCode(errorCode)
    }
}

fun convertErrorCode(errorCode: String) = when (errorCode) {
    "EMPTY_USERNAME" -> "Yêu cầu nhập username."

    //Authenticate
    "E0101" -> "Yêu cầu nhập username."
    "E0102" -> "Yêu cầu nhập mật khẩu."
    "E0103" -> "Mật khẩu ít nhất 6 kí tự."
    "E0110" -> "Tài khoản hoặc mật khẩu không đúng."
    "E0111" -> "Tài khoản chưa được kích hoạt, vui lòng liên hệ hệ thống."
    "E0121" -> "Yêu cầu nhập device uuid."
    "E0122" -> "Yêu cầu nhập device type."
    "E0123" -> "Device type chỉ có thể là ios hoặc android."
    "E0124" -> "Yêu cầu nhập firebase token."

    //UserManagement
    "E0201" -> "Yêu cầu nhập họ tên"
    "E0202" -> "Yêu cầu nhập số diện thoại"
    "E0203" -> "Số điện thoại đã được đăng ký."
    "E0204" -> "Yêu cầu nhập mật khẩu."
    "E0205" -> "Tài khoản đã tồn tại."
    "E0206" -> "Yêu cầu nhập mã giới thiệu khi tài khoản là Staff."
    "E0207" -> "Yêu cầu nhập vĩ độ."
    "E0208" -> "Vĩ độ phải là ký tự số."
    "E0209" -> "Yêu cầu nhập kinh độ."
    "E0210" -> "Kinh độ phải là ký tự số."
    "E0211" -> "Yêu cầu nhập kinh độ."
    "E0212" -> "Kinh độ phải là ký tự số."
    "E0213" -> "Yêu cầu nhập mật khẩu mới."
    "E0214" -> "Mật khẩu không chính xác."
    "E0215" -> "Xác nhận mật khẩu không trùng khớp."
    "E0216" -> "Trong số ca sĩ gọi, có ca sĩ đã ở trong trạng thái được chọn. Vui lòng thao tác lại!"
    "E0217" -> "Yêu cầu đổi trạng thái không hợp lệ."
    "E0218" -> "Ca sĩ đã ở trạng thái online."
    "E0219" -> "Ca sĩ đang ở trạng thái được chọn. Vui lòng đợi khi ca sĩ trở về online."
    "E0220" -> "Bạn không có quyền thay đổi trạng thái cho người dùng này."
    "E0221" -> "Yêu cầu tải ảnh cá nhân."
    "E0222" -> "Mã giới thiệu không tồn tại trong hệ thống."
    "E0223" -> "Không tìm thấy mã người dùng trong hệ thống."
    "E0224" -> "Mã yêu cầu đổi phải là mã của quản lý ca sĩ."
    "E0225" -> "Không tìm thấy nhân viên."
    "E0226" -> "Số tiền nhập không đủ."
    "E0227" -> "Số tiền trong tài khoản không đủ để chuyển."
    "E0228" -> "Số tiền trong tài khoản không đủ để chuyển. Trong tài khoản phải có đủ cho tối thiểu 2 cuộc gọi."

    //BarManagement
    "E0301" -> "Yêu cầu nhập tên bar"
    "E0302" -> "Yêu cầu nhập người quản lý"
    "E0303" -> "Hình ảnh phải thuộc định dạng png,jpeg,jpg,gif"
    "E0304" -> "Không tìm thấy quán."
    "E0305" -> "Tên quán tại cơ sở đã tồn tại."
    "E0306" -> "Không tìm thấy phòng."

    //OrderManagement
    "E0401" -> "Yêu cầu nhập ID của bar"
    "E0402" -> "Yêu cầu nhập số lượng ca sĩ"
    "E0403" -> "Số lượng ca sĩ phải là một chữ số"
    "E0404" -> "Tài khoản bạn không đáp ứng chi phí tối thiểu để nhận cuộc gọi! Vui lòng liên hệ hệ thống để nạp tiền"
    "E0405" -> "Yêu cầu thay đổi trạng thái cuộc gọi không hợp lệ"
    "E0406" -> "Yêu cầu thực hiện survey cuộc gọi gần nhất."
    "E0407" -> "Yêu cầu nhập số ca sĩ cần."
    "E0408" -> "Số ca sĩ cần phải là một số."
    "E0409" -> "Yêu cầu thay đổi trạng thái cuộc gọi không hợp lệ."
    "E0410" -> "Ca sỹ không có trong cuộc gọi này."
    "E0411" -> "Không tìm thấy yêu cầu gọi này."
    "E0412" -> "Không tìm thấy ca sỹ theo yêu cầu gọi."

    //RoomManagement
    "E0501" -> "Yêu cầu nhập tên room"

    //BankAccountManagement
    "E0600" -> "Không có quyển thay đổi tài khoản ngân hàng người dùng này."
    "E0601" -> "Số tài khoản đã tồn tại."
    "E0602" -> "Yêu cầu nhập tên chủ tài khoản"
    "E0603" -> "Yêu cầu nhập số tài khoản"
    "E0604" -> "Yêu cầu nhập tên ngân hàng"
    "E0605" -> "Yêu cầu nhập tên chi nhánh ngân hàng"

    //OrderReport
    "E0700" -> "Yêu cầu nhập Y,N."
    "E0701" -> "Định dạng confirm không hợp lệ."
    "E0702" -> "Yêu cầu nhập report id"
    "E0703" -> "Định dạng report id không hợp lệ"
    "E0704" -> "Không tìm thấy report id"
    "E0705" -> "Báo cáo đã được xác nhận!"
    "E0706" -> "Vượt quá lần báo cáo cho phép!"

    //CallConfiguration
    "E0800" -> "Set giới hạn bar là on nhưng chưa đăng ký bar."
    "E0821" -> "Ảnh là bắt buộc phải nhập."
    "E0822" -> "Chỉ chấp nhận định dạng png,jpg,jpeg,gif."
    "E0823" -> "Tối đa 2048Kb."
    "E0824" -> "Bạn chỉ có thể up tối đa 5 ảnh."
    "E0825" -> "Xóa không thành công."

    else -> "no message"
}
