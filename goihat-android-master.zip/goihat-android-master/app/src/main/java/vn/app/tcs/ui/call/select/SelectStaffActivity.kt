package vn.app.tcs.ui.call.select

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import com.flyco.tablayout.listener.OnTabSelectListener
import kotlinx.android.synthetic.main.activity_select_staff.*
import org.jetbrains.anko.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.EVENT_CHANGE_STAFF_CALL
import vn.app.tcs.data.karaconstant.EventConstant.RELOAD_STAFF_CALL
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.ActivitySelectStaffBinding
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerActivity
import vn.app.tcs.ui.profile.slideshow.SlideShowActivity

class SelectStaffActivity :
    BaseKaraToolbarActivity<ActivitySelectStaffBinding, SelectStaffViewModel>(),
    OnTabSelectListener, BaseAdapter.OnClickItemListener<ListStaff.Staff> {

    val tagCallRandom = "tagCallRandom"
    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_select_staff

    override val viewModel: SelectStaffViewModel by viewModel()
    private val adapter: StaffAvailableAdapter by lazy {
        StaffAvailableAdapter(
            this,
            ArrayList()
        )
    }
    private val favoriteAdapter: StaffFavoriteAvailableAdapter by lazy {
        StaffFavoriteAvailableAdapter(
            this,
            ArrayList()
        )
    }
    var currentTab = 0
    val tabData = arrayOf("Gần đây", "Yêu thích")

    private fun getCurrentAdapter() = if (currentTab == 0) adapter else favoriteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tabStaff.setTabData(tabData)
        tabStaff.setOnTabSelectListener(this)
        getIntentData()
        initBarList()
        viewModel.getListStaff(1)
        swRefresh.setOnRefreshListener {
            if (currentTab == 0)
                viewModel.getListStaff(1, true)
            else viewModel.getListFavorite(1, true)
        }
        viewModel.tabIndex.value = currentTab
        adapter.setOnClickListener(this)
        favoriteAdapter.setOnClickListener(this)
    }

    override fun setUpObserver() {
        super.setUpObserver()
        viewModel.staffs.observe(this, Observer { listStaff ->
            run {
                listStaff?.let {
                    swRefresh.isRefreshing = false
                    getCurrentAdapter().setDataList(it.staff)
                }
            }
        })
        viewModel.favorite.observe(this, Observer { listStaff ->
            run {
                listStaff?.let {
                    swRefresh.isRefreshing = false
                    getCurrentAdapter().setDataList(it.staff)
                    rvStaffSelect.adapter = getCurrentAdapter()
                }
            }
        })
        viewModel.call.observe(this, Observer { call ->
            call?.let {
                run {
                    if (call.orderId != 0) {
                        startActivity<OrderDetailManagerActivity>(EventConstant.KEY_ORDER_DETAIL to call.orderId)
                        finish()
                    }
                }
            }
        })
        viewModel.favoriteRequest.observe(this, Observer {
            it?.let {
                adapter.list[viewModel.favoritePosition].setInvertFavorite()
                adapter.notifyDataSetChanged()
            }
        })

        addDisposable(RxEvent.EventNegativeClick::class.java) {
            if (it.tag == tagCallRandom) {
                handleCallStaff(false)
            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if (event.tag == tagCallRandom) {
            handleCallStaff(true)
        }
    }

    private fun initBarList() {
        rvStaffSelect.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rvStaffSelect.adapter = getCurrentAdapter()
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.unselectAll({})
    }

    private fun getIntentData() {
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    viewModel.maxCallPosition = ex.getInt(EventConstant.KEY_MAX_CALL, 0)
                    viewModel.barID = ex.getInt(EventConstant.KEY_BAR_ID, 0)
                    viewModel.fee = ex.getString(EventConstant.KEY_WANT_FEE, "0")
                }
            }
        }
    }

    fun showLimitCall() {
        showDialogMessage(MessageDialog(content = "Quá số lượng ca sĩ có thể chọn"))
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EVENT_CHANGE_STAFF_CALL -> {
                tvStaff.text = getString(
                    R.string.call_noti,
                    viewModel.selectedSet.size,
                    viewModel.maxCallPosition,
                    viewModel.maxCallPosition - viewModel.selectedSet.size
                )
            }
            RELOAD_STAFF_CALL -> {
                tvStaff.text = getString(
                    R.string.call_noti,
                    viewModel.selectedSet.size,
                    viewModel.maxCallPosition,
                    viewModel.maxCallPosition - viewModel.selectedSet.size
                )
                adapter.reset()
                favoriteAdapter.reset()
            }
            EventConstant.EVENT_CALL_STAFF -> {
                val ids = viewModel.selectedSet.toIntArray().toList()
                if (ids.size < viewModel.maxCallPosition) {
                    showDialogMessage(
                        MessageDialog(
                            content = "Bạn đã chọn ${ids.size}/${viewModel.maxCallPosition}. Bạn có đồng ý để hệ thống tự chọn ${viewModel.maxCallPosition - ids.size} Ca sĩ còn lại không",
                            cancelButton = "Chỉ chọn đã gọi",
                            showCancel = true,
                            tag = tagCallRandom
                        )
                    )
                    return
                }
                handleCallStaff(false)
            }
            EventConstant.EVENT_LIMIT_CALL -> {
                showLimitCall()
            }
            EventConstant.EVENT_UPDATE_STATUS -> {
                if (currentTab == 0) {
                    viewModel.staffs.value?.staff?.let {
                        getCurrentAdapter().setDataList(it)
                    }
                } else {
                    viewModel.favorite.value?.staff?.let {
                        getCurrentAdapter().setDataList(it)
                    }
                }

            }
            EventConstant.EVENT_UPDATE_FAVORITE -> {
                viewModel.favorite.value?.staff?.let {
                    restoreAdapter()
                }
            }
            EventConstant.EVENT_UPDATE_LIST_STAFF -> {
                viewModel.staffs.value?.staff?.let {
                    restoreAdapter()
                }
            }
            EventConstant.EVENT_SHOW_AVATAR_STAFF -> {
                viewModel.avartarStaffShow?.let {
                    startActivity<SlideShowActivity>(EventConstant.KEY_LIST_IMAGE to it.getAvatarGallery())
                }
            }
        }
    }

    private fun handleCallStaff(random: Boolean) {
        adapter.reset()
        favoriteAdapter.reset()
        viewModel.callStaff(viewModel.selectedSet.toIntArray().toList(), random)
    }

    private fun restoreAdapter() {
        swRefresh.isRefreshing = false
        rvStaffSelect.adapter = getCurrentAdapter()
    }

    override fun onTabSelect(position: Int) {
        currentTab = position
        viewModel.tabIndex.value = currentTab
        if (position == 0) viewModel.getListStaff(1)
        else viewModel.getListFavorite(1)
    }

    override fun onTabReselect(position: Int) {
    }

    override fun onClickItem(item: ListStaff.Staff, position: Int) {
        getCurrentAdapter().onSelectItem(item)
    }

}