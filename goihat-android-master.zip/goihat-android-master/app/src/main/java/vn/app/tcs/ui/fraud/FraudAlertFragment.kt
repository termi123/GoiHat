package vn.app.tcs.ui.fraud

import com.base.common.data.event.MessageDialog
import org.koin.android.ext.android.inject
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.model.NotifyItem
import vn.app.tcs.ui.notify.BaseNotifyFragment

class FraudAlertFragment : BaseNotifyFragment<FraudAlertViewModel>() {

    override val viewModel: FraudAlertViewModel by inject()

    override fun onClickRecycleViewItem(item: NotifyItem) {
        if (activity is BaseKaraActivity<*, *>) {
            (activity as BaseKaraActivity<*, *>).apply {
                showDialogMessage(MessageDialog("Thông báo",
                    if(item.dataItem.data!!.body.isBlank()) item.dataItem.notification!!.body else item.dataItem.data.body
                , confirmButton = "OK"))
            }
        }
    }

    companion object {
        val TAG = FraudAlertFragment::class.java.getName()
        fun newInstance(): FraudAlertFragment {
            return FraudAlertFragment()
        }
    }
}

