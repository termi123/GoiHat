package vn.app.tcs.ui.bank.list

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetBankUseCase
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.usermanager.UserManager

class BankListViewModel(private val getBankUseCase: GetBankUseCase) : BaseViewModel() {

    var banks = Transformations.map(getBankUseCase.result) {
        handleCommonApi(it)
    }

    private val getProfileUseCase: GetProfileUseCase by inject()

    var profileRequestData = Transformations.map(getProfileUseCase.result) {
        handleCommonApi(it)
    }
    var profile = MutableLiveData<UserProfile.Profile>()
    val userManager: UserManager by inject()

    fun doAddBank() = sendEvent(EventConstant.EVENT_ADD_BANK)

    fun getListBank() {
        getBankUseCase.execute()
    }

    fun getProfileFromApi() {
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
        }, {})
    }
}