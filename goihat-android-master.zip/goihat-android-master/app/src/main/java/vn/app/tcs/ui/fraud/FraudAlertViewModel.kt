package vn.app.tcs.ui.fraud

import vn.app.tcs.data.karaconstant.CategoryNotification
import vn.app.tcs.ui.notify.BaseNotifyViewModel

class FraudAlertViewModel : BaseNotifyViewModel() {
    override val categoryNoti : String? = CategoryNotification.warning.category
}
