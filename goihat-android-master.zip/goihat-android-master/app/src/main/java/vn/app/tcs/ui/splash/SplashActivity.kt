package vn.app.tcs.ui.splash

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.constant.AppConstant.UPDATE_APP_TAG
import com.base.common.utils.rx.bus.RxEvent
import org.jetbrains.anko.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.KaraApplication
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.ActivitySplashBinding
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffActivity
import vn.app.tcs.ui.home.manager.MainManagerActivity
import vn.app.tcs.ui.home.owner.MainOwnerActivity
import vn.app.tcs.ui.home.staff.MainStaffActivity
import vn.app.tcs.ui.login.LoginActivity
import vn.app.tcs.utils.sharepref.SharedPreUtils


class SplashActivity : BaseKaraActivity<ActivitySplashBinding, SplashViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_splash
    override val viewModel: SplashViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SharedPreUtils.putBoolean("APP_START", true)
        isNeedLoading = false
        viewModel.checkVersionRequest.observe(this, Observer {
            it?.let {
                KaraApplication.setBaseUrl(it.url)
                viewModel.checkAccessToken()
            }
        })
        viewModel.getStaffActivityRequest.observe(this, Observer {
            it?.let { response ->
                response.data?.let {
                    run {
                        startActivity<OrderDetailStaffActivity>(
                            EventConstant.KEY_ORDER_DETAIL to it.orderId,
                            EventConstant.KEY_FROM_SPLASH to true
                        )
                        return@Observer
                    }
                }
            }
            startActivity<MainStaffActivity>()
            finish()
        })
        viewModel.checkVersion()
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if (event.tag == UPDATE_APP_TAG) {
            openPlayStore()
        }
    }

    private fun openPlayStore() {
        val appPackageName = packageName
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$appPackageName")))
        } catch (anfe: android.content.ActivityNotFoundException) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=$appPackageName")
                )
            )
        }
        finish()
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_MAIN -> {
                when (viewModel.getRole()) {
                    AppConstant.Role.Manager.name -> startActivity<MainManagerActivity>()
                    AppConstant.Role.Owner.name -> startActivity<MainOwnerActivity>()
                    AppConstant.Role.Staff.name -> {
                        viewModel.getStaffActivity()
                        return
                    }
                }
            }
            EventConstant.EVENT_LOGIN -> startActivity<LoginActivity>()
        }
        finish()
    }
}
