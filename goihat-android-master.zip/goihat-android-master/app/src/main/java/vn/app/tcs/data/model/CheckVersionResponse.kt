package vn.app.tcs.data.model

import com.google.gson.annotations.SerializedName

data class CheckVersionResponse(
    @SerializedName("url")
    val url: String
)