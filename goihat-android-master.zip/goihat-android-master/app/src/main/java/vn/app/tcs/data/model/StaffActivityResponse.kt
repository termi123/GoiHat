package vn.app.tcs.data.model

import com.google.gson.annotations.SerializedName

data class StaffActivityResponse(
    @SerializedName("order")
    val data: OrderDetail?
)

data class OrderDetail(
    @SerializedName("order_id")
    val orderId: Int = 0
)