package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.ReportRepository

class SetReportReadUseCase: UseCase<List<String>>(){

    var idReport: Int = 0
    var typeReport: String = ""
    private val authenticateRepository: ReportRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return authenticateRepository.setReportRead(idReport, typeReport)
    }
}