package vn.app.tcs.ui.home.manager

import android.os.Bundle
import androidx.fragment.app.Fragment
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_main.*
import vn.app.tcs.R
import vn.app.tcs.ui.bank.list.BankListFragment
import vn.app.tcs.ui.favorite.StaffFavoriteFragment
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.managercallhistory.ManagerCallHistoryFragment
import vn.app.tcs.ui.managerhome.FragmentManagerHome
import vn.app.tcs.ui.notify.NotifyFragment

class MainManagerActivity : MainActivity() {

    private lateinit var callFinishDisposable: Disposable

    override fun getDefaultFragmentTag(): String {
        return ManagerCallHistoryFragment.TAG
    }

    override fun getNavigationMenu(): Int {
        return R.menu.drawer_manager_items
    }

    override fun getDefaultFragment(): Fragment {
        toolbarTitle.text = "Danh sách sự kiện"
        return ManagerCallHistoryFragment.newInstance()
    }

    override fun openDefaultFragment() {
        toolbarTitle.text = "Quản lý Sự kiện"
        showManagementFragment(FragmentManagerHome.newInstance(), FragmentManagerHome.TAG)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callFinishDisposable = RxBus.listen(RxEvent.CallFinish::class.java).subscribe {
            toolbarTitle.text = "Danh sách sự kiện"
            showManagementFragment(ManagerCallHistoryFragment.newInstance(), ManagerCallHistoryFragment.TAG)
        }
    }

    override fun setNavigationOnClick(menuItemId: Int) {
        when (menuItemId) {
            R.id.navPayment -> {
                toolbarTitle.text = "Quản lý Sự kiện"
                showManagementFragment(FragmentManagerHome.newInstance(), FragmentManagerHome.TAG)
            }
            R.id.navBank -> {
                toolbarTitle.text = "Tài khoản ngân hàng"
                showManagementFragment(BankListFragment.newInstance(), BankListFragment.TAG)
            }
            R.id.callHistory -> {
                toolbarTitle.text = "Danh sách sự kiện"
                showManagementFragment(ManagerCallHistoryFragment.newInstance(), ManagerCallHistoryFragment.TAG)
            }
            R.id.notifications -> {
                toolbarTitle.text = "Danh sách Thông báo"
                showManagementFragment(NotifyFragment.newInstance(), NotifyFragment.TAG)
            }
            R.id.favorites -> {
                toolbarTitle.text = "Danh sách yêu thích"
                showManagementFragment(StaffFavoriteFragment.newInstance(), StaffFavoriteFragment.TAG)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!callFinishDisposable.isDisposed) callFinishDisposable.dispose()
    }
}