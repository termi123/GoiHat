package vn.app.tcs.ui.dialog

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import com.base.common.base.dialog.BaseDialog
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.edit_dialog.tvContent
import kotlinx.android.synthetic.main.multi_edit_dialog.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.MultiEditDialogBinding

class MultipleEditDialog : BaseDialog<MultiEditDialogBinding, MultipleEditDialogViewModel>() {
    override val viewModel: MultipleEditDialogViewModel by inject()
    override val layoutId: Int
        get() = R.layout.multi_edit_dialog

    override fun updateUI(savedInstanceState: Bundle?) {

    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_MULTI_EDIT_DIALOG -> {
                dismiss()
                RxBus.publish(
                    RxEvent.EventMultipleDialog(
                        viewModel.content.value?.tag,
                        if (tvContent.text.isNullOrBlank()) "0" else tvContent.text,
                        if (tvContent2.text.isNullOrBlank()) "0" else tvContent2.text
                    )
                )
            }
        }
    }

    companion object {
        fun newInstance(messageDialog: MessageDialog) = MultipleEditDialog().apply {
            viewModel.content.value = messageDialog
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
}