package vn.app.tcs.data.model


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import vn.app.tcs.utils.TimeUtil

@Parcelize
data class ListRejectOrder(
    @SerializedName("lists")
    val lists: List<RejectOrder>?,
    @SerializedName("current_page")
    val currentPage: Int,
    @SerializedName("last_page")
    val lastPage: Int,
    @SerializedName("total")
    val total: Int,
    @SerializedName("per_page")
    val perPage: Int
) : Parcelable{
    @Parcelize
    data class RejectOrder(
        @SerializedName("id")
        val id: Int,
        @SerializedName("title")
        val title: String,
        @SerializedName("body")
        val body: String,
        @SerializedName("is_confirmed")
        val isConfirmed: String,
        @SerializedName("confirmed_at")
        val confirmedAt: String,
        @SerializedName("order")
        val order: Order,
        @SerializedName("read_at")
        var readAt: String = "",
        @SerializedName("staff")
        val staff: UserProfile.Profile,
        @SerializedName("created_at")
        val createdAt: Long?
    ) : Parcelable{
        fun getTime() = TimeUtil.milliSecondToDate(createdAt ?: 0, TimeUtil.DATE_FOMART_NOTI)
        @Parcelize
        data class Order(
            @SerializedName("id")
            val id: Int,
            @SerializedName("room")
            val room: Bar.Room,
            @SerializedName("description")
            val description: String,
            @SerializedName("bar")
            val bar: Bar
        ) : Parcelable

        fun getDes() = "Ca sĩ \"" + staff.name + "\"" + " (" + staff.code + ") " + "yêu cầu xử lý bị Out"
        fun getOrderInfo() = body + "\n" + getTime()
        fun getConfirm() = if(isConfirmed == "Y") "Bạn đã đồng ý yêu cầu xử lý này" else "Bạn đã từ chối yêu cầu xử lý này"
    }
}