package vn.app.tcs.ui.addbar.fee

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.recyclerview.widget.GridLayoutManager
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_add_bar.toolbar
import kotlinx.android.synthetic.main.activity_fee_list.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.databinding.ActivityFeeListBinding

class FeeActivity : BaseKaraToolbarActivity<ActivityFeeListBinding, FeeViewModel>(), FeeAdapter.OnClickItemListener {

    override fun getToolBar(): Toolbar = toolbar
    override val layoutId: Int
        get() = R.layout.activity_fee_list
    override val viewModel: FeeViewModel by viewModel()
    lateinit var adapter: FeeAdapter
    private var feeArray = arrayListOf(
        "50",
        "5%",
        "100",
        "10%",
        "150",
        "15%",
        "200",
        "20%",
        "250",
        "25%",
        "300",
        "30%",
        "350",
        "35%"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initList()
    }

    private fun initList() {
        rvFeeList.setHasFixedSize(true)
        val manager = GridLayoutManager(this, 2)
        rvFeeList.layoutManager = manager
        val header = LayoutInflater.from(this).inflate(
            R.layout.item_fee_list, rvFeeList, false
        )
        adapter = FeeAdapter(feeArray, header)
        rvFeeList.adapter = adapter
        adapter.setOnClickItemListener(this)
        manager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (adapter.isHeader(position)) manager.spanCount else 1
            }
        }
    }

    override fun onClick(item: String) {
        RxBus.publish(RxEvent.SelectFee(item))
        finish()
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {

    }
}