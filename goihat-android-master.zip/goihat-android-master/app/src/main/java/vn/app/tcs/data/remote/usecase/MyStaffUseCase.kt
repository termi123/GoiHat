package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.data.remote.UserManagerRepository

class MyStaffUseCase : UseCase<ListStaff>() {
    private val userManagerRepository: UserManagerRepository by inject()
    var pageNum : Int = 1
    override fun buildUseCaseObservable(): Single<ListStaff> {
        return userManagerRepository.getStaffs(pageNum)
    }
}