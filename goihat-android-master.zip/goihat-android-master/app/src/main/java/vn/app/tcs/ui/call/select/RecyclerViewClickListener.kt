package vn.app.tcs.ui.call.select

import android.view.View

interface RecyclerViewClickListener {
    fun onClick(view: View, position: Int)

    fun onLongClick(view: View, position: Int)
}