package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class TokenRequest(
    @SerializedName("device_uuid") var device_uuid: String,
    @SerializedName("type") var type: String,
    @SerializedName("fcm_token") var fcm_token: String
)