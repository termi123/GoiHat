package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.model.UserProfile

interface CallConfigSource {

    @POST("/api/user/call-config/setall")
    fun configSetAll(@Query("has_registered_bar") hasRegister: String): Single<List<String>>//off là nhận hết bar, on là giới hạn bar

    @GET("/api/user/call-config/get-bar")
    fun getListBar(): Single<ListBar>

    @POST("/api/user/call-config/register")
    fun registerBar(
        @Query("bar_ids[]") bar_ids: List<Int>
    ): Single<List<String>>

    @POST("/api/user/call-config/delete")
    fun deleteBar(
        @Query("bar_ids[]") bar_ids: List<Int>
    ): Single<List<String>>

    @GET("/api/bar/detail-by-name")
    fun getListBarByName(@Query("bar_name") barName: String): Single<ListBar>
}