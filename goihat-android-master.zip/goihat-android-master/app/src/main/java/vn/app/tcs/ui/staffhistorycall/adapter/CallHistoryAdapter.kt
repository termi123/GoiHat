package vn.app.tcs.ui.staffhistorycall.adapter

import android.os.CountDownTimer
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.DEFAULT_COUNT_DOWN_TIME
import vn.app.tcs.data.model.Order
import vn.app.tcs.databinding.ItemCallHistoryBinding

class CallHistoryAdapter(data: ArrayList<Order>) : BaseAdapter<Order>(data) {
    lateinit var onActionOrderListener: OnActionOrderListener
    lateinit var onFinishListener: OnFinish
    val endTimeArray = SparseArray<Long>()
    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return OrderViewHolder(parent?.inflateExt(R.layout.item_call_history)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is OrderViewHolder) {
            holder.apply {
                val createdAt = if(list[position].createdAt == null)  0L else (list[position].createdAt.toLong() + DEFAULT_COUNT_DOWN_TIME) * 1000 ;
                list[position].isCalling = list[position].status == "New" && (createdAt > System.currentTimeMillis())
                if (!list[position].isCalling) {
                    binding.tvCountDown.visibility = View.GONE
                } else {
                    binding.tvCountDown.visibility = View.VISIBLE
                }

                if (list[position].isCalling && !endTimeArray.contains(list[position].orderId)) {
                    endTimeArray.put(
                        list[position].orderId,
                        createdAt
                    )
                }
                if (endTimeArray.contains(list[position].orderId)) {
                    val endTime = endTimeArray[list[position].orderId]
                    if (endTime - System.currentTimeMillis() < 0 || !list[position].isCalling) {
                        endTimeArray.remove(list[position].orderId)
                        cancelTimer()
                    } else {
                        binding.tvCountDown.visibility = View.VISIBLE
                        startTimer(endTimeArray[list[position].orderId]) {
                            if (list.size <= position || list.size == 0) {
                                endTimeArray.clear()
                                if (::onFinishListener.isInitialized) onFinishListener.onFinish()
                                return@startTimer
                            }
                            endTimeArray.remove(list[position].orderId)
                            list[position].isCalling = false
                            if (::onFinishListener.isInitialized) onFinishListener.onFinish()
                        }
                    }
                }
                holder.binding.root.onClick {
                    if (::onActionOrderListener.isInitialized) onActionOrderListener.onEdit(position)
                }
            }.onBind(list[position])
        }

    }

    fun setOnFinish(onFinish: OnFinish) {
        this.onFinishListener = onFinish
    }

    class OrderViewHolder(view: View) : BaseViewHolder<Order, ItemCallHistoryBinding>(view) {
        var timer: CountDownTimer? = null
        override fun onBind(item: Order) {
            binding.order = item
        }

        fun cancelTimer() {
            if (timer != null) {
                timer?.cancel()
                binding.tvCountDown.text = (DEFAULT_COUNT_DOWN_TIME).toString()
                binding.tvCountDown.visibility = View.GONE
            }
        }

        fun startTimer(endTime: Long, onFinishCountDown: () -> Unit) {
            cancelTimer()
            timer = object : CountDownTimer(endTime - System.currentTimeMillis(), 1000L) {
                override fun onFinish() {
                    binding.tvCountDown.visibility = View.GONE
                    onFinishCountDown.invoke()
                }

                override fun onTick(millisUntilFinished: Long) {
                    binding.tvCountDown.text = (millisUntilFinished / 1000).toString()
                }
            }
            timer?.start()
        }
    }

    interface OnActionOrderListener {
        fun onEdit(position: Int)
    }

    interface OnFinish {
        fun onFinish()
    }
}
