package vn.app.tcs.ui.registerbar

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.ConfigBarUserCase
import vn.app.tcs.data.remote.usecase.DeleteBarUserCase
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.remote.usecase.GetRegisteredBar
import vn.app.tcs.data.usermanager.UserManager

class FragmentRegisterBarViewModel : BaseViewModel() {
    val userManager: UserManager by inject()

    private val getProfileUseCase: GetProfileUseCase by inject()
    var profile = MutableLiveData<UserProfile.Profile>()
    var changeConfig = MutableLiveData<String>("off")

    private val getListBarUseCase: GetRegisteredBar by inject()
    var bars: LiveData<ListBar?>

    private val configRegister: ConfigBarUserCase by inject()
    var config: LiveData<List<String>?>

    private val deleteBarUseCase: DeleteBarUserCase by inject()
    var deleteBar: LiveData<List<String>?>

    init {
        bars = Transformations.map(getListBarUseCase.result) {
            handleCommonApi(it)
        }
        config = Transformations.map(configRegister.result) {
            handleCommonApi(it)
        }
        deleteBar = Transformations.map(deleteBarUseCase.result) {
            handleCommonApi(it)
        }
        profile.value = userManager.getUserInfo()
    }


    fun getListBar() {
        getListBarUseCase.execute()
    }

    fun getProfile() {
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
            if (changeConfig.value != profile.value!!.hasRegisteredBar) {
                changeConfig.value = if (profile.value!!.isRegisterBar()) "on" else "off"
            }
        }, {})
    }

    fun doAddBar(){
        sendEvent(EventConstant.EVENT_ADD_BAR)
    }

    fun changeRegisterStatus(){
        sendEvent(EventConstant.EVENT_CHANGE_STATUS)
    }

    fun configBar() {
        if (changeConfig.value == profile.value!!.hasRegisteredBar) {
            sendEvent(EventConstant.EVENT_KEEP_STATUS)
            return
        }
        configRegister.apply {
            hasConfig = changeConfig.value!!
        }.execute()
    }

    fun deleteBar(id: Int) {
        deleteBarUseCase.apply {
            listBar = arrayListOf(id)
        }.execute()
    }
}