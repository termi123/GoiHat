package vn.app.tcs.ui.intro.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.Observable
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.detail_intro_fragment.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.databinding.DetailIntroFragmentBinding

class DetailIntroFragment : BaseKaraFragment<DetailIntroFragmentBinding,DetailIntroViewModel>() {
    override val layoutId: Int
        get() = R.layout.detail_intro_fragment
    override val viewModel: DetailIntroViewModel by inject()

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    companion object {
        fun newInstance(resource: Int): DetailIntroFragment {
            return DetailIntroFragment().apply {
                viewModel.resource.value = resource
            }
        }
    }



}
