package vn.app.tcs.ui.managercallhistory.adapter

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R
import vn.app.tcs.data.model.Order
import vn.app.tcs.databinding.ItemManagerCallBinding

class ManagerCallAdapter(data: ArrayList<Order>) : BaseAdapter<Order>(data) {
    lateinit var onActionOrderListener: OnActionOrderListener

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return ManagerCallViewHolder(parent?.inflateExt(R.layout.item_manager_call)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is ManagerCallViewHolder) {
            holder.onBind(list[position])
            holder.binding.root.onClick {
                if (::onActionOrderListener.isInitialized) onActionOrderListener.onEdit(position)
            }
        }

    }

    class ManagerCallViewHolder(view: View) : BaseViewHolder<Order, ItemManagerCallBinding>(view) {
        override fun onBind(item: Order) {
            binding.order = item
        }

    }

    interface OnActionOrderListener {
        fun onEdit(position: Int)
    }
}
