package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName
import vn.app.tcs.data.model.Bar

data class UpdateRoomRequest(

    @SerializedName("bar_id")
    var bar_id: Int,
    @SerializedName("rooms[]")
    var listStaff: Bar.Room
)