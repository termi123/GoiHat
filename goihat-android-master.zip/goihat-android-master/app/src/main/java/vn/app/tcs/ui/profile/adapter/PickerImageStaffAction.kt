package vn.app.tcs.ui.profile.adapter

import vn.app.tcs.data.model.WrapperImageStaff

class PickerImageStaffAction(
    var type: PickImageType,
    var wrapper: WrapperImageStaff,
    var position: Int
) {
}

enum class PickImageType {
    PICK_NEW_IMAGE, EDIT
}