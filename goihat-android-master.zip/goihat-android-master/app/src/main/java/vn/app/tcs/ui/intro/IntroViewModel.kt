package vn.app.tcs.ui.intro

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel

class IntroViewModel : BaseViewModel(){
    val showStart = MutableLiveData<Boolean>()
    val isFromMenu = MutableLiveData<Boolean>()
}