package vn.app.tcs.utils

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context.KEYGUARD_SERVICE
import android.view.WindowManager

object WakeUpUtils {
    fun setUpWakeUp(activity: Activity?) {
        if (activity == null) return
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            activity.setTurnScreenOn(true)
            activity.setShowWhenLocked(true)
            val keyguardManager = activity.getSystemService(Activity.KEYGUARD_SERVICE) as KeyguardManager?
            val lock = keyguardManager!!.newKeyguardLock(KEYGUARD_SERVICE)
            lock.disableKeyguard()
        } else {
            activity.window.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }


    }


}