package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class SelectStaffRequest(
    @SerializedName("staff_id")
    var staffId: Int
)
