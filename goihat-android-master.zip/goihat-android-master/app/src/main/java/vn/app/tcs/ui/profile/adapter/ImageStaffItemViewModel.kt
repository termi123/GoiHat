package vn.app.tcs.ui.profile.adapter

import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.ui.profile.ProfileViewModel

class ImageStaffItemViewModel : ImageStaffItemBaseViewModel<ProfileViewModel>() {

    fun doDeleteImage() = sendEvent(EventConstant.EVENT_DELETE_PICK_IMAGE_STAFF)
}