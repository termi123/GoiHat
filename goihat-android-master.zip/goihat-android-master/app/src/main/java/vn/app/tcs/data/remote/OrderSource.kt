package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.*
import vn.app.tcs.data.model.*
import vn.app.tcs.data.request.OrderStatusRequest
import vn.app.tcs.data.request.ReportRequest
import vn.app.tcs.data.request.StaffOrderRequest

interface OrderSource {

    @GET("/api/order/available-staffs")
    fun getAvailableStaffs(@Query("bar_id") id: Int, @Query("page") page: Int): Single<ListStaff>

    @GET("/api/order/my-lists/staff")
    fun getOrderForStaffs(@Query("page") page: Int, @Query("option[]") option: List<String>): Single<OrderManager>

    @GET("/api/order/{order_id}/staff")
    fun getOrderDetailForStaffs(@Path("order_id") orderId: Int): Single<DetailOrderStaff>

    @GET("/api/order/{order_id}")
    fun getOrderDetailForManager(@Path("order_id") orderId: Int): Single<OrderManagerDetail>

    @GET("/api/order/my-lists/manager")
    fun getOrderForManager(@Query("page") page: Int, @Query("is_survey") isSurvey: String): Single<OrderManager>

    @GET("/api/order/fraud-alert")
    fun getFraudAlert(@Query("page") page: Int): Single<OrderManager>

    @POST("/api/order/{order_id}/update-order-status")
    fun setOrderStatus(@Path("order_id") orderId: Int, @Body orderStatusRequest: OrderStatusRequest): Single<List<String>>

    @POST("/api/order")
    fun orderStaffs(
        @Query("bar_id") id: Int,
        @Query("number_staffs_required") number: Int,
        @Query("room_id") room_id: Int,
        @Query("fee") fee: String,
        @Query("is_random") isRandom: Boolean?,
        @Query("staff_id[]") listStaff: List<Int>
    ): Single<OrderResponse>

    @GET("/api/order/survey/{order_id}")
    fun getSurvey(@Path("order_id") orderId: Int): Single<List<String>>

    @POST("/api/order/report")
    fun report(@Body report : ReportRequest): Single<List<String>>

    @POST("/api/order/stafforder")
    fun staffOrder(@Query("description") description : String): Single<StaffOrderResponse>

    @POST("/api/order/survey/{order_id}")
    fun setSurvey(
        @Path("order_id") orderId: Int,
        @Query("number_staffs_required") numberStaffsRequired: Int,
        @Query("number_staffs_needed") numberStaffsNeeded: Int
    ): Single<List<String>>

    @POST("/api/order/survey/check")
    fun checkSurvey(
        @Query("bar_id") barId: Int,
        @Query("room_id") roomId: Int
    ): Single<List<String>>
}