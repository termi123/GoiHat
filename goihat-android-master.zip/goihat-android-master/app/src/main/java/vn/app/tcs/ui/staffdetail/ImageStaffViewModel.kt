package vn.app.tcs.ui.staffdetail

import vn.app.tcs.ui.profile.adapter.ImageStaffItemBaseViewModel

class ImageStaffViewModel : ImageStaffItemBaseViewModel<StaffViewModel>() {
}