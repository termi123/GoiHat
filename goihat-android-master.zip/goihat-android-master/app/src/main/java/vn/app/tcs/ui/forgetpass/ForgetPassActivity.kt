package vn.app.tcs.ui.forgetpass

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import vn.app.tcs.R

class ForgetPassActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_pass)
    }
}
