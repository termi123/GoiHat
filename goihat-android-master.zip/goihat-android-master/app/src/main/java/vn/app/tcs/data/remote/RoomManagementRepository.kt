package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.Bar

interface RoomManagementRepository {

    fun registerRoom(
        bar_id: Int,
        listStaff: List<String>
    ): Single<Bar.ListRoom>

    fun updateRoom(
        bar_id: Int,
        listStaff: String
    ): Single<Bar.ListRoom>

    fun deleteRoom(
        listStaff: List<Int>
    ): Single<ArrayList<String>>
}

class RoomManagementRepositoryImpl(private val orderSource: RoomManagementSource) : RoomManagementRepository {
    override fun registerRoom(bar_id: Int, listStaff: List<String>): Single<Bar.ListRoom> {
        return orderSource.registerRoom(bar_id, listStaff)
    }

    override fun updateRoom(bar_id: Int, listStaff: String): Single<Bar.ListRoom> {
        return orderSource.updateRoom(bar_id, listStaff)
    }

    override fun deleteRoom(listStaff: List<Int>): Single<ArrayList<String>> {
        return orderSource.deleteRoom(listStaff)
    }

}