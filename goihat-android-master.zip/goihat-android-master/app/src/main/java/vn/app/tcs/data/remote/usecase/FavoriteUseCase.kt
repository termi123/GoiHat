package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.UserManagerRepository
import vn.app.tcs.data.request.FavoriteRequest

class FavoriteUseCase : UseCase<List<String>>() {
    private val userManagerRepository: UserManagerRepository by inject()
    lateinit var favoriteRequest: FavoriteRequest
    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.favoriteStaff(favoriteRequest)
    }
}