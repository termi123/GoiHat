package vn.app.tcs.ui.staffdetail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.constant.AppConstant
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import org.koin.core.inject
import timber.log.Timber
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.FavoriteUseCase
import vn.app.tcs.data.remote.usecase.GetStaffInforUseCase
import vn.app.tcs.data.remote.usecase.UpdateFeeOneUseCase
import vn.app.tcs.data.request.FavoriteRequest
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.utils.databinding.notifyObserver

class StaffViewModel : BaseViewModel() {
    private val getStaffInforUseCase: GetStaffInforUseCase by inject()
    private val useManager : UserManager by inject()
    private val feeOneUseCase: UpdateFeeOneUseCase by inject()
    var staffInfo: LiveData<UserProfile>
    var showFee = MutableLiveData<Boolean>()
    var updateFeeResult = Transformations.map(feeOneUseCase.result) {
        handleCommonApi(it)
    }
    var userStatus = MutableLiveData<String>()
    private val favoriteUseCase: FavoriteUseCase by inject()

    init {
        staffInfo = Transformations.map(getStaffInforUseCase.result) {
            handleCommonApi(it)
        }
//        showFee.value = useManager.getUserInfo()!!.role == AppConstant.Role.Owner.name
    }

    fun getInfoDetail(id: String) = getStaffInforUseCase.apply { idUser = id }.execute()

    fun favoriteStaff(id: String, type: String) {
        favoriteUseCase.apply {
            favoriteRequest = FavoriteRequest(id, type) //Available values : Yes, No
        }.executeZip({
            sendEvent(EventConstant.EVENT_FAVORITE)
        }, {

        })
    }

    fun doEditManagerFee() = sendEvent(EventConstant.EVENT_CHANGE_MANAGER_FEE)

    fun editManagerFee(mFee: Int) {
        feeOneUseCase.apply {
            fee = mFee
            staffId = staffInfo.value!!.profile.id
        }.execute()
    }

    fun setDatabaseListener(database: DatabaseReference, id: String) {
        userStatus.value = "Online"
        database.child("users").child(id).child("status")
            .addValueEventListener(object : ValueEventListener {
                override fun onCancelled(databaseError: DatabaseError) {
                    Timber.d("loadPost:%s", databaseError.toException())
                }

                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (!dataSnapshot.exists()) return
                    val status = dataSnapshot.getValue(String::class.java).toString()
                    userStatus.value = status
                    userStatus.notifyObserver()
                }
            })
        database.child("users").child(id).child("status")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onCancelled(p0: DatabaseError) {

                }

                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (!dataSnapshot.exists()) return
                    val status = dataSnapshot.getValue(String::class.java).toString()
                    userStatus.value = status
                    userStatus.notifyObserver()
                }
            })
    }


    fun copyCode() {
        sendEvent(EventConstant.EVENT_COPY)
    }

    fun copyCodeUser() {
        sendEvent(EventConstant.EVENT_COPY_USER)
    }

    fun showAlbum() = sendEvent(EventConstant.EVENT_SHOW_ALBUM)
}