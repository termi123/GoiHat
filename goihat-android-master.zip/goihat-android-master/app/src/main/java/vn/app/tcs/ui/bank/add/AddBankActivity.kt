package vn.app.tcs.ui.bank.add

import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_add_bank.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BANK
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_TYPE
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.databinding.ActivityAddBankBinding
import vn.app.tcs.ui.dialog.CallDialog

class AddBankActivity : BaseKaraToolbarActivity<ActivityAddBankBinding, AddBankViewModel>() {
    override fun getToolBar(): Toolbar = toolbar

    override val layoutId: Int
        get() = R.layout.activity_add_bank
    override val viewModel: AddBankViewModel by viewModel()

    private val originBar: ListBank.Bank? by lazy { intent?.extras?.get(KEY_BANK) as ListBank.Bank? }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getIntentData()
    }

    override fun setUpObserver() {
        super.setUpObserver()
        viewModel.deleteBar.observe(this, Observer {
            it?.let {
                finish()
            }
        })
        viewModel.updateBankResult.observe(this, Observer {

        })
        viewModel.addBankResult.observe(this, Observer {

        })
        viewModel.deleteBarResult.observe(this, Observer {

        })
    }

    private fun getIntentData() {
        viewModel.type = intent?.extras?.get(KEY_BAR_TYPE) as AppConstant.BarActionType
        originBar?.let {
            viewModel.setRequest(originBar!!)
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_ADD_BAR -> {
                if (!isValidate()) return
                viewModel.apply {
                    addBankRequestLiveData.value?.apply {
                        accountOwnerName = etName.text.toString()
                        bankName = etBankName.text.toString()
                        bankBranch = etBranchName.text.toString()
                        accountNumber = etAccount.text.toString()
                    }
                }
                viewModel.addBank()
            }
            EventConstant.EVENT_EDIT_BAR -> {
                if (!isValidate()) return
                viewModel.apply {
                    addBankRequestLiveData.value?.apply {
                        accountOwnerName = etName.text.toString()
                        bankName = etBankName.text.toString()
                        bankBranch = etBranchName.text.toString()
                        accountNumber = etAccount.text.toString()
                    }
                }
                viewModel.updateBar(originBar?.id)
            }

            EventConstant.EVENT_ADD_BAR_SUCCESS -> {
                finish()
            }
            EventConstant.EVENT_UPDATE_BAR_SUCCESS -> {
                finish()
            }
            EventConstant.EVENT_DELETE_BAR -> {
                originBar?.let {
                    CallDialog.newInstance(MessageDialog("Xoá cơ sở", "Bạn có chắc chắn muốn xóa tài khoản này không.̉", confirmButton = "Huỷ", cancelButton = "OK"))
                        .show(supportFragmentManager, it.id.toString())
                }
            }
        }
    }

    override fun handleEventCloseDialog(event : RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if (event.dialogState == AppConstant.DialogState.Back) {
            viewModel.deleteBar(originBar?.id!!)
        }
    }

    private fun isValidate(): Boolean {
        if (TextUtils.isEmpty(etName.text.toString())) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), "Yêu cầu nhập tên Chủ tài khoản."))
            return false
        }
        if (TextUtils.isEmpty(etBankName.text.toString())) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), "Yêu cầu nhập tên Ngân hàng."))
            return false
        }
//        if (TextUtils.isEmpty(etBranchName.text.toString())) {
//            showDialogMessage(MessageDialog(getString(R.string.app_name), "Yêu cầu nhập tên Chi nhánh."))
//            return false
//        }
        if (TextUtils.isEmpty(etAccount.text.toString())) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), "Yêu cầu nhập Số tài khoản."))
            return false
        }

        return true
    }

}