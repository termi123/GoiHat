package vn.app.tcs.ui.staffdetail

import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseLifecycleAdapter
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.base.adapter.BaseVMAdapter
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.ItemImageViewStaffBinding

class ImageViewStaffAdapter (var activity: FragmentActivity, listImage: ArrayList<WrapperImageStaff>) :

    BaseVMAdapter<WrapperImageStaff, ImageStaffViewModel>(listImage) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffImageViewHolder(parent?.inflateExt(R.layout.item_image_view_staff)!!, activity, this)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffImageViewHolder) {
            list[position].apply {
                if (!viewModelProvide.contains(id)) {
                    viewModelProvide.put(id, ImageStaffViewModel())
                }
                holder.onBind(this, viewModelProvide.get(id), position)
            }
        }
    }

    class StaffImageViewHolder(
        view: View,
        activity: FragmentActivity,
        var adapter: ImageViewStaffAdapter
    ) :
        BaseLifecycleAdapter<WrapperImageStaff, ItemImageViewStaffBinding, ImageStaffViewModel>(
            view,
            activity
        ) {
        var positionItem = -1

        fun onBind(item: WrapperImageStaff, viewModelItem: ImageStaffViewModel, position: Int) {
            this.viewModel = viewModelItem
            this.positionItem = position
            viewModel.mainViewModel = (activity as StaffDetailActivity).viewModel
            onBind(item)
        }

        override fun onBind(item: WrapperImageStaff) {
            super.onBind(item)
            viewModel.staffImage.value = item
        }
    }
}