package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.remote.OrderRepository

class GetManagerCallHistoryUseCase : UseCase<OrderManager>() {
    var pageNum = 1
    var isSurvey = true
    private val barManagementRepository: OrderRepository by inject()
    override fun buildUseCaseObservable(): Single<OrderManager> {
        return barManagementRepository.getOrderForManager(pageNum, isSurvey)
    }
}