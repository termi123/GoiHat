package vn.app.tcs.ui.sendstar

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.remote.usecase.SendStarUseCase
import vn.app.tcs.data.usermanager.UserManager

class SendStarViewModel(private val sendStarUseCase: SendStarUseCase,private val userManager: UserManager,private val getProfileUseCase: GetProfileUseCase) : BaseViewModel() {

    var lastCode = ""
    var lastStar = 0

    val profile = MutableLiveData<UserProfile.Profile>()

    init {
        profile.value = userManager.getUserInfo()
    }

    val sendStarResult = Transformations.map(sendStarUseCase.result) {
        handleCommonApi(it)
    }

    fun getProfile(){
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
        },{})
    }

    fun doSendStar() = sendEvent(EventConstant.EVENT_SEND_STAR)

    fun sendStar(mCode: String, mStar: Int,passWord : String) {
        sendStarUseCase.apply {
            code = mCode
            star = mStar
            pass = passWord
        }.executeZip({
            lastCode = mCode
            lastStar = mStar
            getProfile()
            sendEvent(EventConstant.EVENT_SEND_STAR_SUCCESS)
        }, {})
    }
}
