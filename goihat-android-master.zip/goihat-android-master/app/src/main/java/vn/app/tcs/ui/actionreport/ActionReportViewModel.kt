package vn.app.tcs.ui.actionreport

import android.icu.lang.UCharacter.GraphemeClusterBreak.L
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.deploygate.sdk.DeployGate.refresh
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.base.LoadingState
import vn.app.tcs.data.karaconstant.DEFAULT_PAGE
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.ActionReportUseCase
import vn.app.tcs.utils.TimeUtil
import java.util.*

class ActionReportViewModel(private var actionReportUseCase: ActionReportUseCase) : BaseListViewModel() {

    var timeData = MutableLiveData<String?>()
    var statusData = MutableLiveData<String?>()
    var statusDataDisplay = MutableLiveData<String?>()
    var fromDate = MutableLiveData<String>()
    var toDate = MutableLiveData<String>()
    var enableSelect = false

    init {
        fromDate.value =
            TimeUtil.convertCalToString(Calendar.getInstance(), TimeUtil.DATE_FORMAT_INCOME)
        toDate.value =
            TimeUtil.convertCalToString(Calendar.getInstance(), TimeUtil.DATE_FORMAT_INCOME)
    }

    val actionReport = Transformations.map(actionReportUseCase.result) {
        handleStateCommonApi(it)
    }

    override fun loadData() {
        getListAction()
    }

    private fun getListAction() {
        actionReportUseCase.apply {
            currentPage = page
            time = timeData.value
            option = statusData.value
        }.executeZip({
            page++
            isEmpty.value = (stateLoading == LoadingState.INIT || stateLoading == LoadingState.REFRESH) && it.users.staffs.isNullOrEmpty()
        }, {})
    }

    fun getCalendarFromDate(date: String?): Calendar {
        if (date.isNullOrEmpty()) return Calendar.getInstance()
        return TimeUtil.convertCalendarForEvent(date, TimeUtil.DATE_FORMAT_INCOME)!!
    }

    fun doPickFromDate() {
        if(enableSelect) sendEvent(EventConstant.EVENT_PICK_FROM_DATE)
    }

    fun doPickToDate() {
        if(enableSelect) sendEvent(EventConstant.EVENT_PICK_TO_DATE)
    }

    fun doReport() = reset()


    fun setPickUpdate(isToDate: Boolean, year: Int, monthOfYear: Int, dayOfMonth: Int) {
        val convertTime =
            TimeUtil.convertNumberToCalendar(year, monthOfYear, dayOfMonth)
        if (isToDate) {
            toDate.value = TimeUtil.convertCalToString(
                convertTime,
                TimeUtil.DATE_FORMAT_INCOME
            )
            return
        }
        fromDate.value = TimeUtil.convertCalToString(
            convertTime,
            TimeUtil.DATE_FORMAT_INCOME
        )
        if (TimeUtil.getDifferenceTime(
                convertTime!!,
                getCalendarFromDate(toDate.value)
            ) < 0
        )
            toDate.value = fromDate.value

    }
}
