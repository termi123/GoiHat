package vn.app.tcs

import android.app.Application
import android.content.Context
import androidx.multidex.MultiDex
import com.base.common.CommonApplication
import com.crashlytics.android.Crashlytics
import com.google.firebase.analytics.FirebaseAnalytics
import com.zing.zalo.zalosdk.oauth.ZaloSDKApplication
import io.fabric.sdk.android.Fabric
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import timber.log.Timber
import vn.app.tcs.di.module.*


class KaraApplication : CommonApplication() {
    var mFirebaseAnalytics: FirebaseAnalytics? = null

    override fun onCreate() {
        super.onCreate()
        app = this
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        startKoin {
            androidContext(this@KaraApplication)
            modules(
                viewModelModule,
                appModule,
                networkModule,
                repositoryModule,
                useCaseModule
            )
        }
        Fabric.with(this, Crashlytics())
        ZaloSDKApplication.wrap(this);
        Timber.plant(Timber.DebugTree())
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    companion object {
        private var app: KaraApplication? = null
        private var baseUrl: String = ""

        val instance: Application?
            get() = app

        fun getBaseUrl() = baseUrl
        fun setBaseUrl(url: String) {
            baseUrl = url
        }
    }
}