package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.data.remote.ReportRepository

class GetListChangeCodeUseCase : UseCase<ListChangeCode>(){

    var pageList: Int = 1
    private val authenticateRepository: ReportRepository by inject()

    override fun buildUseCaseObservable(): Single<ListChangeCode> {
        return authenticateRepository.getListChangeCode(pageList)
    }
}