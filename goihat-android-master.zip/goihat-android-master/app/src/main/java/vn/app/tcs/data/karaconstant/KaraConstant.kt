package vn.app.tcs.data.karaconstant

enum class CategoryNotification(var category: String) {
    order("order"),
    survey("survey"),
    alert("alert"),
    warning("warning"),
    money("money")

}

val DEFAULT_TIME : Int = 60
val DEFAULT_COUNT_DOWN_TIME : Int = 120
val DEFAULT_REPORT_TIME : Int = 24 * 60 * 60
val DEFAULT_PAGE = 1
