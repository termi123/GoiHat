package vn.app.tcs.data.model


import com.base.common.constant.AppConstant
import com.google.gson.annotations.SerializedName
import vn.app.tcs.utils.TimeUtil

data class Order(
    @SerializedName("bar")
    val bar: Bar,
    @SerializedName("processing_at")
    val processingAt: String = "",
    @SerializedName("rejected_at")
    val rejectedAt: String = "",
    @SerializedName("manager")
    val manager: Manager,
    @SerializedName("complete_at")
    val completeAt: String = "",
    @SerializedName("approved_at")
    val approvedAt: String = "",
    @SerializedName("canceled_at")
    val canceledAt: String = "",
    @SerializedName("created_at")
    val createdAt: String = "",
    @SerializedName("order_id")
    val orderId: Int = 0,
    @SerializedName("status")
    val status: String = "",
    @SerializedName("type")
    val type: String = "",
    @SerializedName("reason")
    val reason: String = "",
    @SerializedName("number_staffs_required")
    val numberStaffsRequired: Int = 0,
    @SerializedName("number_staffs_accepted")
    val numberStaffsAccepted: Int = 0,
    @SerializedName("room")
    val room: Bar.Room,

    var isCalling: Boolean
) {
    fun getDateOrder() =
        TimeUtil.milliSecondToDate(createdAt.toLong(), TimeUtil.DATE_FOMART_EVENT_ORDER)

    fun getStaffStatus(): String = AppConstant.Status.from(status)!!.status
}


data class Manager(
    @SerializedName("birthday")
    val birthday: String = "",
    @SerializedName("code")
    val code: String = "",
    @SerializedName("address")
    val address: String = "",
    @SerializedName("role")
    val role: String = "",
    @SerializedName("gender")
    val gender: String = "",
    @SerializedName("phone")
    val phone: String = "",
    @SerializedName("referral_code")
    val referralCode: String = "",
    @SerializedName("name")
    val name: String = "",
    @SerializedName("created_at")
    val createdAt: String = "",
    @SerializedName("id")
    val id: Int = 0,
    @SerializedName("avatar")
    val avatar: String = ""
)


data class OrderManager(
    @SerializedName("per_page")
    val perPage: Int = 0,
    @SerializedName("total")
    val total: Int = 0,
    @SerializedName("lists")
    val lists: List<Order>?,
    @SerializedName("last_page")
    val lastPage: Int = 0,
    @SerializedName("current_page")
    val currentPage: Int = 0
)


