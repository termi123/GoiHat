package vn.app.tcs.ui.income

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.utils.rx.bus.RxEvent
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.remote.usecase.IncomeFilterUseCase
import vn.app.tcs.data.remote.usecase.UpdateFeeAllUseCase
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.utils.TimeUtil
import java.util.*

class IncomeViewModel(
    private val incomeFilterUseCase: IncomeFilterUseCase,
    private val updateFeeAllUseCase: UpdateFeeAllUseCase
) : BaseViewModel() {
    var fromDate = MutableLiveData<String>()
    var toDate = MutableLiveData<String>()
    var profile = MutableLiveData<UserProfile.Profile>()
    val userManager: UserManager by inject()
    private val getProfileUseCase: GetProfileUseCase by inject()

    var profileRequestData = Transformations.map(getProfileUseCase.result) {
        handleCommonApi(it)
    }

    val updateFee = Transformations.map(updateFeeAllUseCase.result) {
        handleCommonApi(it)
    }

    init {
        fromDate.value =
            TimeUtil.convertCalToString(Calendar.getInstance(), TimeUtil.DATE_FORMAT_INCOME)
        toDate.value =
            TimeUtil.convertCalToString(Calendar.getInstance(), TimeUtil.DATE_FORMAT_INCOME)
    }


    var incomeFilter = Transformations.map(incomeFilterUseCase.result) {
        handleCommonApi(it)
    }

    fun doFilterIncome() {
        if (fromDate.value != null && toDate.value != null) {
            incomeFilterUseCase.apply {
                from = fromDate.value
                to = toDate.value
            }.execute()
        }
    }

    fun getProfileFromApi() {
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
        }, {})
    }

    fun getProfile() {
        profile.value = userManager.getUserInfo()
    }

    fun doPickFromDate() = sendEvent(EventConstant.EVENT_PICK_FROM_DATE)

    fun doPickToDate() = sendEvent(EventConstant.EVENT_PICK_TO_DATE)

    fun doEditManagerFee() = sendEvent(EventConstant.EVENT_CHANGE_MANAGER_FEE)

    fun getCalendarFromDate(date: String?): Calendar {
        if (date.isNullOrEmpty()) return Calendar.getInstance()
        return TimeUtil.convertCalendarForEvent(date, TimeUtil.DATE_FORMAT_INCOME)!!
    }


    fun copyCode() {
        sendEvent(EventConstant.EVENT_COPY)
    }


    fun navigationSingerList() {
        publishRxEvent(RxEvent.ShowSingerList())
    }

    fun setPickUpdate(isToDate: Boolean, year: Int, monthOfYear: Int, dayOfMonth: Int) {
        val convertTime =
            TimeUtil.convertNumberToCalendar(year, monthOfYear, dayOfMonth)
        if (isToDate) {
            toDate.value = TimeUtil.convertCalToString(
                convertTime,
                TimeUtil.DATE_FORMAT_INCOME
            )
            return
        }
        fromDate.value = TimeUtil.convertCalToString(
            convertTime,
            TimeUtil.DATE_FORMAT_INCOME
        )
        if (TimeUtil.getDifferenceTime(
                convertTime!!,
                getCalendarFromDate(toDate.value)
            ) < 0
        )
            toDate.value = fromDate.value

    }


    fun updateFeeOwner(mFee: Int) {
        updateFeeAllUseCase.apply { fee = mFee }.execute()
    }
}
