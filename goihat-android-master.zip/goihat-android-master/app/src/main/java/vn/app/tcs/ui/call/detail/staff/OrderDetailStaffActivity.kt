package vn.app.tcs.ui.call.detail.staff

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import io.reactivex.disposables.Disposable
import org.jetbrains.anko.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.DEFAULT_REPORT_TIME
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.ActivityOrderDetailBinding
import vn.app.tcs.ui.home.dialog.CallSupportDialog
import vn.app.tcs.ui.report.ReportActivity
import vn.app.tcs.utils.WakeUpUtils
import vn.app.tcs.utils.databinding.notifyObserver
import vn.app.tcs.utils.sound.AlarmController
import vn.app.tcs.utils.sound.VibratorController


class OrderDetailStaffActivity : BaseKaraActivity<ActivityOrderDetailBinding, OrderDetailStaffViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_order_detail
    override val viewModel: OrderDetailStaffViewModel by viewModel()

    private var oderId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        WakeUpUtils.setUpWakeUp(this)
        super.onCreate(savedInstanceState)
        getIntentData()
        viewModel.orderInfoRequest.observe(this, Observer {
            it.let {
                viewModel.orderInfo.value = it
                if (viewModel.isFromFb.value == true) {
                    if (it?.status != null) {
                        if (!it.status.equals(AppConstant.Status.New.name)) {
                            AlarmController.stopSound()
                            VibratorController.stopAlert()
                        }
                    }
                }
            }
        })
        viewModel.updaetOrderInfo.observe(this, Observer {
            it.let {
                AlarmController.stopSound()
                VibratorController.stopAlert()
                viewModel.orderInfo.value?.status = viewModel.tempStatus
                viewModel.orderInfo.notifyObserver()
                if (viewModel.tempStatus == AppConstant.Status.Complete.name ||
                        viewModel.tempStatus == AppConstant.Status.Cancel.name ||
                        viewModel.tempStatus == AppConstant.Status.Rejected.name
                ) {
                    runOnUiThread {
                        Handler().postDelayed({
                            finish()
                        }, 1000)
                    }
                }
            }
        })
        addDisposable(RxEvent.EventReloadDetail::class.java) {
            //            viewModel.getInfoDetail(oderId)
        }
        addDisposable(RxEvent.EventReload::class.java) {
            viewModel.getInfoDetail(oderId)
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Call -> {

            }
            AppConstant.DialogState.Back -> {
                when (event.tag) {
                    EventConstant.EVENT_ACCEPT.toString() -> viewModel.updateOrder(AppConstant.Status.Processing.name)
                    EventConstant.EVENT_COMPLETE.toString() -> viewModel.updateOrder(AppConstant.Status.Complete.name)
                    "E0409" -> finish()
//                    "TIME_OUT" -> gotoReportScreen()
                }
            }
            else -> {
            }
        }
    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        when (event?.tag) {
            EventConstant.EVENT_ACCEPT.toString() -> viewModel.updateOrder(AppConstant.Status.Processing.name)
            EventConstant.EVENT_COMPLETE.toString() -> viewModel.updateOrder(AppConstant.Status.Complete.name)
            "E0409" -> finish()
//            "TIME_OUT" -> gotoReportScreen()
        }
    }

    private fun getIntentData() {
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    oderId = ex.getInt(EventConstant.KEY_ORDER_DETAIL, 0)
                    viewModel.getInfoDetail(oderId)
                    viewModel.isFromFb.value = (ex.getBoolean(EventConstant.KEY_FROM_FB, false))
                    viewModel.isFromSP.value = (ex.getBoolean(EventConstant.KEY_FROM_SPLASH, false))
                }
            }
        }
    }

    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        getIntentData()
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_BACK -> onBackPressed()
            EventConstant.EVENT_STOP_ALERT -> VibratorController.stopAlert()
//            EventConstant.EVENT_REPORT -> {
//                if (System.currentTimeMillis() > (viewModel.orderInfo.value?.createdAt!!.toLong() + DEFAULT_REPORT_TIME) * 1000) {
//                    showDialogMessage(MessageDialog(content = "Đã quá thời gian cho phép báo cáo (24 giờ từ lúc sự kiện được tạo), bạn không thể BÁO CÁO sự kiện này nữa").apply {
//                        tag = "TIME_OUT"
//                    })
//                    return
//                }
//                gotoReportScreen()
//            }
            EventConstant.EVENT_ACCEPT -> {
                showDialog2ButtonMessage(
                        MessageDialog(
                                content = "Xác nhận được chọn, TK của bạn sẽ - " + viewModel.getFee() + "⭐",
                                tag = EventConstant.EVENT_ACCEPT.toString(),
                                confirmButton = "Huỷ", cancelButton = "OK"
                        )
                )
            }
            EventConstant.EVENT_COMPLETE -> {
                showDialog2ButtonMessage(
                        MessageDialog(
                                content = "Bạn chỉ được hoàn thành khi đã kết thúc sự kiện. Bạn có muốn hoàn thành ngay không",
                                tag = EventConstant.EVENT_COMPLETE.toString(),
                                confirmButton = "Huỷ", cancelButton = "OK"
                        )
                )
            }
        }
    }

//    private fun gotoReportScreen() {
//        startActivity<ReportActivity>(
//                EventConstant.KEY_ORDER_DETAIL to oderId,
//                EventConstant.KEY_CREATE_DATE to viewModel.orderInfo.value?.createdAt
//        )
//        finish()
//    }

    override fun onBackPressed() {
        if (viewModel.orderInfo.value?.status == AppConstant.Status.Approve.name
                || viewModel.orderInfo.value?.status == AppConstant.Status.Processing.name) {
            return
        }
        super.onBackPressed()
    }
}
