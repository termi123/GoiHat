package vn.app.tcs.utils.sound;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import timber.log.Timber;

public class VibratorController {

    private static Vibrator vibrator;

    private VibratorController(Context c) {
        vibrator = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
    }

    public static void setVibrate(Context context) {
        if (vibrator == null) {
            new VibratorController(context);
        }
        if (vibrator.hasVibrator()) {
            long[] mVibratePattern = {0, 400, 800, 600, 800, 800, 800, 1000};
            int[] mAmplitudes = {0, 255, 0, 255, 0, 255, 0, 255};
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (vibrator.hasAmplitudeControl()) {
                    VibrationEffect effect = VibrationEffect.createWaveform(mVibratePattern, mAmplitudes, -1);
                    vibrator.vibrate(effect);
                }
            } else {
                vibrator.vibrate(mVibratePattern, 3);
            }
        }
    }

    public static void stopAlert() {
        if (vibrator == null) {
            return;
        }
        try {
            vibrator.cancel();
//            ringtone.stop()
        } catch (Exception ex) {
            Timber.d(ex);
        }
    }
}
