package vn.app.tcs.data.remote

import io.reactivex.Single
import okhttp3.RequestBody
import retrofit2.http.*
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.model.ListBar

interface BarManagementSource {

    @GET("/api/bar/list")
    fun getListBar(@Query("manager_id") id: String): Single<ListBar>

    @GET("/api/bar/detail/{id}")
    fun getBarDetail(@Path("id") id: String): Single<Bar>

    @POST("/api/bar/register")
    fun registerBar(@Body body: RequestBody, @Query("rooms[]") rooms: List<String>): Single<ArrayList<String>>

    @POST("/api/bar/delete/{id}")
    fun deleteBar(@Path("id") id: String): Single<ArrayList<String>>

    @POST(value = "/api/bar/update/{id}")
    fun updateBar(
        @Path(
            value = "id",
            encoded = true
        ) id: String, @Body body: RequestBody, @Query("rooms[]") rooms: List<String>
    ): Single<Bar>
}
