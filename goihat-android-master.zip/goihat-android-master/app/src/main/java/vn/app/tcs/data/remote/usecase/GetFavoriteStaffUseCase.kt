package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.data.remote.UserManagerRepository
import vn.app.tcs.data.request.FavoriteOptionRequest

class GetFavoriteStaffUseCase : UseCase<ListStaff>() {
    private val userManagerRepository: UserManagerRepository by inject()
    lateinit var favoriteOptionRequest: FavoriteOptionRequest

    override fun buildUseCaseObservable(): Single<ListStaff> {
        return userManagerRepository.getFavoriteStaff(favoriteOptionRequest)
    }
}