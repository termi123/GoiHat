package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class FavoriteOptionRequest(
    @SerializedName("page")
    var page: String,
    @SerializedName("option")
    var option: String,
    @SerializedName("bar_id")
    var barId: String = "0"
)