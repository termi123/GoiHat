package vn.app.tcs.data.model


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ListBank(
    @SerializedName("lists")
    val lists: List<Bank>
) : Serializable {

    class Bank : BankInfo(), Serializable {
        @SerializedName("id")
        var id: Int = 0
        @SerializedName("owner_id")
        var ownerId: Int = 0
    }

    open class BankInfo : Serializable {
        @SerializedName("account_owner_name")
        var accountOwnerName: String = ""
        @SerializedName("account_number")
        var accountNumber: String = ""
        @SerializedName("bank_name")
        var bankName: String = ""
        @SerializedName("bank_branch")
        var bankBranch: String = ""
    }
}