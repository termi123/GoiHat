package vn.app.tcs.ui.intro.detail

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel

class DetailIntroViewModel : BaseViewModel() {
    var resource = MutableLiveData<Int>()
}
