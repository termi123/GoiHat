package vn.app.tcs.ui.actionreport

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.data.event.MessageDialog
import kotlinx.android.synthetic.main.action_report_fragment.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraListFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.StaffAction
import vn.app.tcs.databinding.ActionReportFragmentBinding
import vn.app.tcs.ui.actionreport.detail.DetailStaffActionActivity
import vn.app.tcs.utils.TimeUtil
import java.util.*
import kotlin.collections.ArrayList

class ActionReportFragment :
    BaseKaraListFragment<ActionReportFragmentBinding, ActionReportViewModel, StaffAction>() {
    override val recyclerView: RecyclerView by lazy { rvReport }
    override val layoutId: Int
        get() = R.layout.action_report_fragment
    override val viewModel: ActionReportViewModel by viewModel()

    private val listTime = arrayOf("today", "yesterday", "7_days", null)

    private val listTimeDisplay by lazy {
        arrayOf(
            getString(R.string.today),
            getString(R.string.yesterday),
            getString(R.string.seven_day),
            getString(R.string.pick_time)
        )
    }
    private val listStatusDisplay = arrayOf("Kết thúc", "Từ chối cuộc gọi", "Bị từ chối", "Out")

    private val listStatus = arrayOf("Complete", "Rejected", "Cancel", "Out")

    override val adapter: BaseAdapter<StaffAction> = ActionReportAdapter(ArrayList())


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initSpinnerTime()
        initSpinnerStatus()
        viewModel.actionReport.observe(viewLifecycleOwner, Observer {
            it?.let { report ->
                run {
                    btUpdateFilter.text = "Thống kê (${report.total})"
                    adapter.totalPage = report.users.lastPage
                    handlerLoadData(report.users.staffs)
                }
            }
        })
    }

    private fun initSpinnerStatus() {
        val statusAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listStatusDisplay)
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spStatusAction.adapter = statusAdapter
        spStatusAction.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                viewModel.statusData.value = listStatus[position]
                viewModel.statusDataDisplay.value = listStatusDisplay[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

        }
    }

    private fun initSpinnerTime() {
        val timeAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, listTimeDisplay)
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spTimeAction.adapter = timeAdapter
        spTimeAction.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                viewModel.enableSelect = position == 3
                viewModel.timeData.value = listTime[position]
                viewModel.toDate.value =
                    TimeUtil.convertCalToString(Calendar.getInstance().apply {
                        when (position) {
                            0 -> {// Today
                                if(this.get(Calendar.HOUR_OF_DAY) > 6){
                                    add(Calendar.DAY_OF_YEAR,1)
                                }
                            }
                            1 -> {// Today
                                if(this.get(Calendar.HOUR_OF_DAY) < 6){
                                    add(Calendar.DAY_OF_YEAR,-1)
                                }
                            }
                            2 -> {// Today
                                if(this.get(Calendar.HOUR_OF_DAY) < 6){
                                    add(Calendar.DAY_OF_YEAR,-1)
                                }
                            }
                        }

                    }, TimeUtil.DATE_FORMAT_INCOME)
                viewModel.fromDate.value =
                    TimeUtil.convertCalToString(Calendar.getInstance().apply {
                        when (position) {
                            0 -> {
                                if(this.get(Calendar.HOUR_OF_DAY) < 6){
                                    add(Calendar.DAY_OF_YEAR,-1)
                                }
                            }
                            1 -> add(Calendar.DAY_OF_YEAR, if(this.get(Calendar.HOUR_OF_DAY) < 6) -2 else -1)
                            2 -> add(Calendar.DAY_OF_YEAR, if(this.get(Calendar.HOUR_OF_DAY) <  6) -7 else -6)
                        }
                    }, TimeUtil.DATE_FORMAT_INCOME)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }

        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_PICK_TO_DATE -> handlePickDate(true)
            EventConstant.EVENT_PICK_FROM_DATE -> handlePickDate(false)
        }
    }

    private fun handlePickDate(isToDate: Boolean) {
        viewModel.getCalendarFromDate(if (isToDate) viewModel.toDate.value else viewModel.fromDate.value)
            .let {
                val today = Calendar.getInstance()
                val minDate = if (isToDate) {
                    viewModel.getCalendarFromDate(viewModel.fromDate.value)
                } else {
                    Calendar.getInstance().apply {
                        add(Calendar.DAY_OF_YEAR, -44)
                    }
                }
                DatePickerDialog(
                    requireContext(),
                    DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                        run {
                            viewModel.setPickUpdate(isToDate, year, monthOfYear, dayOfMonth)
                        }
                    },
                    it.get(Calendar.YEAR),
                    it.get(Calendar.MONTH),
                    it.get(Calendar.DAY_OF_MONTH)
                ).apply {
                    datePicker.maxDate = today.timeInMillis
                    datePicker.minDate = minDate.timeInMillis
                }.show()
            }
    }

    override fun onClickRecycleViewItem(item: StaffAction) {
        super.onClickRecycleViewItem(item)
        if (item.orderStaffCount == 0) {
            showDialogMessage(
                MessageDialog(
                    "Thông báo",
                    getString(
                        R.string.staff_report_no_order,
                        item.name,
                        viewModel.statusDataDisplay.value!!
                    )
                )
            )
            return
        }
        startActivity<DetailStaffActionActivity>(EventConstant.KEY_ORDER_DETAIL to item)
    }

    companion object {
        val TAG = ActionReportFragment::class.java.simpleName
        fun newInstance(): ActionReportFragment {
            return ActionReportFragment()
        }
    }

}
