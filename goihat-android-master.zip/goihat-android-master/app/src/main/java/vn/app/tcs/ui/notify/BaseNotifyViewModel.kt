package vn.app.tcs.ui.notify

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.data.karaconstant.EventConstant.EVENT_MARK_NOTIFICATION
import vn.app.tcs.data.model.Notify
import vn.app.tcs.data.remote.usecase.GetNotifyUseCase
import vn.app.tcs.data.remote.usecase.SetMarkAllNotification
import vn.app.tcs.data.remote.usecase.SetMarkNotification

abstract class BaseNotifyViewModel : BaseListViewModel() {
    abstract val categoryNoti : String?
    private val getNotifyUseCase: GetNotifyUseCase by inject()
    private val markNotification: SetMarkNotification by inject()
    private val markAllNotification: SetMarkAllNotification by inject()

//    var markNotificationRequest: LiveData<List<String>> = Transformations.map(markNotification.result) {
//        handleCommonApi(it)
//    }
    var markAllNotificationRequest: LiveData<List<String>> = Transformations.map(markAllNotification.result) {
        handleCommonApi(it)
    }

    var listNotify: LiveData<Notify> = Transformations.map(getNotifyUseCase.result) {
        handleStateCommonApi(it)
    }

    override fun loadData(){
        getListNotify()
    }

    private fun getListNotify() {
        getNotifyUseCase.apply {
            pageNum = page
            category = categoryNoti
        }.executeZip({
            page++
        },{})
    }

    fun setMark(tempId: String) {
        markNotification.apply { id = tempId }.executeZip({
            sendEvent(EVENT_MARK_NOTIFICATION)
        },
        {})
    }

    fun setAllMark() {
        markAllNotification.execute()
    }
}