package vn.app.tcs.ui.home

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.constant.AppConstant
import io.reactivex.Observable
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.*
import vn.app.tcs.data.request.LocationRequest
import vn.app.tcs.data.request.TokenRequest
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.utils.TimeUtil
import java.util.*
import java.util.concurrent.TimeUnit

class MainViewModel : BaseViewModel() {
    private val updateFirebaseTokenUseCase: UpdateFirebaseTokenUseCase by inject()
    private val logoutUseCase: LogoutUseCase by inject()
    private val updateLocationUseCase: UpdateLocationUseCase by inject()
    private val updateActivityUseCase: UpdateActivityUseCase by inject()
    val userManager: UserManager by inject()

    var profile = MutableLiveData<UserProfile.Profile>()


    var loutOut = Transformations.map(logoutUseCase.result) {
        handleCommonApi(it)
    }

    init {
        updateFirebase()
        getProfile()
        if (!isOnline()) {
            updateProfile(AppConstant.Activity.Online.name)
        }
    }

    fun updateProfile(activity: String) {
        if (isStaff()) {
            updateActivityUseCase.apply {
                this.activity = activity
            }.execute()
        }
    }

    fun isStaff() = userManager.getUserInfo()?.role == AppConstant.Role.Staff.name

    fun isOnline() =
        isStaff() && userManager.getUserInfo()?.activity == AppConstant.Activity.Online.name

    private fun updateFirebase() {
        updateFirebaseTokenUseCase.apply {
            tokenRequest =
                TokenRequest(userManager.getUUID(), "android", userManager.getFireBaseToken())
        }.execute()
    }

    fun logOut() {
        logoutUseCase.executeZip({
            userManager.setUserInfo(null)
            userManager.setIsUserLogin(false)
        }, {})
    }

    fun clickLeftTopButton()  = sendEvent(EventConstant.EVENT_PROFILE)



    @SuppressLint("CheckResult")
    fun setUpLocationSchedule() {
        Observable.interval(1, TimeUnit.MINUTES)
            .startWith(1)
            .subscribe(
                {
                    sendEvent(EventConstant.EVENT_GET_LOCATION)
                }, {

                }
            )
    }

    fun sendLocation(lat: Double, lng: Double) {
        updateLocationUseCase.apply {
            id = userManager.getUserInfo()?.id.toString()
            locationRequest = LocationRequest(lat.toString(), lng.toString())
        }.execute()
    }

    fun getProfile() {
        profile.value = userManager.getUserInfo()
    }

}