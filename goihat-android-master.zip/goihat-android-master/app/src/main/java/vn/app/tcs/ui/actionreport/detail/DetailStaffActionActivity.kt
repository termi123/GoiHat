package vn.app.tcs.ui.actionreport.detail

import android.os.Bundle
import com.base.common.base.adapter.BaseAdapter
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseStaticListActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.OrderInfo
import vn.app.tcs.data.model.StaffAction

class DetailStaffActionActivity : BaseStaticListActivity<DetailStaffActionViewModel, OrderInfo>() {
    override val adapter: BaseAdapter<OrderInfo> = OrderInfoAdapter(ArrayList())
    override val viewModel: DetailStaffActionViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTitleToolbar(getString(R.string.detai_action))
    }

    override fun initList() {
        super.initList()
        adapter.setDataList((intent!!.extras!!.get(EventConstant.KEY_ORDER_DETAIL) as StaffAction).orderStaff.lists as ArrayList<OrderInfo>)
    }

}