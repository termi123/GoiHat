package vn.app.tcs.ui.report

import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.ReportUseCase
import vn.app.tcs.data.request.ReportRequest

class ReportViewModel(private var requestUseCase: ReportUseCase) : BaseViewModel() {
    var order: Int = 0
    var reportResult = Transformations.map(requestUseCase.result) {
        handleCommonApi(it)
    }

    fun sendReport(title: String, body: String) {
        requestUseCase.apply {
            reportRequest = ReportRequest(order, title, body)
        }.executeZip({
            sendEvent(EventConstant.EVENT_CHECK_REPORT)
        }, {})
    }

    fun doSendReport() = sendEvent(EventConstant.EVENT_SEND_REPORT)

}