package vn.app.tcs.di.module

import org.koin.dsl.module
import vn.app.tcs.data.remote.usecase.*
import vn.app.tcs.ui.actionreport.ActionReportViewModel
import vn.app.tcs.ui.actionreport.detail.DetailStaffActionViewModel
import vn.app.tcs.ui.addbar.AddBarViewModel
import vn.app.tcs.ui.addbar.fee.FeeViewModel
import vn.app.tcs.ui.addbar.room.AddRoomViewModel
import vn.app.tcs.ui.bank.add.AddBankViewModel
import vn.app.tcs.ui.bank.list.BankListViewModel
import vn.app.tcs.ui.call.CallStaffViewModel
import vn.app.tcs.ui.call.bar.ChooseBarViewModel
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerViewModel
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffViewModel
import vn.app.tcs.ui.call.select.SelectStaffViewModel
import vn.app.tcs.ui.changemanagercode.ChangeManagerCodeViewModel
import vn.app.tcs.ui.changepass.ChangePassViewModel
import vn.app.tcs.ui.dialog.*
import vn.app.tcs.ui.favorite.StaffFavoriteViewModel
import vn.app.tcs.ui.fraud.FraudAlertViewModel
import vn.app.tcs.ui.home.MainViewModel
import vn.app.tcs.ui.income.IncomeViewModel
import vn.app.tcs.ui.intro.IntroViewModel
import vn.app.tcs.ui.intro.detail.DetailIntroViewModel
import vn.app.tcs.ui.login.LoginViewModel
import vn.app.tcs.ui.managercallhistory.ManagerCallHistoryViewModel
import vn.app.tcs.ui.managercallhistory.history.HistoryEventViewModel
import vn.app.tcs.ui.managerhome.FragmentManagerHomeViewModel
import vn.app.tcs.ui.notify.NotifyViewModel
import vn.app.tcs.ui.profile.ProfileViewModel
import vn.app.tcs.ui.profile.detail.ImageStaffDetailViewModel
import vn.app.tcs.ui.profile.slideshow.SlideShowViewModel
import vn.app.tcs.ui.register.RegisterViewModel
import vn.app.tcs.ui.registerbar.FragmentRegisterBarViewModel
import vn.app.tcs.ui.registerbar.ListRegisterBarViewModel
import vn.app.tcs.ui.report.ReportViewModel
import vn.app.tcs.ui.report.detail.ReportDetailViewModel
import vn.app.tcs.ui.report.list.ListReportViewModel
import vn.app.tcs.ui.sendstar.SendStarViewModel
import vn.app.tcs.ui.splash.SplashViewModel
import vn.app.tcs.ui.staffdetail.StaffViewModel
import vn.app.tcs.ui.staffhistorycall.StaffCallHistoryViewModel
import vn.app.tcs.ui.staffhome.StaffHomeViewModel
import vn.app.tcs.ui.stafflist.StaffListViewModel
import vn.app.tcs.ui.stafforder.StaffOrderViewModel
import vn.app.tcs.ui.term.TermViewModel

val viewModelModule = module {
    factory { MainViewModel() }
    factory { LoginViewModel() }
    factory { RegisterViewModel() }
    factory { SplashViewModel() }
    factory { StaffViewModel() }
    factory { ReportDetailViewModel() }
    factory { CommonDialogViewModel() }
    factory { CallDialogViewModel() }
    factory { ChangePassViewModel() }
    factory { IncomeViewModel(get(), get()) }
    factory { FragmentManagerHomeViewModel() }
    factory { FragmentRegisterBarViewModel() }
    factory { ListRegisterBarViewModel() }
    factory { AddBarViewModel() }
    factory { AddBankViewModel() }
    factory { AddRoomViewModel() }
    factory { CallStaffViewModel() }
    factory { SelectStaffViewModel() }
    factory { DeleteBarUseCase() }
    factory { DeleteBankUseCase() }
    factory { UpdateBarUseCase() }
    factory { UpdateBankUseCase() }
    factory { NotifyViewModel() }
    factory { OrderDetailStaffViewModel() }
    factory { OrderDetailManagerViewModel() }
    factory { EditDialogViewModel() }
    factory { MultipleEditDialogViewModel() }
    factory { StaffHomeViewModel() }
    factory { StaffCallHistoryViewModel() }
    factory { ManagerCallHistoryViewModel() }
    factory { ListReportViewModel() }
    factory { ProfileViewModel() }
    factory { ImageStaffDetailViewModel() }
    factory { SlideShowViewModel() }
    factory { FavoriteUseCase() }
    factory { GetStaffActivityUseCase() }
    factory { GetFavoriteStaffUseCase() }
    factory { GetBankUseCase() }
    factory { CheckVersionUseCase() }
    factory { FraudAlertViewModel() }
    factory { FeeViewModel() }
    factory { TermViewModel() }
    factory { StaffFavoriteViewModel() }
    factory { DetailIntroViewModel() }
    factory { IntroViewModel() }
    factory { HistoryEventViewModel() }
    factory { ChooseBarViewModel() }
    factory { ReportViewModel(get()) }
    factory { StaffOrderViewModel(get()) }
    factory { ActionReportViewModel(get()) }
    factory { DetailStaffActionViewModel() }
    factory { ChangeManagerCodeViewModel(get()) }
    factory { StaffListViewModel() }
    factory { BankListViewModel(get()) }
    factory { SendStarViewModel(get(), get(),get()) }
    factory { WheelPickerDialogViewModel() }
}