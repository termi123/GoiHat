package vn.app.tcs.ui.notify

import org.koin.androidx.viewmodel.ext.android.viewModel


class NotifyFragment : BaseNotifyFragment<NotifyViewModel>() {

    override val viewModel: NotifyViewModel by viewModel()

    companion object {
        val TAG = NotifyFragment::class.java.simpleName
        fun newInstance(): NotifyFragment {
            return NotifyFragment()
        }
    }
}
