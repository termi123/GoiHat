package vn.app.tcs.utils.imagepicker

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import java.io.*

class ImagePicker(private val fragment: Activity) {

    private var onPickSuccessListener: ImagePickerListener? = null
    private var needCropAfterPick: Boolean = false
    private var userType: Int = 0
    private var cropPictureUrl: Uri? = null
    var tag: String = ""
    val cropImageUrl: Uri? = null
    var cameraUri: Uri? = null
        private set
    private var authority: String? = null

    val isExternalStorageWritable: Boolean
        get() {
            return Environment.MEDIA_MOUNTED == Environment.getExternalStorageState()
        }

    fun setListener(listener: ImagePickerListener): ImagePicker {
        this.onPickSuccessListener = listener
        return this
    }

    fun needCropAfterPick(isNeed: Boolean): ImagePicker {
        this.needCropAfterPick = isNeed
        return this
    }

    fun userType(userType: Int): ImagePicker {
        this.userType = userType
        return this
    }

    fun setAuthority(authority: String): ImagePicker {
        this.authority = authority
        return this
    }

    fun showAlertDialog() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryIntent.type = "image/*"

        val chooserIntent = Intent.createChooser(galleryIntent, "Pick Photo")

        if (isExternalStorageWritable) {
            cameraUri = FileUtils.getInstance(fragment).createImageUri()
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                cameraIntent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri)
            val intents = arrayOf(cameraIntent)
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, intents)
        }

        try {
            fragment.startActivityForResult(
                chooserIntent,
                CHOOSE_PHOTO_INTENT
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    // Change this method(edited)
    fun handleGalleryResult(data: Intent) {
        try {
            cropPictureUrl = Uri.fromFile(
                FileUtils.getInstance(fragment)
                    .createImageTempFile(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES))
            )
            val realPathFromURI =
                FileUtils.getRealPathFromURI(fragment, data.data)
            val file = File(
                realPathFromURI ?: getImageUrlWithAuthority(
                    fragment,
                    data.data!!
                )
            )
            if (file.exists()) {
                if (currentAndroidDeviceVersion > 23) {
                    if (needCropAfterPick) {
                        cropImage(
                            FileProvider.getUriForFile(fragment, authority!!, file),
                            cropPictureUrl
                        )
                    } else {
                        onPickSuccessListener!!.onPickSuccess(
                            FileProvider.getUriForFile(
                                fragment,
                                authority!!,
                                file
                            ), tag
                        )
                    }
                } else {
                    if (needCropAfterPick) {
                        cropImage(Uri.fromFile(file), cropPictureUrl)
                    } else {
                        onPickSuccessListener!!.onPickSuccess(Uri.fromFile(file), tag)
                    }
                }
            } else {
                if (needCropAfterPick) {
                    cropImage(data.data, cropPictureUrl)
                } else {
                    onPickSuccessListener!!.onPickSuccess(data.data, tag)
                }
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    fun handleCameraResult(cameraPictureUrl: Uri?) {
        try {
            if (needCropAfterPick) {
                cropPictureUrl = Uri.fromFile(
                    FileUtils.getInstance(fragment)
                        .createImageTempFile(
                            Environment.getExternalStoragePublicDirectory(
                                Environment.DIRECTORY_PICTURES
                            )
                        )
                )
                cropImage(cameraPictureUrl, cropPictureUrl)
            } else {
                onPickSuccessListener!!.onPickSuccess(cropPictureUrl, tag)
            }
        } catch (e: IOException) {
            e.printStackTrace()
            onPickSuccessListener!!.onPickSuccess(cropPictureUrl, tag)
        } catch (e: ActivityNotFoundException) {
            e.printStackTrace()
            onPickSuccessListener!!.onPickSuccess(cropPictureUrl, tag)
        }

    }

    private fun cropImage(sourceImage: Uri?, destinationImage: Uri?) {
        CropImage.activity(sourceImage)
            .setGuidelines(CropImageView.Guidelines.ON)
            .setAspectRatio(1, 1)
            .setOutputUri(destinationImage)
            .setRequestedSize(500, 500)
            .setOutputCompressFormat(Bitmap.CompressFormat.PNG)
            .setActivityMenuIconColor(Color.WHITE)
            .start(fragment)
    }

    fun onActivityResult(
        imagePicker: ImagePicker,
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == CHOOSE_PHOTO_INTENT) {
                if (data != null && data.data != null) {
                    imagePicker.handleGalleryResult(data)
                } else {
                    imagePicker.handleCameraResult(imagePicker.cameraUri)
                }
            } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                val result = CropImage.getActivityResult(data)
                onPickSuccessListener!!.onPickSuccess(result.uri, tag)
            }
        }
    }

    interface ImagePickerListener {
        fun onPickSuccess(uri: Uri?, tag: String)
    }

    companion object {

        var CHOOSE_PHOTO_INTENT = 101
        var currentAndroidDeviceVersion = Build.VERSION.SDK_INT

        private val PERMISSION_PICKER = arrayOf(
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
        )

        fun getImageUrlWithAuthority(context: Context, uri: Uri): String? {
            var `is`: InputStream? = null
            if (uri.authority != null) {
                try {
                    `is` = context.contentResolver.openInputStream(uri)
                    val bmp = BitmapFactory.decodeStream(`is`)
                    return writeToTempImageAndGetPathUri(
                        context,
                        bmp
                    ).toString()
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } finally {
                    try {
                        `is`!!.close()
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }

                }
            }
            return null
        }

        fun writeToTempImageAndGetPathUri(inContext: Context, inImage: Bitmap): Uri {
            val bytes = ByteArrayOutputStream()
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
            val path = MediaStore.Images.Media.insertImage(
                inContext.contentResolver,
                inImage,
                "Title",
                null
            )
            return Uri.parse(path)
        }
    }

}