package vn.app.tcs.data.karaconstant

object EventConstant {
    const val EVENT_MULTI_EDIT_DIALOG = 1000
    const val EVENT_BACK = 9999
    const val EVENT_DISMISS = 9998
    const val EVENT_CALL = 9997
    const val EVENT_EDIT_DIALOG = 9996
    const val EVENT_STOP_ALERT = 9995
    const val EVENT_COPY = 9994
    const val EVENT_COPY_USER = 9993
    const val EVENT_ACCEPT = 9992
    const val EVENT_COMPLETE = 9991
//    const val EVENT_REPORT = 9990
    const val EVENT_CHECK_REPORT = 9989
    const val EVENT_SEND_REPORT = 9988
    const val EVENT_SEND_STAFF_ORDER = 9987
    const val EVENT_STAFF_ORDER = 9986
    const val EVENT_LOGIN = 1
    const val EVENT_MAIN = 2
    const val EVENT_REGISTER = 3
    const val EVENT_FORGOT_PASS = 4
    const val EVENT_CHANGE_PASS = 5
    const val EVENT_ADD_BAR = 6
    const val EVENT_PICK_IMAGE = 7
    const val EVENT_PICK_LOCATION = 8
    const val EVENT_ADD_BAR_SUCCESS = 9
    const val EVENT_EDIT_BAR = 10
    const val EVENT_DELETE_BAR = 11
    const val EVENT_UPDATE_BAR_SUCCESS = 12
    const val EVENT_CALL_STAFF = 13
    const val EVENT_FIND_STAFF = 14
    const val KEY_MAX_CALL_STAFF = 15
    const val KEY_WANT_CALL_STAFF = 16
    const val EVENT_GET_LOCATION = 17
    const val EVENT_UPDATE_PROFILE = 18
    const val EVENT_PROFILE = 19
    const val EVENT_BIRTH_DAY = 20
    const val EVENT_UPDATE_PROFILE_SUCCESS = 21
    const val EVENT_UPDATE_STATUS = 22
    const val EVENT_FAVORITE = 23
    const val EVENT_UPDATE_FAVORITE = 24
    const val EVENT_UPDATE_LIST_STAFF = 25
    const val EVENT_UPGRADE_APP = 26
    const val EVENT_ACTIVITY_BUSY = 27
    const val EVENT_PICK_ROOM = 28
    const val EVENT_ADD_ROOM = 29
    const val EVENT_PICK_FEE = 30
    const val EVENT_CHANGE_STAFF_CALL = 31
    const val EVENT_TERM = 32
    const val EVENT_FINISH = 33
    const val EVENT_LIMIT_CALL = 34
    const val EVENT_CANT_CALL = 35
    const val RELOAD_STAFF_CALL = 36
    const val EVENT_PICK_FROM_DATE = 37
    const val EVENT_PICK_TO_DATE = 38
    const val EVENT_OUT = 40
    const val EVENT_REPORT_ACTION = 41
    const val EVENT_ADD_BANK = 42
    const val EVENT_VALID_NEW_CODE = 43
    const val EVENT_CHANGE_NEW_CODE = 44
    const val EVENT_CHANGE_MANAGER_FEE = 45
    const val EVENT_REJECT_ORDER_ACCEPT = 46
    const val EVENT_REJECT_ORDER_DENY = 47
    const val EVENT_CALL_SUPPORT = 48
    const val EVENT_MARK_NOTIFICATION = 49
    const val EVENT_CANT_CALL_OFFLINE = 50
    const val EVENT_SEND_STAR = 51
    const val EVENT_CHANGE_STATUS = 52
    const val EVENT_KEEP_STATUS = 53
    const val EVENT_NEG_DIALOG = 54
    const val EVENT_SELF_CALL_STAFF = 55
    const val EVENT_SEND_STAR_SUCCESS = 56
    const val EVENT_PICK_IMAGE_STAFF = 57
    const val EVENT_DELETE_PICK_IMAGE_STAFF = 58
    const val EVENT_SHOW_AVATAR_STAFF = 59
    const val EVENT_NEXT = 60
    const val EVENT_PREVIOUS = 61
    const val EVENT_SHOW_ALBUM  = 62
    const val EVENT_SHOW_SINGER_LIST  = 63


    //key data
    const val KEY_STAFF_DETAIL = "KEY_STAFF_DETAIL"
    const val KEY_REPORT_REJECT_DETAIL = "KEY_REPORT_REJECT_DETAIL"
    const val KEY_STAFF_FAVORITE = "KEY_STAFF_FAVORITE"
    const val KEY_ORDER_DETAIL = "KEY_ORDER_DETAIL"
    const val KEY_ORDER_DETAIL_FROM_NOTI = "KEY_ORDER_DETAIL_FROM_NOTI"
    const val KEY_FROM_FB = "KEY_FROM_FB"
    const val KEY_FROM_SPLASH = "KEY_FROM_SPLASH"
    const val KEY_FROM_LOGIN = "KEY_FROM_LOGIN"
    const val KEY_BAR_TYPE = "KEY_BAR_TYPE"
    const val KEY_BAR_ORIGIN = "KEY_BAR_ORIGIN"
    const val KEY_LIST_ROOM = "KEY_LIST_ROOM"
    const val KEY_BAR_POSITION = "KEY_BAR_POSITION"
    const val KEY_BAR_ID = "KEY_BAR_ID"
    const val KEY_MAX_CALL = "KEY_MAX_CALL"
    const val KEY_GUIDE = "KEY_GUIDE"
    const val KEY_WANT_CALL = "KEY_WANT_CALL"
    const val KEY_WANT_FEE = "KEY_WANT_FEE"
    const val KEY_ROOM_NAME_ADD = "KEY_ROOM_NAME_ADD"
    const val KEY_ROOM_NAME_EDIT = "KEY_ROOM_NAME_EDIT"
    const val KEY_ROOM_NAME_DELETE = "KEY_ROOM_NAME_DELETE"
    const val KEY_MULTI_EDIT = "KEY_MULTI_EDIT"
    const val KEY_CREATE_DATE = "KEY_CREATE_DATE"
    const val KEY_BANK = "KEY_BANK"
    const val KEY_LIST_IMAGE = "KEY_LIST_IMAGE"
    const val KEY_LIST_IMAGE_POSITION = "KEY_LIST_IMAGE_POSITION"


    //Session TimeOut
    const val EVENT_SESSION = 10000


}