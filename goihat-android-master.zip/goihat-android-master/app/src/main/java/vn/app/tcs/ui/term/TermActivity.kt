package vn.app.tcs.ui.term

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import kotlinx.android.synthetic.main.activity_term.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.databinding.ActivityTermBinding

class TermActivity : BaseKaraToolbarActivity<ActivityTermBinding, TermViewModel>() {
    override fun getToolBar(): Toolbar = toolbar

    override val layoutId: Int
        get() = R.layout.activity_term
    override val viewModel: TermViewModel by inject()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wvTerm!!.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                view?.loadUrl(url)
                return true
            }
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }
}
