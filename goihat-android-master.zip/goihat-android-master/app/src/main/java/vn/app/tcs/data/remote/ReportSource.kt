package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.*
import vn.app.tcs.data.model.ListBlackList
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.data.request.RejectOrderRequest

interface ReportSource {

    @GET("/api/report/reject-order")
    fun getListRejectOrder(@Query("page") page: Int): Single<ListRejectOrder>

    @GET("/api/report/blacklist")
    fun getListBlackList(@Query("page") page: Int): Single<ListBlackList>

    @GET("/api/report/change-code-request")
    fun getListChangeCode(@Query("page") page: Int): Single<ListChangeCode>

    @POST("/api/report/reject-order")
    fun rejectOrder(@Body request: RejectOrderRequest): Single<List<String>>

    //Available values : blacklist, change-code-request, reject-order
    @POST("/api/report/read/{id}/{type}")
    fun setReportRead(@Path("id") id: Int, @Path("type") type: String): Single<List<String>>

}