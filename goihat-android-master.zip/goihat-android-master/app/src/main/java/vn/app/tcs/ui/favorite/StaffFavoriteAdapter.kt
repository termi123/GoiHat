package vn.app.tcs.ui.favorite

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.ItemStaffFavoriteBinding
import vn.app.tcs.databinding.ItemStaffListBinding

class StaffFavoriteAdapter(data: ArrayList<ListStaff.Staff>) : BaseAdapter<ListStaff.Staff>(data) {

    lateinit var onActionBarListener: OnActionBarListener

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return BarViewHolder(parent?.inflateExt(R.layout.item_staff_favorite)!!)
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BarViewHolder) {
            holder.onBind(list[position])
            holder.binding.ivFavorite.setOnClickListener {
                if (::onActionBarListener.isInitialized) {
                    onActionBarListener.onFavorite(position, list[position].id, list[position].getInvertFavorite())
                }
            }
        }
    }

    class BarViewHolder(view: View) : BaseViewHolder<ListStaff.Staff, ItemStaffFavoriteBinding>(view) {
        override fun onBind(item: ListStaff.Staff) {
            binding.staff = item

        }

    }

    interface OnActionBarListener {
        fun onFavorite(position: Int, staffId: Int, type: String)
    }
}