package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.StaffOrderResponse
import vn.app.tcs.data.remote.OrderRepository
import vn.app.tcs.data.request.StaffOrderRequest

class StaffOrderUseCase : UseCase<StaffOrderResponse>() {
    private val order: OrderRepository by inject()
    lateinit var staffOrderRequest : StaffOrderRequest

    override fun buildUseCaseObservable(): Single<StaffOrderResponse> {
        return order.staffOrder(staffOrderRequest)
    }

}