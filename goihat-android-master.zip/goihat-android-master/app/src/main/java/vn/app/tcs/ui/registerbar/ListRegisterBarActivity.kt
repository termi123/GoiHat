package vn.app.tcs.ui.registerbar

import android.app.Activity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import kotlinx.android.synthetic.main.activity_add_bar.*
import kotlinx.android.synthetic.main.fragment_manager_home.*
import org.jetbrains.anko.toast
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.FragmentListRegisterBarBinding

class ListRegisterBarActivity :
    BaseKaraToolbarActivity<FragmentListRegisterBarBinding, ListRegisterBarViewModel>(),
    BaseAdapter.OnClickItemListener<Bar> {

    override fun getToolBar(): Toolbar = toolbar

    override val layoutId: Int
        get() = R.layout.fragment_list_register_bar

    override val viewModel: ListRegisterBarViewModel by inject()
    private lateinit var adapter: ListRegisterBarAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.bars.observe(this, Observer { listBar ->
            run {
                listBar?.let {
                    viewDataBinding?.hasBar = !listBar.lists.isNullOrEmpty()
                    adapter.setDataList(it.lists)
                }
            }
        })
        viewModel.addBars.observe(this, Observer {
            it?.let {
                setResult(Activity.RESULT_OK, intent)
                finish()
            }
        })
        etBarName.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                viewModel.getListBar(v.text.toString())
                return@setOnEditorActionListener true
            }
            false
        }
        initBarList()
        viewModel.getListBar("")
    }
    override fun onClickItem(item: Bar, position: Int) {
        if (::adapter.isInitialized) {
            adapter.selectBar(position = position)
        }
    }

    private fun initBarList() {
        adapter = ListRegisterBarAdapter(ArrayList())
        adapter.setOnClickListener(this)
        rvBarList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rvBarList.adapter = adapter
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_ADD_BAR -> {
                val listBars = adapter.getDataList().filter { it.checked }.map { it.id }
                if (listBars.isNullOrEmpty()) {
                    toast(getString(R.string.selectBar))
                    return
                }
                viewModel.registerBars(listBars as List<Int>)
            }
        }
    }


}