package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.data.remote.BankRepository

class GetBankUseCase : UseCase<ListBank>() {
    private val bankRepository: BankRepository by inject()

    override fun buildUseCaseObservable(): Single<ListBank> {
        return bankRepository.getListBank()
    }
}