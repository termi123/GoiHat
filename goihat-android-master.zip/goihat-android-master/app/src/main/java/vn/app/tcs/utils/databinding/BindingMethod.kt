package vn.app.tcs.utils.databinding

import android.graphics.drawable.Drawable
import android.text.Html
import android.text.method.LinkMovementMethod
import android.view.View
import android.webkit.WebView
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.databinding.BindingAdapter
import com.base.common.constant.AppConstant
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.CategoryNotification
import vn.app.tcs.data.model.Data

@BindingAdapter("imageResource")
fun setImageResource(imageView: ImageView, resource: Int) {
    if (resource == 0) {
        setImageResource(imageView, R.drawable.ic_default_profile)
        return
    }
    Glide.with(imageView).load(resource)
        .apply(RequestOptions().placeholder(R.drawable.ic_default_profile).error(R.drawable.ic_default_profile))
        .into(imageView)
}

@BindingAdapter("imageResourceIntro")
fun setImageResourceIntro(imageView: ImageView, resource: Int) {
    if (resource == 0) {
        setImageResource(imageView, R.drawable.ic_default_profile)
        return
    }
    Glide.with(imageView).load(resource)
        .apply(RequestOptions().placeholder(R.drawable.ic_default_profile).error(R.drawable.ic_default_profile))
        .dontTransform()
        .into(imageView)
}

@BindingAdapter(value = ["imageRes", "place"], requireAll = true)
fun setImageResourceWithPlaceHolder(imageView: ImageView, imageRes: Int, place: Int) {
    if (imageRes == 0) {
        setImageResource(imageView, place)
        return
    }
    Glide.with(imageView).load(imageRes)
        .apply(RequestOptions().placeholder(place).error(place))
        .into(imageView)
}

@BindingAdapter("imageResourceDefault")
fun setImageResourceDefault(imageView: ImageView, resource: String?) {
    if (resource.isNullOrBlank()) {
        setImageResource(imageView, R.drawable.default_bar)
        return
    }
    Glide.with(imageView).load(resource)
        .apply(RequestOptions().placeholder(R.drawable.default_bar).error(R.drawable.default_bar))
        .into(imageView)
}

@BindingAdapter("imageBarResource")
fun setImageBarResource(imageView: ImageView, resource: Data?) {
    if (resource == null) {
        setImageResource(imageView, R.drawable.default_bar)
        return
    }
    if (resource.barAvatar.isBlank()) {
        setImageResource(imageView, getIconNotify(resource.category))
        return
    }
    Glide.with(imageView).load(resource.barAvatar)
        .apply(RequestOptions().placeholder(R.drawable.default_bar).error(R.drawable.default_bar))
        .into(imageView)
}

fun getIconNotify(category: String): Int {
    if (category == CategoryNotification.order.category) {
        return R.drawable.default_bar
    }
    if (category == CategoryNotification.money.category) return R.drawable.money
    if (category == CategoryNotification.warning.category) return R.drawable.warning
    return R.drawable.default_bar
}

@BindingAdapter("htmlText")
fun setHtmlText(textView: TextView, resource: String?) {
    if (resource.isNullOrBlank()) return
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
        textView.text = Html.fromHtml(resource, Html.FROM_HTML_MODE_LEGACY);
    } else {
        @Suppress("DEPRECATION")
        textView.text = Html.fromHtml(resource)
    }
    textView.movementMethod = LinkMovementMethod.getInstance();
}

@BindingAdapter("loadWebUrl")
fun loadWebUrl(webView: WebView, resource: String?) {
    resource?.let {
        webView.loadUrl(resource)
    }
}

@BindingAdapter("imageResource")
fun setImageResource(imageView: ImageView, resource: String?) {
    if (resource.isNullOrBlank() || resource == com.base.common.BuildConfig.BASE_URL) {
        setImageResource(imageView, R.drawable.ic_default_profile)
        return
    }
    Glide.with(imageView).load(resource)
        .apply(RequestOptions().placeholder(R.drawable.ic_default_profile).error(R.drawable.ic_default_profile))
        .into(imageView)
}

@BindingAdapter(value = ["imageResource", "placeHolder"])
fun setImageResourceWithPlaceHolder(
    imageView: ImageView,
    imageResource: String?,
    placeHolder: Drawable
) {
    if (imageResource.isNullOrBlank() || imageResource == com.base.common.BuildConfig.BASE_URL) {
        imageView.setImageDrawable(placeHolder)
        return
    }
    Glide.with(imageView).load(imageResource)
        .apply(RequestOptions().placeholder(placeHolder).error(placeHolder))
        .into(imageView)
}

@BindingAdapter("bindingStateCall")
fun setStateCallResource(view: View, state: Int) {
    when (state) {
        0 -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_call_staff_green)
        1 -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_selecting)
        2 -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_cant_select)
    }
}

@BindingAdapter("bindingState")
fun setBindingState(view: View, state: String?) {
    when (state) {
        AppConstant.Activity.Online.name -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_call_staff_green)
        AppConstant.Activity.Ondesk.name -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_selecting)
        else -> view.background =
            ContextCompat.getDrawable(view.context, R.drawable.bg_cant_select)
    }
}

@BindingAdapter("imageResourceBar")
fun setImageResourceBar(imageView: ImageView, resource: String?) {
    if (resource.isNullOrBlank() || resource == com.base.common.BuildConfig.BASE_URL) {
        setImageResource(imageView, R.drawable.default_bar)
        return
    }
    Glide.with(imageView).load(resource)
        .apply(RequestOptions().placeholder(R.drawable.default_bar).error(R.drawable.default_bar))
        .into(imageView)
}