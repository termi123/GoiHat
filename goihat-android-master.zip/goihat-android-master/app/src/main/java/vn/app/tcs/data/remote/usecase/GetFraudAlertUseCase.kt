package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.remote.OrderRepository

class GetFraudAlertUseCase : UseCase<OrderManager>() {
    private val orderRepositoryImpl: OrderRepository by inject()
    var page = 0
    override fun buildUseCaseObservable(): Single<OrderManager> {
        return orderRepositoryImpl.getFraudAlert(page)
    }
}