package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import vn.app.tcs.data.remote.UserManagerRepository

class SendStarUseCase(val userManagerRepository: UserManagerRepository) : UseCase<List<String>>() {
    var star : Int = 0
    var code : String? = null
    var pass : String? = null
    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.sendStar(code,star,pass)
    }
}