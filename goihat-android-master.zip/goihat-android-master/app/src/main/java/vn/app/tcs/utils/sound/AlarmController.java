package vn.app.tcs.utils.sound;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import vn.app.tcs.R;

import java.io.IOException;

public class AlarmController {
    private static MediaPlayer mp;
    private static AudioManager mAudioManager;
    private static int userVolume;

    private AlarmController(Context c) {
        mAudioManager = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        //remember what the user's volume was set to before we change it.
        userVolume = mAudioManager.getStreamVolume(AudioManager.STREAM_ALARM);
        mp = new MediaPlayer();
        setUpMediaPlayer();
    }

    private void setUpMediaPlayer() {
        //Only for release target
        // set the volume to what we want it to be.  In this case it's max volume for the alarm stream.
        mAudioManager.setStreamVolume(AudioManager.STREAM_ALARM, mAudioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM) * 2 / 3, 0);
        mp.setAudioStreamType(AudioManager.STREAM_ALARM);
        mp.setLooping(false);
    }

    public static void playSound(Context context, String category) {
        try {
            if (mp == null)
                new AlarmController(context);
            else
                mp.reset();
            int sound = getSound(category);
            if (sound == 0) return;
            AssetFileDescriptor maiLinhTaxi = context.getResources().openRawResourceFd(sound);
            if (!mp.isPlaying()) {
                mp.setLooping(true);
                mp.setDataSource(maiLinhTaxi.getFileDescriptor(), maiLinhTaxi.getStartOffset(), maiLinhTaxi.getLength());
                mp.prepare();
                mp.start();
                mp.setOnCompletionListener(mp -> {
                    stopSound();
                    mp.release();
                });
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static int getSound(String category) {
        switch (category) {
            case "order":
                return R.raw.call_sound;
            case "alert":
            case "survey":
                return R.raw.alert;
            case "warning":
                return R.raw.warning;
            case "money":
                break;
        }
        return 0;
    }

    public static void stopSound() {
        // reset the volume.
        if (mp == null || !mp.isPlaying()) return;
//        mAudioManager.setStreamVolume(AudioManager.STREAM_ALARM, userVolume, AudioManager.FLAG_PLAY_SOUND);
        mp.stop();
        mp.reset();

    }

}