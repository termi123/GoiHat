package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName
import java.io.File

data class UserRegisterRequest(
    @SerializedName("name") var name: String,
    @SerializedName("phone") var phone: String,
    @SerializedName("password") var password: String,
    @SerializedName("role") var role: String,
    @SerializedName("referral_code") var referral_code: String
) {
    var avatar: File? = null
}