package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ActionReportResponse
import vn.app.tcs.data.remote.UserManagerRepository

class ActionReportUseCase(var userManagerRepository : UserManagerRepository) : UseCase<ActionReportResponse>() {
    var time : String? = null
    var to : String? = null
    var from : String? = null
    var option : String? = null
    var currentPage : Int = 1
    override fun buildUseCaseObservable(): Single<ActionReportResponse> {
        return userManagerRepository.actionReport(currentPage, from, to, option, time)
    }
}