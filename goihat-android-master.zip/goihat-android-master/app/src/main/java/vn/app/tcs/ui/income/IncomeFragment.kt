package vn.app.tcs.ui.income

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import androidx.databinding.Observable
import com.base.common.base.fragment.BaseMVVMFragment
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.FragmentIncomeBinding
import vn.app.tcs.ui.dialog.EditDialog
import vn.app.tcs.ui.home.owner.MainOwnerActivity
import vn.app.tcs.utils.TimeUtil
import java.util.*

class IncomeFragment : BaseMVVMFragment<FragmentIncomeBinding, IncomeViewModel>() {
    override val layoutId: Int
        get() = R.layout.fragment_income
    override val viewModel: IncomeViewModel by viewModel()
    private val tagEditFee = "editFeeStaff"
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.incomeFilter.observe(viewLifecycleOwner, androidx.lifecycle.Observer { })
        viewModel.profileRequestData.observe(viewLifecycleOwner, androidx.lifecycle.Observer {  })
        addDisposable(RxEvent.GetProfileEvent::class.java) {
            viewModel.getProfileFromApi()
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_COPY -> TimeUtil.setClipboard(viewModel.profile.value?.code)
            EventConstant.EVENT_PICK_TO_DATE -> handlePickDate(true)
            EventConstant.EVENT_PICK_FROM_DATE -> handlePickDate(false)
            EventConstant.EVENT_CHANGE_MANAGER_FEE -> showManagerFee()
        }
    }

    override fun observerData() {
        super.observerData()
        viewModel.updateFee.observe(viewLifecycleOwner, androidx.lifecycle.Observer {
            it?.let {
                if (it.isNotEmpty()) viewModel.getProfileFromApi()
            }
        })
    }

    private fun showManagerFee() {
        EditDialog.newInstance(
            MessageDialog(
                title = getString(R.string.manager_fee),
                content = "",
                cancelButton = getString(R.string.cancel),
                hint = "Nhập giá trị",
                tag = tagEditFee,
                inputType = InputType.TYPE_CLASS_NUMBER
            )
        ).show(childFragmentManager, tagEditFee)
    }

    private fun handlePickDate(isToDate: Boolean) {
        viewModel.getCalendarFromDate(if (isToDate) viewModel.toDate.value else viewModel.fromDate.value)
            .let {
                val today = Calendar.getInstance()
                val minDate = if (isToDate) {
                    viewModel.getCalendarFromDate(viewModel.fromDate.value)
                } else {
                    Calendar.getInstance().apply {
                        add(Calendar.DAY_OF_YEAR, -44)
                    }
                }
                DatePickerDialog(
                    requireContext(),
                    DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
                        run {
                            viewModel.setPickUpdate(isToDate, year, monthOfYear, dayOfMonth)
                        }
                    },
                    it.get(Calendar.YEAR),
                    it.get(Calendar.MONTH),
                    it.get(Calendar.DAY_OF_MONTH)
                ).apply {
                    datePicker.maxDate = today.timeInMillis
                    datePicker.minDate = minDate.timeInMillis
                }.show()
            }
    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        if (event?.tag == tagEditFee && event.data is String) {
            if ((event.data as String).isEmpty()) {
                showDialogMessage(MessageDialog(content = "Phí quản lý không hợp lệ vui lòng thử lại"))
                return
            }
            try {
                viewModel.updateFeeOwner((event.data as String).toInt())
            } catch (e: NumberFormatException) {
                showDialogMessage(MessageDialog(content = "Phí quản lý không hợp lệ vui lòng thử lại"))
            }
        }
    }

    companion object {
        val TAG: String = IncomeFragment::class.java.simpleName
        fun newInstance(): IncomeFragment {
            return IncomeFragment()
        }
    }

    override fun onResume() {
        super.onResume()
        if (activity is MainOwnerActivity) {
            (activity as MainOwnerActivity).viewDataBinding?.ivTop?.visibility = View.VISIBLE
        }
        viewModel.getProfile()
        viewModel.getProfileFromApi()
    }

    override fun onPause() {
        super.onPause()
        if (activity is MainOwnerActivity) {
            (activity as MainOwnerActivity).viewDataBinding?.ivTop?.visibility = View.GONE
        }
    }
}
