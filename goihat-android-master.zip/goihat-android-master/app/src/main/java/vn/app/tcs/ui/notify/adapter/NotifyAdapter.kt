package vn.app.tcs.ui.notify.adapter

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.NotifyItem
import vn.app.tcs.databinding.ItemNotifyBinding

class NotifyAdapter(data: ArrayList<NotifyItem>) : BaseAdapter<NotifyItem>(data) {

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return NotifyViewHolder(parent?.inflateExt(R.layout.item_notify)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is NotifyViewHolder) {
            holder.onBind(list[position])
        }

    }

    class NotifyViewHolder(view: View) : BaseViewHolder<NotifyItem, ItemNotifyBinding>(view) {
        override fun onBind(item: NotifyItem) {
            binding.notify = item
        }

    }

}
