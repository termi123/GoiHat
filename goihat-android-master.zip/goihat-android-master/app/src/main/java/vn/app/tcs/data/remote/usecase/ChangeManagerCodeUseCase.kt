package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import vn.app.tcs.data.remote.UserManagerRepository

class ChangeManagerCodeUseCase(private var userManagerRepository: UserManagerRepository) :
    UseCase<List<String>>() {
    var newCode: String? = null
    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.changeOwnerCode(newCode)
    }
}