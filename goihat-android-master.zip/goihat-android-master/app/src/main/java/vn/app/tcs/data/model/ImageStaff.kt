package vn.app.tcs.data.model

import android.net.Uri

class ImageStaff(var uri : Uri,var isLocalImage : Boolean,var id : String = "-1") {
    fun getImageResource() = if(isLocalImage) uri.path else uri.toString()
}