package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.OrderManagerDetail
import vn.app.tcs.data.remote.OrderRepository

class GetOrderDetailManagerUseCase : UseCase<OrderManagerDetail>() {
    var id: Int = 0

    private val barManagementRepository: OrderRepository by inject()

    override fun buildUseCaseObservable(): Single<OrderManagerDetail> {
        return barManagementRepository.getOrderDetailForManager(id)
    }
}