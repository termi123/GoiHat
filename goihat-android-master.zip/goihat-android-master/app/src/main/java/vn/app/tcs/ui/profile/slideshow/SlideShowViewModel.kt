package vn.app.tcs.ui.profile.slideshow

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.data.karaconstant.EventConstant

class SlideShowViewModel : BaseViewModel() {
    var progress = MutableLiveData<String>()

    fun doClose() = sendEvent(EventConstant.EVENT_FINISH)

    fun doNext() = sendEvent(EventConstant.EVENT_NEXT)

    fun doPrevious() = sendEvent(EventConstant.EVENT_PREVIOUS)
}