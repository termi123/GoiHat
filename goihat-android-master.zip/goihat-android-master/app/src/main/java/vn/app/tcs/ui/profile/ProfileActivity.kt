package vn.app.tcs.ui.profile

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.bumptech.glide.Glide
import com.tbruyelle.rxpermissions2.RxPermissions
import kotlinx.android.synthetic.main.activity_add_bar.ivUpload
import kotlinx.android.synthetic.main.activity_profile.*
import org.jetbrains.anko.toast
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ImageStaff
import vn.app.tcs.data.model.ImageStaffType
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.ActivityProfileBinding
import vn.app.tcs.ui.profile.adapter.ImageStaffAdapter
import vn.app.tcs.ui.profile.adapter.PickImageType
import vn.app.tcs.ui.profile.adapter.PickerImageStaffAction
import vn.app.tcs.utils.imagepicker.ImagePicker
import java.io.File
import java.util.*


class ProfileActivity : BaseKaraToolbarActivity<ActivityProfileBinding, ProfileViewModel>()
    , BaseAdapter.OnClickItemListener<WrapperImageStaff> {

    override fun getToolBar(): Toolbar = toolbar
    override val layoutId: Int
        get() = R.layout.activity_profile
    override val viewModel: ProfileViewModel by viewModel()

    private val MAX_IMAGE = 5;
    private val PICK_AVATAR = "PICK_AVATAR";
    private val PICK_IMAGE_STAFF = "PICK_IMAGE_STAFF";
    private var imagePicker: ImagePicker? = null
    private val imageStaffAdapter: ImageStaffAdapter by lazy {
        ImageStaffAdapter(
            this, arrayListOf(
                WrapperImageStaff(null)
            )
        ).apply { setOnClickListener(this@ProfileActivity) }
    }

    override fun setUpObserver() {
        super.setUpObserver()
        initListImage()
        viewModel.updateProfile.observe(this, androidx.lifecycle.Observer {})
        viewModel.profile.observe(this,androidx.lifecycle.Observer { profile ->
            profile.galleries.reversed().forEach {
                imageStaffAdapter.list.add(imageStaffAdapter.list.size - 1,
                    WrapperImageStaff.fromImageStaffResponse(it))
            }
            imageStaffAdapter.notifyDataSetChanged()
        })
    }

    private fun handleUpdateProfile() {
        if (TextUtils.isEmpty(etUserName.text.toString())) {
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    AppConstant.EMPTY_USERNAME
                )
            )
            return
        }
        if (etUserName.text.toString().trim().run {
                length < 1 || length > 16
            }) {
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    AppConstant.WRONG_USERNAME
                )
            )
            return
        }

        viewModel.updateRequest.apply {
            name = etUserName.text.toString()
            images = imageStaffAdapter.getUploadImage()
            gallery_ids = viewModel.deleteIds
        }
        viewModel.updateProfile()
    }

    @SuppressLint("CheckResult")
    private fun handlePickImage(tagPick: String) {
        RxPermissions(this).request(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
            .subscribe { granted ->
                if (granted) {
                    imagePicker = ImagePicker(this).apply { tag = tagPick }
                    imagePicker?.apply {
                        setListener(object : ImagePicker.ImagePickerListener {
                            override fun onPickSuccess(uri: Uri?, tag: String) {
                                if (tag == PICK_AVATAR) {
                                    viewModel.updateRequest.avatarFile = File(uri?.path)
                                    Glide.with(this@ProfileActivity)
                                        .load(viewModel.updateRequest.avatarFile)
                                        .into(ivUpload)
                                    return
                                }
                                if (tag == PICK_IMAGE_STAFF) {
                                    when (viewModel.currentPickTag.type) {
                                        PickImageType.PICK_NEW_IMAGE -> {
                                            imageStaffAdapter.list.add(
                                                imageStaffAdapter.list.size - 1,
                                                WrapperImageStaff(
                                                    ImageStaff(uri!!, true),
                                                    ImageStaffType.IMAGE_LOCAL
                                                )
                                            )
                                            imageStaffAdapter.notifyDataSetChanged()
                                        }
                                        PickImageType.EDIT -> {

                                        }
                                    }
                                }
                            }
                        })
                        setAuthority("vn.app.tcs.provider")
                        needCropAfterPick(true)
                        showAlertDialog()
                    }
                } else {
                    toast("need read external permission")
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        imagePicker?.onActivityResult(imagePicker!!, requestCode, resultCode, data)
    }


    private fun initListImage() {
        rvImageStaff.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rvImageStaff.adapter = imageStaffAdapter
    }

    override fun onClickItem(item: WrapperImageStaff, position: Int) {
        if (position == MAX_IMAGE ) {
            showDialogMessage(MessageDialog(content = "Bạn chỉ có thể chọn tối đa $MAX_IMAGE ảnh"))
            return
        }

        if(!item.isAddItem()) return
        viewModel.doPickImage(
            PickerImageStaffAction(
                if (item.type == ImageStaffType.ADD_IMAGE) PickImageType.PICK_NEW_IMAGE else PickImageType.EDIT,
                item, position
            )
        )
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_PICK_IMAGE -> handlePickImage(PICK_AVATAR)
            EventConstant.EVENT_PICK_IMAGE_STAFF -> handlePickImage(PICK_IMAGE_STAFF)
            EventConstant.EVENT_UPDATE_PROFILE -> handleUpdateProfile()
            EventConstant.EVENT_UPDATE_PROFILE_SUCCESS -> {
                RxBus.publish(RxEvent.UpdateProfileEvent())
                finish()
            }
        }
    }

}
