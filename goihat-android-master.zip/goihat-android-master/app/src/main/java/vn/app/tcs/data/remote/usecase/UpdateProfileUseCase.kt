package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.UserManagerRepository
import vn.app.tcs.data.request.UpdateProfileRequest

class UpdateProfileUseCase : UseCase<UserProfile>() {
    lateinit var updateProfileRequest: UpdateProfileRequest
    private val userManagerRepository: UserManagerRepository by inject()

    override fun buildUseCaseObservable(): Single<UserProfile> {
        return userManagerRepository.updateProfile(updateProfileRequest)
    }
}