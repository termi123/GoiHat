package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.POST
import retrofit2.http.Query
import vn.app.tcs.data.model.Bar

interface RoomManagementSource {
    @POST("/api/rooms/register")
    fun registerRoom(
        @Query("bar_id") bar_id: Int,
        @Query("rooms[]") listStaff: List<String>
    ): Single<Bar.ListRoom>

    @POST("/api/rooms/update")
    fun updateRoom(
        @Query("bar_id") bar_id: Int,
        @Query("rooms[]") listStaff: String
    ): Single<Bar.ListRoom>

    @POST(value = "/api/rooms/delete")
    fun deleteRoom(
        @Query("rooms[]") listStaff: List<Int>
    ): Single<ArrayList<String>>
}