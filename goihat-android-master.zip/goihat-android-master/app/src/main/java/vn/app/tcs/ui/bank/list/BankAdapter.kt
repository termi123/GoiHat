package vn.app.tcs.ui.bank.list

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import vn.app.tcs.R
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.databinding.ItemListBankBinding

class BankAdapter(data: ArrayList<ListBank.Bank>) : BaseAdapter<ListBank.Bank>(data) {

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return BankViewHolder(parent?.inflateExt(R.layout.item_list_bank)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BankViewHolder) {
            holder.onBind(list[position])
            Glide.with(holder.binding.ivBg).load(R.drawable.bank_bg)
                .apply(RequestOptions())
                .into(holder.binding.ivBg)
            Glide.with(holder.binding.ivIcon).load(R.drawable.ic_tcs)
                .apply(RequestOptions())
                .into(holder.binding.ivIcon)
            Glide.with(holder.binding.ivEdit).load(R.drawable.ic_edit)
                .apply(RequestOptions())
                .into(holder.binding.ivEdit)
        }

    }

    class BankViewHolder(view: View) : BaseViewHolder<ListBank.Bank, ItemListBankBinding>(view) {
        override fun onBind(item: ListBank.Bank) {
            binding.bank = item
        }

    }
}
