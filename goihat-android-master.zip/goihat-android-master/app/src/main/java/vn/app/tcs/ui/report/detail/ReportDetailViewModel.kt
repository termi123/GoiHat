package vn.app.tcs.ui.report.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant.EVENT_REJECT_ORDER_ACCEPT
import vn.app.tcs.data.karaconstant.EventConstant.EVENT_REJECT_ORDER_DENY
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.data.remote.usecase.RejectOrderUseCase
import vn.app.tcs.data.request.RejectOrderRequest

class ReportDetailViewModel : BaseViewModel() {
    private val rejectOrderUseCase: RejectOrderUseCase by inject()
    var order = MutableLiveData<ListRejectOrder.RejectOrder>()
    var rejectOrder: LiveData<List<String>>

    init {
        rejectOrder = Transformations.map(rejectOrderUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun rejectOrder(confirm : String) {
        rejectOrderUseCase.apply {
            request = RejectOrderRequest(order.value!!.id, confirm)
        }.execute()
    }

    fun accept() {
        sendEvent(EVENT_REJECT_ORDER_ACCEPT)
    }

    fun deny() {
        sendEvent(EVENT_REJECT_ORDER_DENY)
    }
}