package vn.app.tcs.data.request

import vn.app.tcs.data.model.UserProfile
import java.io.File

class UpdateProfileRequest : UserProfile.BasicProfile() {
    var avatarFile: File? = null
    var gallery_ids = ArrayList<Int>()
    var images = ArrayList<File>()

    fun needCreateBody() : Boolean{
        return avatarFile != null || images.isNotEmpty()
    }

}