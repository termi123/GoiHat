package vn.app.tcs.data.model


import com.base.common.constant.AppConstant
import com.google.gson.annotations.SerializedName

data class DetailOrderStaff(
    @SerializedName("order_id")
    val orderId: Int,
    @SerializedName("bar")
    val bar: Bar,
    @SerializedName("manager")
    val manager: Manager,
    @SerializedName("room")
    val room: vn.app.tcs.data.model.Bar.Room,
    @SerializedName("status")
    var status: String?,
    @SerializedName("approved_at")
    val approvedAt: String,
    @SerializedName("canceled_at")
    val canceledAt: String,
    @SerializedName("rejected_at")
    val rejectedAt: String,
    @SerializedName("processing_at")
    val processingAt: String,
    @SerializedName("complete_at")
    val completeAt: String,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("description")
    val description: String?
) {

    fun hasDescription(): Boolean {
        return !description.isNullOrBlank()
    }

    fun getStaffStatus(): String {
        if (AppConstant.Status.from(status) == null) return ""
        return AppConstant.Status.from(status)!!.status
    }

    fun getStaffStatusDes(): String {
        if (AppConstant.Status.from(status) == null) return ""
        return AppConstant.Status.from(status)!!.des
    }
    data class Bar(
        @SerializedName("id")
        val id: Int,
        @SerializedName("name")
        val name: String,
        @SerializedName("address")
        val address: String,
        @SerializedName("latitude")
        val latitude: String,
        @SerializedName("longitude")
        val longitude: String,
        @SerializedName("discount")
        val discount: Int,
        @SerializedName("description")
        val description: String,
        @SerializedName("avatar")
        val avatar: Any,
        @SerializedName("manager_id")
        val managerId: Int,
        @SerializedName("created_at")
        val createdAt: String,
        @SerializedName("fee")
        val fee: String
    )

    data class Manager(
        @SerializedName("id")
        val id: Int,
        @SerializedName("code")
        val code: String,
        @SerializedName("referral_code")
        val referralCode: String,
        @SerializedName("name")
        val name: String,
        @SerializedName("phone")
        val phone: String,
        @SerializedName("avatar")
        val avatar: Any,
        @SerializedName("birthday")
        val birthday: Any,
        @SerializedName("gender")
        val gender: String,
        @SerializedName("address")
        val address: Any,
        @SerializedName("role")
        val role: String,
        @SerializedName("created_at")
        val createdAt: String
    )
}