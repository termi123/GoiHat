package vn.app.tcs.ui.managerhome

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetListBarUseCase
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.usermanager.UserManager

class FragmentManagerHomeViewModel : BaseViewModel() {
    val userManager: UserManager by inject()
    var bars: LiveData<ListBar?>
    var profile = MutableLiveData<UserProfile.Profile>()
    private val getProfileUseCase: GetProfileUseCase by inject()


    private val getListBarUseCase: GetListBarUseCase by inject()

    init {
        bars = Transformations.map(getListBarUseCase.result) {
            handleCommonApi(it)
        }
    }


    fun getListBar() {
        getListBarUseCase.apply { id = userManager.getUserInfo()?.id.toString() }.execute()
    }

    fun doAddBar() = sendEvent(EventConstant.EVENT_ADD_BAR)

    fun callStaff() = sendEvent(EventConstant.EVENT_CALL_STAFF)

    fun updateProfile() {
        profile.value = userManager.getUserInfo()
    }

    fun getProfile() {
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
        }, {})
    }


    fun copyCode() {
        sendEvent(EventConstant.EVENT_COPY)
    }
}