package vn.app.tcs.ui.staffhome

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.core.content.ContextCompat
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.fragment.BaseMVVMFragment
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_staff_detail.*
import kotlinx.android.synthetic.main.staff_home_fragment.*
import kotlinx.android.synthetic.main.staff_home_fragment.ivDefault
import kotlinx.android.synthetic.main.staff_home_fragment.llStatus
import kotlinx.android.synthetic.main.staff_home_fragment.rvImageStaff
import kotlinx.android.synthetic.main.staff_home_fragment.spStatus
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.startActivity
import org.jetbrains.anko.support.v4.toast
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ImageStaffResponse
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.StaffHomeFragmentBinding
import vn.app.tcs.ui.changemanagercode.ChangeManagerCodeActivity
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.profile.ProfileActivity
import vn.app.tcs.ui.profile.slideshow.SlideShowActivity
import vn.app.tcs.ui.staffdetail.ImageViewStaffAdapter
import vn.app.tcs.utils.TimeUtil

class StaffHomeFragment : BaseMVVMFragment<StaffHomeFragmentBinding, StaffHomeViewModel>(),
    BaseAdapter.OnClickItemListener<WrapperImageStaff> {
    override fun onClickItem(item: WrapperImageStaff, position: Int) {
        startActivity<SlideShowActivity>(
            EventConstant.KEY_LIST_IMAGE to viewModel.profile.value?.galleries,
            EventConstant.KEY_LIST_IMAGE_POSITION to position
        )
    }

    override val layoutId: Int
        get() = R.layout.staff_home_fragment
    override val viewModel: StaffHomeViewModel by inject()
    private val imageStaffAdapter: ImageViewStaffHomeAdapter by lazy {
        ImageViewStaffHomeAdapter(
            activity!!, this@StaffHomeFragment, arrayListOf(
                WrapperImageStaff(null)
            )
        )
    }
    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_CALL -> {
                showContactInfo()
            }
            EventConstant.EVENT_COPY -> {
                TimeUtil.setClipboard(viewModel.profile.value?.code)
                (activity as MainActivity).showDialog2ButtonMessage(
                    MessageDialog(
                        "Thông báo", "Mã số của bạn dùng để:<br><br>" +
                                "1: Đưa vào Nội dung chuyển tiền. Số tiền sẽ được nạp vào tài khoản của Mã số này.<br><br>" +
                                "2: Dùng để giới thiệu bạn bè. Khi giới thiệu mỗi người vào \"Hệ thống\", bạn sẽ được cộng 100⭐ vào Tài khoản phụ.",
                        "Huỷ", "Chia sẻ"
                    ).apply {
                        tag = "GUIDE"
                    }
                )
            }
            EventConstant.EVENT_COPY_USER -> {
                TimeUtil.setClipboard(viewModel.profile.value?.ownerCode)
            }
            EventConstant.EVENT_CHANGE_NEW_CODE -> {
                startActivity<ChangeManagerCodeActivity>()
            }
            EventConstant.EVENT_EDIT_DIALOG -> {
                startActivity<ProfileActivity>()
            }
            EventConstant.EVENT_SHOW_ALBUM -> {
                startActivity<SlideShowActivity>(
                    EventConstant.KEY_LIST_IMAGE to viewModel.profile.value?.getAvatarGallery(),
                    EventConstant.KEY_LIST_IMAGE_POSITION to 0
                )
            }
        }
    }

    private fun showContactInfo() {
        Handler().postDelayed({
            (activity as BaseKaraActivity<*, *>).showDialogMessage(
                MessageDialog(
                    getString(R.string.contact_info),
                    "Chủ TK : Bùi Thị Thu Uyên<br>STK : <u><font color=#FF0000>19034505336014</font></u><br>Ngân hàng : TECHCOMBANK<br>Chi nhánh : Hà Nội.<br>Nội dung chuyển tiền: " + viewModel.profile.value?.code,
                    "OK"
                ).apply {
                    tag = "NapTien"
                }
            )
        }, 200)
    }

    @SuppressLint("CheckResult")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initSpinnerAdapter()
        addDisposable(RxEvent.UpdateProfileEvent::class.java) {
            viewModel.updateProfile()
        }

        addDisposable(RxEvent.GetProfileEvent::class.java) {
            viewModel.getProfile()
        }
        initListImage()
    }

    override fun observerData() {
        super.observerData()
        viewModel.profile.observe(viewLifecycleOwner, Observer { profile ->
            profile?.let {
                viewModel.status.value = it.activity

                val list = it.galleries
                val listWrap = arrayListOf<WrapperImageStaff>()
                for (item : ImageStaffResponse in list) {
                    listWrap.add(WrapperImageStaff.fromImageStaffResponse(item))
                }
                if (!listWrap.isNullOrEmpty()) {
                    rvImageStaff.visibility = View.VISIBLE
                    ivDefault.visibility = View.GONE
                    imageStaffAdapter.list = listWrap
                    imageStaffAdapter.notifyDataSetChanged()
                }
            }
        })
        viewModel.status.observe(viewLifecycleOwner, Observer {
            it?.let { status ->
                run {
                    if (activity is MainActivity) {
                        (activity as MainActivity).updateStatusMenu(status == AppConstant.Activity.Online.name)
                    }
                    spStatus.post { spStatus.text = getStatus(it) }
                    llStatus.post {
                        when {
                            viewModel.status.value == "Online" -> llStatus.background =
                                ContextCompat.getDrawable(
                                    requireContext(),
                                    R.drawable.bg_rounder_black_green
                                )
                            viewModel.status.value == "Offline" -> llStatus.background =
                                ContextCompat.getDrawable(
                                    requireContext(),
                                    R.drawable.bg_round_gray_2
                                )
                            else -> llStatus.background = ContextCompat.getDrawable(
                                requireContext(),
                                R.drawable.bg_rounder_yellow
                            )
                        }
                    }
                }
            }
        })
        viewModel.setDatabaseListener((activity as BaseKaraActivity<*, *>).database)
        viewModel.updateActivty.observe(viewLifecycleOwner, Observer {

        })

    }

    private fun initListImage() {
        rvImageStaff.layoutManager = LinearLayoutManager(activity, RecyclerView.HORIZONTAL, false)
        rvImageStaff.adapter = imageStaffAdapter
        imageStaffAdapter.setOnClickListener(this)
    }

    fun getStatus(status: String) = when (status) {
        "Online" -> "Online"
        "Offline" -> "Offline"
        "Selecting" -> "Đang được chọn"
        else -> ""
    }

    override fun onResume() {
        super.onResume()
        viewModel.getProfile()
    }

    private fun initSpinnerAdapter() {
        spStatus.setOnClickListener {
            showConfirmDialog()
        }
    }

    private fun showConfirmDialog() {
        when (spStatus.text) {
            AppConstant.Activity.Online.name -> (activity as MainActivity).showDialog2ButtonMessage(
                MessageDialog(
                    content = "Bạn có chắc muốn chuyển trạng thái sang Offline hay không?",
                    tag = AppConstant.Activity.Offline.name,
                    title = getString(
                        R.string.change_status
                    ),
                    confirmButton = "HUỶ",
                    cancelButton = "OK"
                )
            )
            "Đang được chọn" -> (activity as MainActivity).showDialog2ButtonMessage(
                MessageDialog(
                    content = "Bạn có chắc muốn chuyển trạng thái sang Offline hay không?",
                    tag = AppConstant.Activity.Offline.name,
                    title = getString(
                        R.string.change_status
                    ),
                    confirmButton = "HUỶ",
                    cancelButton = "OK"
                )
            )
            AppConstant.Activity.Selecting.name -> (activity as MainActivity).showDialog2ButtonMessage(
                MessageDialog(
                    content = "Bạn có chắc muốn chuyển trạng thái sang Offline hay không?",
                    tag = AppConstant.Activity.Offline.name,
                    title = getString(
                        R.string.change_status
                    ),
                    confirmButton = "HUỶ",
                    cancelButton = "OK"
                )
            )
            AppConstant.Activity.Offline.name -> (activity as MainActivity).showDialog2ButtonMessage(
                MessageDialog(
                    content = "Bạn có chắc muốn chuyển trạng thái sang Online hay không?",
                    tag = AppConstant.Activity.Online.name,
                    title = getString(
                        R.string.change_status
                    ),
                    confirmButton = "HUỶ",
                    cancelButton = "OK"
                )
            )
            AppConstant.Activity.Moving.name -> (activity as MainActivity).showDialogMessage(
                MessageDialog(content = "Bạn không thể thay đổi trạng thái này.")
            )
            AppConstant.Activity.Ondesk.name -> (activity as MainActivity).showDialogMessage(
                MessageDialog(content = "Bạn không thể thay đổi trạng thái này.")
            )
        }
    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        event?.tag.let {
            it?.let { tag ->
                if (tag == "CallSupport") {
                    toast("Đã sao chép số tài khoản")
                    TimeUtil.setClipboard("19034505336014")
                    return
                }
                if (tag == "NapTien") {
                    TimeUtil.setClipboard("19034505336014")
                    return
                }
                if (tag == AppConstant.Activity.Offline.name || tag == AppConstant.Activity.Online.name) {
                    viewModel.updateActivity(tag)
                }

            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
//        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Back -> {
                event.tag.let {
                    if (it == "GUIDE") {
                        val intent2 = Intent()
                        intent2.action = Intent.ACTION_SEND
                        intent2.type = "text/plain"
                        intent2.putExtra(Intent.EXTRA_TEXT, viewModel.profile.value?.code)
                        startActivity(Intent.createChooser(intent2, "Chia sẻ mã số của bạn"))
                        return@let
                    }
                    if (it == AppConstant.Activity.Offline.name || it == AppConstant.Activity.Online.name) {
                        viewModel.updateActivity(it)
                    }
                }
            }
            else -> {
            }
        }
    }

    companion object {
        val TAG = StaffHomeFragment::class.java.simpleName
        fun newInstance(): StaffHomeFragment {
            return StaffHomeFragment()
        }
    }

}
