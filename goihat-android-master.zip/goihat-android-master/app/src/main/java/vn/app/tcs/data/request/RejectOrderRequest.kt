package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class RejectOrderRequest (
    @SerializedName("order_report_id")
    var order_report_id: Int = 0,
    @SerializedName("confirm")
    var confirm: String = "" //Available values : Y, N
)