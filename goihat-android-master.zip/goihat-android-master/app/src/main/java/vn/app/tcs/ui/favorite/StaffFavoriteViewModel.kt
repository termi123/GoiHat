package vn.app.tcs.ui.favorite

import androidx.lifecycle.Transformations
import com.base.common.constant.AppConstant
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.base.LoadingState
import vn.app.tcs.data.remote.usecase.FavoriteUseCase
import vn.app.tcs.data.remote.usecase.GetFavoriteStaffUseCase
import vn.app.tcs.data.request.FavoriteOptionRequest

class StaffFavoriteViewModel : BaseListViewModel() {
    private val getFavoriteStaffUseCase: GetFavoriteStaffUseCase by inject()

    private val favoriteUseCase: FavoriteUseCase by inject()
    var favoriteRequest = Transformations.map(favoriteUseCase.result) {
        handleCommonApi(it)
    }

    var favorite = Transformations.map(getFavoriteStaffUseCase.result) {
        handleStateCommonApi(it)
    }


    override fun loadData() {
        super.loadData()
        getListFavorite()
    }

    fun getListFavorite() {
        getFavoriteStaffUseCase.apply {
            favoriteOptionRequest = FavoriteOptionRequest(page.toString(), "Full")
        }.executeZip({
            page++
            isEmpty.value = (stateLoading == LoadingState.INIT || stateLoading == LoadingState.REFRESH) && it.staff.isNullOrEmpty()
        }, {})
    }
}