package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.ListBank

interface BankRepository {
    fun getListBank(): Single<ListBank>

    fun registerBank(bank : ListBank.BankInfo): Single<List<String>>

    fun updateBank(id: Int, bank: ListBank.BankInfo): Single<List<String>>

    fun getBankDetail(id: Int): Single<ListBank.Bank>

    fun deleteBank(id: Int): Single<List<String>>
}
class BankRepositoryImpl (private val bankManagement: BankManagement) :
    BankRepository {
    override fun getListBank(): Single<ListBank> {
        return bankManagement.getListBank()
    }

    override fun registerBank(bank: ListBank.BankInfo): Single<List<String>> {
        return bankManagement.registerBank(bank)
    }

    override fun updateBank(id: Int, bank: ListBank.BankInfo): Single<List<String>> {
        return bankManagement.updateBank(id, bank)
    }

    override fun getBankDetail(id: Int): Single<ListBank.Bank> {
        return bankManagement.getBankDetail(id)
    }

    override fun deleteBank(id: Int): Single<List<String>> {
        return bankManagement.deleteBank(id)
    }
}