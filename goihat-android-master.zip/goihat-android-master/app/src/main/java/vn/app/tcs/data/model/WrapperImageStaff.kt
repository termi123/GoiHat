package vn.app.tcs.data.model

import android.net.Uri
import java.util.*

class WrapperImageStaff(
    var imageStaff: ImageStaff?,
    var type: ImageStaffType = ImageStaffType.ADD_IMAGE,
    var id: Int = Random().nextInt()
) {
    fun isAddItem() = type == ImageStaffType.ADD_IMAGE

    companion object {
        fun fromImageStaffResponse(imageStaffResponse: ImageStaffResponse): WrapperImageStaff {
            return WrapperImageStaff(
                ImageStaff(Uri.parse(imageStaffResponse.thumb), false, imageStaffResponse.id),
                ImageStaffType.IMAGE_NET
            )
        }
    }
}

enum class ImageStaffType {
    ADD_IMAGE, IMAGE_LOCAL, IMAGE_NET;
}