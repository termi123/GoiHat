package vn.app.tcs.base.adapter

import android.util.SparseArray
import androidx.core.util.contains
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import vn.app.tcs.base.BaseItemViewModel

abstract class BaseVMAdapter <T,VM : BaseItemViewModel<*>> ( list: ArrayList<T>) : BaseAdapter<T>(list){
    val viewModelProvide = SparseArray<VM>()

}