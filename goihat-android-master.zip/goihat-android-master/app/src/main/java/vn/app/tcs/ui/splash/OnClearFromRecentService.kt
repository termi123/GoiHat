package vn.app.tcs.ui.splash

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import org.koin.android.ext.android.inject
import vn.app.tcs.data.usermanager.UserManager

class OnClearFromRecentService : Service() {
//    val updateActivityUseCase: UpdateActivityUseCase by inject()
    val userManager: UserManager by inject()

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        Log.d("ClearFromRecentService", "Service Started")
        return Service.START_NOT_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ClearFromRecentService", "Service Destroyed")
    }

    override fun onTaskRemoved(rootIntent: Intent) {
        Log.e("ClearFromRecentService", "END")
//        SharedPreUtils.putBoolean("APP_START", false)
//        if (userManager.getUserInfo()?.role == AppConstant.Role.Staff.name) {
//            updateActivityUseCase.apply {
//                this.activity = AppConstant.Activity.Offline.name
//            }.execute()
//        }
        stopSelf()
    }
}