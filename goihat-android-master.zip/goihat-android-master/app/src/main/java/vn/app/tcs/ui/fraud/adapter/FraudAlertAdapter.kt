package vn.app.tcs.ui.fraud.adapter

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.Order
import vn.app.tcs.databinding.ItemFraudAlertBinding

class FraudAlertAdapter(data: ArrayList<Order>) : BaseAdapter<Order>(data) {

    lateinit var onActionFraudListener: OnActionFraudListener

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return FraudAlertViewHolder(parent?.inflateExt(R.layout.item_fraud_alert)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is FraudAlertViewHolder) {
        }
    }

    class FraudAlertViewHolder(view: View) : BaseViewHolder<Order, ItemFraudAlertBinding>(view) {
        override fun onBind(item: Order) {
            binding.order = item
        }

    }

    interface OnActionFraudListener {
        fun onEdit(position: Int)
    }
}

