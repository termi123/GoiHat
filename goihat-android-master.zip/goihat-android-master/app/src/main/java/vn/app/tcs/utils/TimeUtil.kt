package vn.app.tcs.utils


import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import vn.app.tcs.KaraApplication
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit


/**
 * Created by dell on 04/02/2018.
 */

class TimeUtil {
    companion object {
        var listDayVi = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")

        val DATE_FORMAT_7 = "dd/MM/yyyy"
        val DATE_FORMAT_INCOME = "dd-MM-yyyy"
        val DATE_FORMAT_BIRTHDAY = "yyyy-MM-dd"
        val DATE_FOMART_EVENT = "yyyy-MM-dd HH:mm:ss"
        val DATE_FOMART_UTC = "yyyy-MM-dd'T'HH:mm:ss.SSSSS'Z'"
        val DATE_FOMART_EVENT_ORDER = "HH-mm dd/MM/yyy"
        val DATE_FOMART_NOTI = "HH:mm dd/MM/yyy"

        fun getDayNameVi(dayOfWeek: Int): String {
            if (dayOfWeek < 1 || dayOfWeek > 8) return ""
            return listDayVi[dayOfWeek - 1]
        }

        fun getTime(time: Date): String {
            val sdfDate = SimpleDateFormat("dd MMMM, yyyy", Locale("vi"))
            return sdfDate.format(time)
        }

        fun isToday(calendar: Calendar): Boolean {
            val today = Calendar.getInstance()
            return (calendar.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH)
                    && calendar.get(Calendar.MONTH) == today.get(Calendar.MONTH)
                    && calendar.get(Calendar.YEAR) == today.get(Calendar.YEAR))
        }


        fun convertCalToString(date: Calendar?, str: String): String {
            if(date == null) return SimpleDateFormat(str, Locale.getDefault()).format(Calendar.getInstance().time)
            return SimpleDateFormat(str, Locale.getDefault()).format(date.time)
        }

        fun convertDateForEvent(str: String, format: String): Date {
            return SimpleDateFormat(format, Locale.getDefault()).parse(str)
        }

        fun isSameDay(cal1 : Calendar,cal2 : Calendar): Boolean {
            return cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
                    cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
        }

        fun convertCalendarForEvent(str: String, format: String): Calendar? {
            if(str.isEmpty()) return Calendar.getInstance()
            return Calendar.getInstance().apply {
                time = SimpleDateFormat(format, Locale.getDefault()).parse(str)
            }
        }

        fun convertNumberToCalendar(year : Int, monthOfYear : Int, dayOfMonth : Int): Calendar? {
            return Calendar.getInstance().apply {
                set(Calendar.YEAR,year)
                set(Calendar.MONTH,monthOfYear)
                set(Calendar.DAY_OF_MONTH,dayOfMonth)
            }
        }

        fun convertDateForEvent(str: String): Date {
            return SimpleDateFormat(DATE_FOMART_EVENT, Locale.getDefault()).parse(str)
        }

        fun getTimeForEvent(str: String): String {
            val date = SimpleDateFormat(DATE_FOMART_EVENT, Locale.getDefault()).parse(str)
            val cal = Calendar.getInstance()
            cal.time = date
            return "" + cal.get(Calendar.DAY_OF_MONTH) + "/ " + (cal.get(java.util.Calendar.MONTH) + 1) + " " + cal.get(
                java.util.Calendar.YEAR
            )
        }

        fun milliSecondToDate(second: Long, format: String): String? {
            return try {
                val cal = Calendar.getInstance()
                cal.timeInMillis = second * 1000
                SimpleDateFormat(format, Locale.getDefault()).format(cal.time)
            } catch (e: Exception) {
                ""
            }
        }

        fun convertFormatOrder(str: String?, format: String): String {
            if (str.isNullOrBlank()) return ""
            val date = SimpleDateFormat(DATE_FOMART_EVENT, Locale.getDefault()).parse(str)
            val desDate = SimpleDateFormat(format, Locale.getDefault()).format(date)
            return desDate
        }

        fun convertFormatOrderCall(str: String?, format: String): String {
            if (str.isNullOrBlank()) return ""
            return try {
                val date = SimpleDateFormat(DATE_FOMART_UTC, Locale.getDefault()).parse(str)
                val desDate = SimpleDateFormat(format, Locale.getDefault()).format(date)
                desDate
            } catch (e: Exception) {
                e.printStackTrace()
                ""
            }

        }

        fun getDifferenceDays(d1: Date, d2: Date): Long {
            val diff = d2.time - d1.time
            return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)
        }

        fun getDifferenceTime(d1: Calendar, d2: Calendar): Long {
            return d2.time.time - d1.time.time
        }

        @SuppressLint("ObsoleteSdkInt")
        fun setClipboard(text: String?) {
            if (text.isNullOrBlank()) return
            if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
                val clipboard =
                    KaraApplication.instance?.getSystemService(Context.CLIPBOARD_SERVICE) as android.text.ClipboardManager
                clipboard.text = text
            } else {
                val clipboard =
                    KaraApplication.instance?.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = android.content.ClipData.newPlainText("Copied Text", text)
                clipboard.primaryClip = clip
            }
            Toast.makeText(KaraApplication.instance, "Đã copy: $text", Toast.LENGTH_LONG).show()
        }
    }

}
