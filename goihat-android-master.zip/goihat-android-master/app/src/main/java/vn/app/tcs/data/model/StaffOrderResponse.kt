package vn.app.tcs.data.model

import com.google.gson.annotations.SerializedName

class StaffOrderResponse(
    @SerializedName("success")
    val success: String,
    @SerializedName("order_id")
    val orderId: Int,
    @SerializedName("description")
    val description: String = ""
)