package vn.app.tcs.ui.registerbar

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.remote.usecase.GetRegisteredBarByName
import vn.app.tcs.data.remote.usecase.RegisterBarUserCase

class ListRegisterBarViewModel : BaseViewModel() {
    private val getListBarUseCase: GetRegisteredBarByName by inject()
    var bars: LiveData<ListBar?>

    private val registerBarUseCase: RegisterBarUserCase by inject()
    var addBars: LiveData<List<String>>

    init {
        bars = Transformations.map(getListBarUseCase.result) {
            handleCommonApi(it)
        }
        addBars = Transformations.map(registerBarUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun getListBar(name: String) {
        getListBarUseCase.apply {
            barName = name
        }.execute()
    }

    fun registerBars(list: List<Int>) {
        registerBarUseCase.apply {
            listBar = list
        }.execute()
    }

    fun doAddBar() {
        sendEvent(EventConstant.EVENT_ADD_BAR)
    }
}