package vn.app.tcs.ui.stafforder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil.setContentView
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_staff_order.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.ActivityStaffOrderBinding
import vn.app.tcs.ui.staffdetail.StaffViewModel

class StaffOrderActivity : BaseKaraToolbarActivity<ActivityStaffOrderBinding,StaffOrderViewModel>() {
    override fun getToolBar(): Toolbar {
        return  toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_staff_order
    override val viewModel: StaffOrderViewModel by viewModel()

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when(propertyId){
            EventConstant.EVENT_SEND_STAFF_ORDER -> checkStaffOrder()
            EventConstant.EVENT_STAFF_ORDER -> {
                RxBus.publish(RxEvent.GetStaffRecentActivity())
                finish()
            }
        }
    }

    private fun checkStaffOrder() {
        if (etDescription.text.isNullOrBlank()){
            showDialogMessage(MessageDialog(content = "Vui lòng nhập mô tả yêu cầu"))
            return
        }
        viewModel.order(etDescription.text.toString())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.orderResult.observe(this, Observer {

        })
    }
}
