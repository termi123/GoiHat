package vn.app.tcs.ui.call.detail.manager

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.OrderManagerDetail
import vn.app.tcs.databinding.ItemOrderListBinding

class OrderAdapter(data: ArrayList<OrderManagerDetail.Detail>) : BaseAdapter<OrderManagerDetail.Detail>(data) {

    lateinit var onActionBarListener: OnActionBarListener

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return BarViewHolder(parent?.inflateExt(R.layout.item_order_list)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BarViewHolder) {
            holder.onBind(list[position])
        }

    }

    class BarViewHolder(view: View) : BaseViewHolder<OrderManagerDetail.Detail, ItemOrderListBinding>(view) {
        override fun onBind(item: OrderManagerDetail.Detail) {
            binding.staff = item

        }

    }

    interface OnActionBarListener {
        fun onEdit(position: Int)
    }
}