package vn.app.tcs.ui.splash

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.BuildConfig
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.CheckVersionResponse
import vn.app.tcs.data.model.StaffActivityResponse
import vn.app.tcs.data.remote.usecase.CheckVersionUseCase
import vn.app.tcs.data.remote.usecase.GetStaffActivityUseCase
import vn.app.tcs.data.request.CheckVersionRequest
import vn.app.tcs.data.usermanager.UserManager

class SplashViewModel : BaseViewModel() {
    private val userManager: UserManager by inject()
    private val checkVersionUseCase: CheckVersionUseCase by inject()
    private val getStaffActivityUseCase: GetStaffActivityUseCase by inject()

    var checkVersionRequest: LiveData<CheckVersionResponse> = Transformations.map(checkVersionUseCase.result) {
        handleCommonApi(it)
    }
    var getStaffActivityRequest: LiveData<StaffActivityResponse> = Transformations.map(getStaffActivityUseCase.result) {
        handleCommonApi(it)
    }

    fun checkAccessToken() =
        sendEvent(if (userManager.isUserLoggedIn()) EventConstant.EVENT_MAIN else EventConstant.EVENT_LOGIN)

    fun getRole() = userManager.getUserInfo()?.role

    fun checkVersion() {
        checkVersionUseCase.apply {
            checkVersionRequest = CheckVersionRequest(
                BuildConfig.VERSION_NAME,
                "android"
            )
        }.execute()
    }

    fun getStaffActivity() {
        getStaffActivityUseCase.execute()
    }
}