package vn.app.tcs.ui.report.list

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.ListBlackList
import vn.app.tcs.databinding.ItemListBlackListBinding

class BlackListAdapter(data: ArrayList<ListBlackList.BlackList>) :
    BaseAdapter<ListBlackList.BlackList>(data) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffViewHolder(parent?.inflateExt(R.layout.item_list_black_list)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffViewHolder) {
            holder.onBind(list[position])
        }

    }

    class StaffViewHolder(view: View) :
        BaseViewHolder<ListBlackList.BlackList, ItemListBlackListBinding>(view) {
        override fun onBind(item: ListBlackList.BlackList) {
            binding.notify = item
        }

    }
}