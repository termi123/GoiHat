package vn.app.tcs.ui.notify

class NotifyViewModel : BaseNotifyViewModel() {
    override val categoryNoti: String? = null
}
