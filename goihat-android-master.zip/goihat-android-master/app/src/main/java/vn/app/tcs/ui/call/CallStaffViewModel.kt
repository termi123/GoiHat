package vn.app.tcs.ui.call

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.remote.usecase.CheckSurveyUseCase

class CallStaffViewModel : BaseViewModel() {

    private val setSurveyUseCase: CheckSurveyUseCase by inject()
    var selectedBar: Int = 0
    var selectedRoom: Bar.Room? = null
    var listBar = emptyList<Bar>()

    var setSurveyRequest: LiveData<List<String>>

    init {
        setSurveyRequest = Transformations.map(setSurveyUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun setSurvey(barId: Int, roomId: Int) = setSurveyUseCase.apply {
        this.barId = barId
        this.roomId = roomId
    }.execute()

    fun selectWantCall() = sendEvent(EventConstant.KEY_WANT_CALL_STAFF)

    fun selectMaxCall() = sendEvent(EventConstant.KEY_MAX_CALL_STAFF)

    fun findStaff() = sendEvent(EventConstant.EVENT_FIND_STAFF)

    fun pickFee() = sendEvent(EventConstant.EVENT_PICK_FEE)

    fun pickRoom() = sendEvent(EventConstant.EVENT_PICK_ROOM)

}