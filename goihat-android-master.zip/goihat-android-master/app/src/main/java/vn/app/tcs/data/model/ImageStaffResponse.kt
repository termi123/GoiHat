package vn.app.tcs.data.model
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ImageStaffResponse(
    @SerializedName("created_at")
    var createdAt: Int = 0,
    @SerializedName("id")
    var id: String = "",
    @SerializedName("image")
    var path: String = "",
    @SerializedName("thumb")
    var thumb: String = ""
): Parcelable