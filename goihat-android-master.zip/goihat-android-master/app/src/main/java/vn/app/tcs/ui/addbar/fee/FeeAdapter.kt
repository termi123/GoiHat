package vn.app.tcs.ui.addbar.fee

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseHeaderAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.databinding.ItemFeeListBinding

class FeeAdapter(data: ArrayList<String>, header: View) : BaseHeaderAdapter<String>(data, header) {

    lateinit var onClickListener: OnClickItemListener

    fun setOnClickItemListener(onClickListener: OnClickItemListener) {
        this.onClickListener = onClickListener
    }

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == ITEM_VIEW_TYPE_HEADER) {
            return FeeViewHolder(mHeader)
        }
        return FeeViewHolder(parent?.inflateExt(R.layout.item_fee_list)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is FeeViewHolder) {
            if (isHeader(position)) {
                holder.onBind("Không mất phí")
            } else {
                holder.onBind(list[position - 1])
            }
            holder.binding.textView7.setOnClickListener {
                if (::onClickListener.isInitialized) onClickListener.onClick(if (isHeader(position)) "0" else list[position - 1])
            }
        }
    }

    class FeeViewHolder(view: View) : BaseViewHolder<String, ItemFeeListBinding>(view) {
        override fun onBind(item: String) {
            binding.fee = item
        }
    }

    interface OnClickItemListener {
        fun onClick(item: String)
    }
}