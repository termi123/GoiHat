package vn.app.tcs.ui.actionreport.detail

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.OrderInfo
import vn.app.tcs.databinding.ItemOrderInfoBinding

class OrderInfoAdapter(data: ArrayList<OrderInfo>) : BaseAdapter<OrderInfo>(data) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return OrderInfoViewHolder(parent?.inflateExt(R.layout.item_order_info)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is OrderInfoViewHolder) {
            holder.onBind(list[position])
        }

    }

    class OrderInfoViewHolder(view: View) : BaseViewHolder<OrderInfo, ItemOrderInfoBinding>(view) {
        override fun onBind(item: OrderInfo) {
            binding.order = item

        }

    }
}
