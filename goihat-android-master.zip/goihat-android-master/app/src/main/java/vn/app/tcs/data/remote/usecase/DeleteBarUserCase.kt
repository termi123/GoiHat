package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.CallConfigRepository

class DeleteBarUserCase : UseCase<List<String>>() {

    lateinit var listBar: List<Int>

    private val roomManagerRepository: CallConfigRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return roomManagerRepository.deleteBar(listBar)
    }
}