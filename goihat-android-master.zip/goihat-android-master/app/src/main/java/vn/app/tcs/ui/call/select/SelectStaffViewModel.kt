package vn.app.tcs.ui.call.select

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.data.event.Event
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.data.model.OrderResponse
import vn.app.tcs.data.remote.usecase.*
import vn.app.tcs.data.request.FavoriteOptionRequest

class SelectStaffViewModel : BaseListViewModel() {
    //get staff
    private val getStaffAvailableUseCase: GetStaffAvailableUseCase by inject()
    private val getFavoriteStaffUseCase: GetFavoriteStaffUseCase by inject()
    private val unSelectStaffsUseCase: UnSelectStaffsUseCase by inject()

    //favorite
    private val favoriteUseCase: FavoriteUseCase by inject()
    var staffs: LiveData<ListStaff?>
    var tabIndex = MutableLiveData<Int>()
    var avartarStaffShow : ListStaff.Staff? = null
    var isEmptyFavorite = MutableLiveData<Boolean>()
    var isEmptyStaff = MutableLiveData<Boolean>()
    val selectedSet = HashSet<Int>()
//    var wantCallPosition: Int = 0
    var maxCallPosition: Int = 0
    var barID: Int = 0
    var fee: String = "0"
    var itemCall = 0;

    //order staff
    private val orderUseCase: OrderUseCase by inject()
    var call: LiveData<OrderResponse>
    var favorite: LiveData<ListStaff?>
    var favoriteRequest: LiveData<List<String>>
    var favoritePosition: Int = 0

    init {
        staffs = Transformations.map(getStaffAvailableUseCase.result) {
            handleCommonApi(it)
        }
        favorite = Transformations.map(getFavoriteStaffUseCase.result) {
            handleCommonApi(it)
        }
        call = Transformations.map(orderUseCase.result) {
            handleCommonApi(it)
        }
        favoriteRequest = Transformations.map(favoriteUseCase.result) {
            handleCommonApi(it)
        }

    }

    fun getListStaff(_page: Int, refresh: Boolean = false) {
        if(refresh){
            if(selectedSet.isEmpty()) loadStaff(_page) else
            unselectAll {
                loadStaff(_page)
            }
            return
        }
        if (staffs.value != null) {
            sendEvent(EventConstant.EVENT_UPDATE_LIST_STAFF)
            return
        }
        loadStaff(_page)
    }

    private fun loadStaff(_page: Int){
        getStaffAvailableUseCase.apply {
            id = barID
            page = _page
        }.executeZip({
            isEmptyStaff.value = it.staff.isEmpty() && tabIndex.value == 0 && _page == 1
        }, {})
    }

    fun callStaff(listStaff: List<Int>,random : Boolean) {
        orderUseCase.apply {
            id = barID
            this@apply.fee = this@SelectStaffViewModel.fee
//            numberNeeded = wantCallPosition
            numberRequired = maxCallPosition
            isRandom = random
            list = listStaff
        }.execute()
    }

    fun selectStaff() = sendEvent(EventConstant.EVENT_CALL_STAFF)

    fun getListFavorite(_page: Int, refresh: Boolean = false) {
        if(refresh){
            if(selectedSet.isEmpty()) loadFavorite(_page) else
            unselectAll {
                loadFavorite(_page)
            }
            return
        }
        if (favorite.value != null /*&& !needRefreshFavorite*/) {
            sendEvent(EventConstant.EVENT_UPDATE_FAVORITE)
            return
        }
//        needRefreshFavorite = false
        loadFavorite(_page)
    }

    private fun loadFavorite(_page: Int) {
        getFavoriteStaffUseCase.apply {
            favoriteOptionRequest = FavoriteOptionRequest(_page.toString(), "Online",
                barID.toString()
            )
        }.executeZip({
            isEmptyFavorite.value = it.staff.isEmpty() && tabIndex.value == 1 && _page == 1
        }, {})
    }

    fun unselectAll(onUnSelected : () -> Unit) {
        if(selectedSet.isEmpty()) return
        unSelectStaffsUseCase.apply {
            list = ArrayList(selectedSet)
                  }.executeZip({
            onUnSelected.invoke()
            selectedSet.clear()
            itemCall = 0
            sendEvent(EventConstant.RELOAD_STAFF_CALL)
        },{})
    }


}