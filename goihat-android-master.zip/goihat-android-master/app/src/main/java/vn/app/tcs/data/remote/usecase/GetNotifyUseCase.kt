package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.Notify
import vn.app.tcs.data.remote.NotificationRepository

class GetNotifyUseCase : UseCase<Notify>() {
    private val notificationRepository: NotificationRepository by inject()
    var category: String? = null
    var pageNum: Int = 1
    override fun buildUseCaseObservable(): Single<Notify> {
        return notificationRepository.getNotification(category, pageNum)
    }
}