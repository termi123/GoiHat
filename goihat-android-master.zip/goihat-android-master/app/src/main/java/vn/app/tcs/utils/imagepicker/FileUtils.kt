package vn.app.tcs.utils.imagepicker

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Base64
import timber.log.Timber
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.*

class FileUtils private constructor(private val context: Context) {

    fun createImageUri(): Uri? {
        val contentResolver = context.contentResolver
        val cv = ContentValues()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        cv.put(MediaStore.Images.Media.TITLE, timeStamp)
        return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
    }

    /**
     * Create image temp file file.
     *
     * @param filePathDir the file path dir
     * @return the file
     * @throws IOException the io exception
     */
    @SuppressLint("SimpleDateFormat")
    @Throws(IOException::class)
    fun createImageTempFile(filePathDir: File): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())

        val imageFileName = "JPEG_" + timeStamp + "_"
        return File.createTempFile(
            imageFileName, /* prefix */
            ".jpg", /* suffix */
            filePathDir      /* directory */
        )
    }

    interface ImageLoaderListener {
        fun onLoadSuccess(base64: String)
    }

    companion object {

        val JPG_EXTENSION = ".jpeg"
        val NAIL_IMAGE_PREFIX = "WillerImage"
        val NAIL_AVATAR_NAME = "WillerAvatar$JPG_EXTENSION"
        val TYPE_IMAGE = "image"
        val TYPE_VIDEO = "video"
        val TYPE_AUDIO = "audio"
        private val JPEG_FILE_PREFIX = ".jpeg"
        val APP_DIRECTORY_NAME = "WillerApp"

        @SuppressLint("StaticFieldLeak")
        private var sSingleton: FileUtils? = null

        /**
         * Gets instance.
         *
         * @param ctx the ctx
         * @return the instance
         */
        fun getInstance(ctx: Context): FileUtils {
            if (sSingleton == null) {
                synchronized(FileUtils::class.java) {
                    sSingleton =
                        FileUtils(ctx)
                }
            }
            return sSingleton!!
        }

        /**
         * Create file from uri
         * @param context
         * @param uri the uri of image
         * @return file
         */
        fun getFile(context: Context, uri: Uri?): File? {
            if (uri != null) {
                val path = getRealPathFromURI(context, uri)
                if (path != null) {
                    return File(path)
                }
            }
            return null
        }

        val uploadFileName: String
            get() {
                val sdf = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
                val date = Date()
                return String.format("profile_%s.png", sdf.format(date))
            }

        //add this code(edited)
        //get Path
        @TargetApi(Build.VERSION_CODES.KITKAT)
        fun getRealPathFromURI(context: Context, uri: Uri): String? {
            val isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT

            // DocumentProvider
            if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
                // ExternalStorageProvider
                if (isExternalStorageDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    val type = split[0]

                    if ("primary".equals(type, ignoreCase = true)) {
                        return Environment.getExternalStorageDirectory().toString() + "/" + split[1]
                    }
                } else if (isDownloadsDocument(uri)) {
                    val id = DocumentsContract.getDocumentId(uri)
                    val contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), java.lang.Long.valueOf(id)
                    )

                    return getDataColumn(
                        context,
                        contentUri,
                        null,
                        null
                    )
                } else if (isMediaDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    val type = split[0]

                    var contentUri: Uri? = null
                    if ("image" == type) {
                        contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    } else if ("video" == type) {
                        contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    } else if ("audio" == type) {
                        contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    }

                    val selection = "_id=?"
                    val selectionArgs = arrayOf(split[1])

                    return getDataColumn(
                        context,
                        contentUri,
                        selection,
                        selectionArgs
                    )
                }// MediaProvider
                // DownloadsProvider
            } else return if ("content".equals(uri.scheme!!, ignoreCase = true)) {
                // Return the remote address
                if (isGooglePhotosUri(uri)) uri.lastPathSegment else getDataColumn(
                    context,
                    uri,
                    null,
                    null
                )

            } else if ("file".equals(uri.scheme!!, ignoreCase = true)) {
                uri.path
            } else
                getRealPathFromURIDB(context, uri)// File
            // MediaStore (and general)

            return null
        }

        /**
         * Gets real path from uri.
         *
         * @param contentUri the content uri
         * @return the real path from uri
         */
        private fun getRealPathFromURIDB(context: Context, contentUri: Uri): String? {
            val cursor = context.contentResolver.query(contentUri, null, null, null, null)
            if (cursor == null) {
                return contentUri.path
            } else {
                cursor.moveToFirst()
                val index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
                val realPath = cursor.getString(index)
                cursor.close()
                return realPath
            }
        }

        /**
         * Gets data column.
         *
         * @param uri           the uri
         * @param selection     the selection
         * @param selectionArgs the selection args
         * @return the data column
         */
        fun getDataColumn(
            context: Context, uri: Uri?, selection: String?,
            selectionArgs: Array<String>?
        ): String? {
            var cursor: Cursor? = null
            val column = "_data"
            val projection = arrayOf(column)

            try {
                cursor = context.contentResolver.query(uri!!, projection, selection, selectionArgs, null)
                if (cursor != null && cursor.moveToFirst()) {
                    val index = cursor.getColumnIndexOrThrow(column)
                    return cursor.getString(index)
                }
            } finally {
                cursor?.close()
            }
            return null
        }

        /**
         * Is external storage document boolean.
         *
         * @param uri The Uri to check.
         * @return Whether the Uri authority is ExternalStorageProvider.
         */
        fun isExternalStorageDocument(uri: Uri): Boolean {
            return "com.android.externalstorage.documents" == uri.authority
        }

        /**
         * Is downloads document boolean.
         *
         * @param uri The Uri to check.
         * @return Whether the Uri authority is DownloadsProvider.
         */
        fun isDownloadsDocument(uri: Uri): Boolean {
            return "com.android.providers.downloads.documents" == uri.authority
        }

        /**
         * Is media document boolean.
         *
         * @param uri The Uri to check.
         * @return Whether the Uri authority is MediaProvider.
         */
        fun isMediaDocument(uri: Uri): Boolean {
            return "com.android.providers.media.documents" == uri.authority
        }

        /**
         * Is google photos uri boolean.
         *
         * @param uri The Uri to check.
         * @return Whether the Uri authority is Google Photos.
         */
        fun isGooglePhotosUri(uri: Uri): Boolean {
            return "com.google.android.apps.photos.content" == uri.authority
        }

        fun bitmapFromBase64(base64: String): Bitmap? {
            try {
                val decodedString = Base64.decode(base64, Base64.DEFAULT)
                return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            } catch (e: IllegalArgumentException) {
                //bad base 64
                return null
            }

        }

        fun encodeToBase64(image: Bitmap, compressFormat: Bitmap.CompressFormat, quality: Int): String {
            val byteArrayOS = ByteArrayOutputStream()
            image.compress(compressFormat, quality, byteArrayOS)
            return Base64.encodeToString(byteArrayOS.toByteArray(), Base64.DEFAULT)
        }


        fun readPropertyFileFromAssets(context: Context, fileName: String): Properties {
            val properties = Properties()
            if (TextUtils.isEmpty(fileName)) {
                return properties
            }
            try {
                val manager = context.assets
                val paths = Arrays.asList(*manager.list(""))
                if (!paths.contains(fileName)) {
                    return properties
                }
                val inputStream = manager.open(fileName)
                val reader = InputStreamReader(inputStream, Charset.forName("UTF-8"))
                properties.load(reader)
                inputStream.close()
                reader.close()
            } catch (e: IOException) {
                Timber.e(e)
            }

            return properties
        }
    }

}
