package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import vn.app.tcs.data.remote.UserManagerRepository

class UpdateFeeAllUseCase(private var userManagerRepository: UserManagerRepository) :
    UseCase<List<String>>() {
    var fee : Int = 0
    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.updateFeeAll(fee)
    }
}