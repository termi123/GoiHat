package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.ListBlackList
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.data.request.RejectOrderRequest

interface ReportRepository {
    fun getListRejectOrder(page: Int): Single<ListRejectOrder>

    fun getListBlackList(page: Int): Single<ListBlackList>

    fun getListChangeCode(page: Int): Single<ListChangeCode>

    fun rejectOrder(request: RejectOrderRequest): Single<List<String>>

    fun setReportRead(id: Int, type: String): Single<List<String>>
}

class ReportRepositoryImpl(private val reportSource: ReportSource) :
    ReportRepository {
    override fun getListRejectOrder(page: Int): Single<ListRejectOrder> {
        return reportSource.getListRejectOrder(page)
    }

    override fun getListBlackList(page: Int): Single<ListBlackList> {
        return reportSource.getListBlackList(page)
    }

    override fun getListChangeCode(page: Int): Single<ListChangeCode> {
        return reportSource.getListChangeCode(page)
    }

    override fun rejectOrder(request: RejectOrderRequest): Single<List<String>> {
        return reportSource.rejectOrder(request)
    }

    override fun setReportRead(id: Int, type: String): Single<List<String>> {
        return reportSource.setReportRead(id, type)
    }

}