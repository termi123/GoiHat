package vn.app.tcs.ui.actionreport.detail

import com.base.common.base.viewmodel.BaseViewModel

class DetailStaffActionViewModel : BaseViewModel() {
}