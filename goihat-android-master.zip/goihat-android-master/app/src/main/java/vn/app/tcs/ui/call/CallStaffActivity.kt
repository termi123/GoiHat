package vn.app.tcs.ui.call

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import com.google.gson.JsonObject
import kotlinx.android.synthetic.main.activity_call_staff.*
import org.jetbrains.anko.sdk27.coroutines.onClick
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.startActivityForResult
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_ID
import vn.app.tcs.data.karaconstant.EventConstant.KEY_MAX_CALL
import vn.app.tcs.data.karaconstant.EventConstant.KEY_WANT_CALL
import vn.app.tcs.data.karaconstant.EventConstant.KEY_WANT_FEE
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ActivityCallStaffBinding
import vn.app.tcs.ui.addbar.fee.FeeActivity
import vn.app.tcs.ui.addbar.room.AddRoomActivity
import vn.app.tcs.ui.call.bar.ChooseBarActivity
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerActivity
import vn.app.tcs.ui.call.select.SelectStaffActivity
import vn.app.tcs.ui.dialog.WheelPickerDialog
import java.util.*

private const val ADD_BAR_REQUEST_CODE = 3

class CallStaffActivity : BaseKaraToolbarActivity<ActivityCallStaffBinding, CallStaffViewModel>() {

    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_call_staff

    override val viewModel: CallStaffViewModel by viewModel()
    val tagPickSinger = "tagPickSinger"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getIntentData()
        viewModel.setSurveyRequest.observe(this, Observer {
            it?.let {
                startActivity<SelectStaffActivity>(
                    KEY_BAR_ID to viewModel.listBar[viewModel.selectedBar].id,
                    KEY_MAX_CALL to spMaxCall.text.toString().toInt(),
                    KEY_WANT_FEE to tvFee.text.toString()
                )
            }
        })
        addDisposable(RxEvent.CallFinish::class.java) {
            finish()
        }
        addDisposable(RxEvent.EventDialog::class.java) {
            val text = if (it.data.toString().isBlank()) "0" else it.data.toString()
            when (it.tag) {
                KEY_WANT_CALL -> {
                }
                KEY_MAX_CALL -> {
                    run {
                        spMaxCall.text = text
                    }
                }
                AppConstant.CALL_ERROR -> {
                    run {
                        try {
                            val orderId =
                                (it.data as JsonObject).get("order_id").toString().toInt()
                            startActivity<OrderDetailManagerActivity>(EventConstant.KEY_ORDER_DETAIL to orderId)
                        } catch (e: Exception) {
                        }
                    }

                }
            }
        }
        addDisposable(RxEvent.SelectFee::class.java) {
            it.let { selectFee ->
                tvFee.text = selectFee.fee
            }
        }
        if (viewModel.listBar.size == 1) {
            viewModel.selectedBar = 0
        }
        if (viewModel.selectedBar >= 0) {
            spBar.text = viewModel.listBar[viewModel.selectedBar].name
            checkBar(viewModel.listBar[viewModel.selectedBar])
        }
        spBar.onClick {
            startActivityForResult<ChooseBarActivity>(
                10,
                EventConstant.KEY_BAR_ORIGIN to viewModel.listBar
            )

        }
    }

    private fun checkBar(bar: Bar): Boolean {
        bar.rooms?.listRoom?.let {
            if (it.size == 1) {
                viewModel.selectedRoom = it[0]
                spRoom.text = it[0].name
                return true
            }
        }
        return false
    }

    private fun getIntentData() {
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    viewModel.listBar = ex.get(EventConstant.KEY_BAR_ORIGIN) as List<Bar>
                    viewModel.selectedBar = ex.getInt(EventConstant.KEY_BAR_POSITION, -1)
                }
            }
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_FIND_STAFF -> {
                if (viewModel.listBar.isNullOrEmpty()) {
                    showDialogMessage(
                        MessageDialog(
                            getString(R.string.app_name),
                            "Yêu cầu nhập tên bar."
                        )
                    )
                    return
                }
                if (viewModel.selectedRoom != null) {
                    viewModel.setSurvey(
                        viewModel.listBar[viewModel.selectedBar].id!!,
                        viewModel.selectedRoom?.id!!.toInt()
                    )
                    return
                }
                showDialogMessage(
                    MessageDialog(
                        getString(R.string.app_name),
                        "Yêu cầu nhập tên phòng."
                    )
                )
            }
            EventConstant.KEY_MAX_CALL_STAFF -> {
                val message =  MessageDialog(
                    getString(R.string.so_nhan_vien),
                    "",
                    tag = KEY_MAX_CALL,
                    showCancel = true,
                    inputType = InputType.TYPE_CLASS_NUMBER
                )
                val data = ArrayList<String>().apply {
                    for (i in 1..20) {
                        add(i.toString())
                    }
                }

                WheelPickerDialog.newInstance(message,data,data.indexOf(spMaxCall.text.toString())).show(supportFragmentManager,"")
            }
            EventConstant.EVENT_PICK_FEE -> startActivity<FeeActivity>()
            EventConstant.EVENT_PICK_ROOM -> {
                if (viewModel.selectedBar == -1) {
                    return
                }
                val intent = Intent(this, AddRoomActivity::class.java)
                intent.putExtra(EventConstant.KEY_BAR_TYPE, AppConstant.BarActionType.View)
                intent.putExtra(
                    EventConstant.KEY_BAR_ORIGIN,
                    viewModel.listBar[viewModel.selectedBar]
                )
                startActivityForResult(intent, ADD_BAR_REQUEST_CODE)
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == 10 && data != null) {
            val bar = data.getParcelableExtra<Bar>(KEY_BAR_ID)
            viewModel.selectedBar = viewModel.listBar.indexOf(bar)
            spBar.text = bar.name
            if (checkBar(bar)) return
            viewModel.selectedRoom = null
            spRoom.text = ""
            return
        }
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (requestCode == ADD_BAR_REQUEST_CODE) {
                viewModel.selectedRoom = data.getParcelableExtra(EventConstant.KEY_ROOM_NAME_ADD)
                spRoom.text = viewModel.selectedRoom?.name
            }
        }

    }
}