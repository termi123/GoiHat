package vn.app.tcs.data.model

import com.google.gson.annotations.SerializedName
import vn.app.tcs.utils.TimeUtil
import java.io.Serializable
import java.util.*

data class ActionReportResponse(
    @SerializedName("users")
    var users: Users,
    @SerializedName("total_booking")
    var total: Int
) : Serializable

data class Users(
    @SerializedName("current_page")
    var currentPage: Int,
    @SerializedName("last_page")
    var lastPage: Int,
    @SerializedName("lists")
    var staffs: List<StaffAction>,
    @SerializedName("per_page")
    var perPage: Int,
    @SerializedName("total")
    var total: Int
) : Serializable

data class StaffAction(
    @SerializedName("avatar")
    var avatar: String,
    @SerializedName("code")
    var code: String,
    @SerializedName("id")
    var id: Int,
    @SerializedName("name")
    var name: String,
    @SerializedName("order_staff")
    var orderStaff: OrderStaff,
    @SerializedName("order_staff_count")
    var orderStaffCount: Int,
    @SerializedName("phone")
    var phone: String
) : Serializable

data class OrderStaff(
    @SerializedName("lists")
    var lists: List<OrderInfo>
) : Serializable

data class OrderInfo(
    @SerializedName("bar_avatar")
    var barAvatar: String,
    @SerializedName("bar_name")
    var barName: String,
    @SerializedName("created_at")
    var createdAt: Long,
    @SerializedName("description")
    var description: String,
    @SerializedName("id")
    var id: Int,
    @SerializedName("room_name")
    var roomName: String,
    @SerializedName("status")
    var status: String
) : Serializable {

    fun getTime() = TimeUtil.convertCalToString(
        Calendar.getInstance().apply { time.time = createdAt },
        TimeUtil.DATE_FOMART_EVENT_ORDER
    )
}