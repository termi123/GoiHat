package vn.app.tcs.ui.dialog

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.data.event.MessageDialog
import vn.app.tcs.data.karaconstant.EventConstant

class CommonDialogViewModel : BaseViewModel() {
    var content = MutableLiveData<MessageDialog>()


    fun doDismiss() = sendEvent(EventConstant.EVENT_DISMISS)

    fun doCancel() = sendEvent(EventConstant.EVENT_NEG_DIALOG)
}
