package vn.app.tcs.ui.dialog

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.data.event.MessageDialog
import vn.app.tcs.data.karaconstant.EventConstant

class WheelPickerDialogViewModel : BaseViewModel() {
    var content = MutableLiveData<MessageDialog>()
    var data = ArrayList<String>()
    var currentSelect : String? = null
    var originPos : Int = 0

    fun doAccept() = sendEvent(EventConstant.EVENT_ACCEPT)

    fun doCancel() = sendEvent(EventConstant.EVENT_DISMISS)

}
