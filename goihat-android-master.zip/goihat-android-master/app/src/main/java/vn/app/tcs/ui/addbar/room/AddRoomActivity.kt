package vn.app.tcs.ui.addbar.room

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_add_bar.*
import kotlinx.android.synthetic.main.fragment_manager_home.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ActivityAddRoomBinding

class AddRoomActivity : BaseKaraToolbarActivity<ActivityAddRoomBinding, AddRoomViewModel>(),
    BaseAdapter.OnClickItemListener<Bar.Room> {

    override fun getToolBar(): Toolbar = toolbar

    override val layoutId: Int
        get() = R.layout.activity_add_room
    override val viewModel: AddRoomViewModel by viewModel()
    private lateinit var adapter: RoomAdapter
    private val originBar: Bar? by lazy { intent?.extras?.get(EventConstant.KEY_BAR_ORIGIN) as Bar? }
    private val type: AppConstant.BarActionType? by lazy { intent?.extras?.get(EventConstant.KEY_BAR_TYPE) as AppConstant.BarActionType }
    private var listRoom: ArrayList<Bar.Room> = arrayListOf()
    private var selectedPos = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initBarList()
        viewModel.registerRoomRequestData.observe(this, Observer {
            it?.let { list ->
                if (!list.listRoom.isNullOrEmpty()) {
                    listRoom.addAll(list.listRoom)
                    updateAdapter()
                    Toast.makeText(this, "Thêm phòng thành công", Toast.LENGTH_LONG).show()
                }
            }
        })
        viewModel.updateRoomRequestData.observe(this, Observer {
            it?.let { list ->
                if (!list.listRoom.isNullOrEmpty()) {
                    listRoom.forEach {
                        if (it.id == list.listRoom[0].id) {
                            it.name = list.listRoom[0].name
                        }
                    }
                    updateAdapter()
                    Toast.makeText(this, "Sửa tên phòng thành công", Toast.LENGTH_LONG).show()
                }
            }
        })
        viewModel.deleteRoomRequestData.observe(this, Observer {
            it?.let {
                listRoom.removeAt(selectedPos)
                updateAdapter()
                Toast.makeText(this, "Xoá phòng thành công", Toast.LENGTH_LONG).show()
            }
        })

    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        if (event?.data.toString().isBlank()) return
        when (event?.tag) {
            EventConstant.KEY_ROOM_NAME_ADD -> {
                listRoom.forEach { room ->
                    run {
                        if (room.name.equals(event.data.toString(), true)) {
                            Toast.makeText(
                                this@AddRoomActivity,
                                "Trùng tên phòng!",
                                Toast.LENGTH_LONG
                            )
                                .show()
                            return
                        }
                    }
                }
                when (type) {
                    AppConstant.BarActionType.Add -> {
                        listRoom.add(Bar.Room(name = event.data.toString()))
                        updateAdapter()
                    }
                    AppConstant.BarActionType.Edit, AppConstant.BarActionType.View -> {
                        viewModel.registerRoom(arrayListOf(event.data.toString()))
                    }
                }
            }
            EventConstant.KEY_ROOM_NAME_EDIT -> {
                if (selectedPos < 0 || selectedPos >= listRoom.size) return
                listRoom[selectedPos].name = event.data.toString()
                when (type) {
                    AppConstant.BarActionType.Add -> {
                        updateAdapter()
                    }
                    AppConstant.BarActionType.Edit, AppConstant.BarActionType.View -> {
                        viewModel.updateRoom(arrayListOf(listRoom[selectedPos]))
                    }
                }
            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Back -> {
                if (selectedPos < 0 || selectedPos >= listRoom.size) return
                when (type) {
                    AppConstant.BarActionType.Add -> {
                        listRoom.removeAt(selectedPos)
                        updateAdapter()
                    }
                    AppConstant.BarActionType.Edit, AppConstant.BarActionType.View -> {
                        val id = listRoom[selectedPos].id
                        if (!id!!.isBlank()) {
                            viewModel.deleteRoom(arrayListOf(id!!.toInt()))
                        } else {
                            listRoom.removeAt(selectedPos)
                            updateAdapter()
                        }
                    }
                }
            }
            AppConstant.DialogState.Call -> {
                var name = listRoom[selectedPos].name
                if (name.isNullOrBlank()) name = ""
                showDialogEditMessage(
                    MessageDialog(
                        "Nhập tên phòng hát",
                        name,
                        tag = EventConstant.KEY_ROOM_NAME_EDIT
                    )
                )
            }
            else -> {
            }
        }
    }

    private fun initBarList() {
        adapter = RoomAdapter(ArrayList())
        rvBarList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rvBarList.adapter = adapter
        adapter.setOnClickListener(this)
        adapter.onActionBarListener = object : RoomAdapter.OnActionBarListener {
            override fun onEdit(position: Int) {
                selectedPos = position
                showDialog2ButtonMessage(
                    MessageDialog(
                        "Sửa phòng hát", "Bạn muốn đổi tên hay xoá phòng ?",
                        "Đổi tên", "Xoá"
                    )
                )
            }
        }
        originBar?.let {
            listRoom = it.rooms!!.listRoom
            viewModel.barId = it.id!!
            updateAdapter()
        }
    }

    private fun updateAdapter() {
        viewDataBinding?.hasRoom = !listRoom.isNullOrEmpty()
        listRoom.sortBy { it.name }
        adapter.setDataList(listRoom)
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_ADD_ROOM) {
            showDialogEditMessage(
                MessageDialog(
                    "Nhập tên phòng hát",
                    "",
                    tag = EventConstant.KEY_ROOM_NAME_ADD
                )
            )
        }
    }

    override fun onClickItem(item: Bar.Room, position: Int) {
        if (type == AppConstant.BarActionType.View) {
            val intent = Intent()
            intent.putExtra(EventConstant.KEY_ROOM_NAME_ADD, item)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }

    override fun onBackPressed() {
        if (type == AppConstant.BarActionType.View) {
            super.onBackPressed()
            return
        }
        val intent = Intent()
        intent.putParcelableArrayListExtra(EventConstant.KEY_LIST_ROOM, listRoom)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}