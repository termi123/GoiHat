package vn.app.tcs.ui.profile.detail

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel

class ImageStaffDetailViewModel : BaseViewModel() {
    var resource = MutableLiveData<String>()

}
