package vn.app.tcs.utils

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.koin.core.KoinComponent
import org.koin.core.inject
import vn.app.tcs.data.model.UserProfile

object JsonParserUtils : KoinComponent {
    private val gson: Gson by inject()


    fun <T> getData(data: String): T? {
        try {
            val type = object : TypeToken<T>() {}.type
            return gson.fromJson<T>(data, type)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

    }


    fun getUserProfile(data: String): UserProfile.Profile? {
        try {
            val type = object : TypeToken<UserProfile.Profile>() {}.type
            return gson.fromJson<UserProfile.Profile>(data, type)
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }

    }
}