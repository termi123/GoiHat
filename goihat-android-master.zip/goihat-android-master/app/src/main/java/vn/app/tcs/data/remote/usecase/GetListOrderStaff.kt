package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.remote.OrderRepository

class GetListOrderStaffUseCase : UseCase<OrderManager>() {
    var currentPage = 0
    lateinit var option: List<String> //New, Approve, Cancel, Rejected, Processing, Missed, Complete
    private val barManagementRepository: OrderRepository by inject()

    override fun buildUseCaseObservable(): Single<OrderManager> {
        return barManagementRepository.getOrderForStaffs(currentPage, option)
    }
}