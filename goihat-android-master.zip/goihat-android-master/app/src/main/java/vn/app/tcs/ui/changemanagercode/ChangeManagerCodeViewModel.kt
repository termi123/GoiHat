package vn.app.tcs.ui.changemanagercode

import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.ChangeManagerCodeUseCase

class ChangeManagerCodeViewModel(private val changeManagerCodeUseCase: ChangeManagerCodeUseCase) :
    BaseViewModel() {
    val changeCodeResult = Transformations.map(changeManagerCodeUseCase.result){
        handleCommonApi(it)
    }

    fun doChangeCode() = sendEvent(EventConstant.EVENT_VALID_NEW_CODE)

    fun changeManagerCode(mNewCode: String) {
        changeManagerCodeUseCase.apply {
            newCode = mNewCode
        }.execute()
    }

}