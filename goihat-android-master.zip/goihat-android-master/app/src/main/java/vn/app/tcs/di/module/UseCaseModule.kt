package vn.app.tcs.di.module

import org.koin.dsl.module
import vn.app.tcs.data.remote.usecase.*

val useCaseModule = module {
    factory { LoginUseCase() }

    factory { RegisterUseCase() }

    factory { UpdateFirebaseTokenUseCase() }

    factory { MyStaffUseCase() }

    factory { GetStaffInforUseCase() }

    factory { GetProfileUseCase() }

    factory { GetListBarUseCase() }

    factory { RegisterBarUseCase() }

    factory { RegisterBankUseCase() }

    factory { GetNotifyUseCase() }

    factory { SetMarkNotification() }

    factory { SetMarkAllNotification() }

    factory { GetStaffAvailableUseCase() }

    factory { ChangePasswordUseCase() }

    factory { OrderUseCase() }

    factory { UpdateActivityUseCase() }

    factory { SelectStaffUseCase() }

    factory { UnSelectStaffUseCase() }

    factory { UnSelectStaffsUseCase() }

    factory { GetOrderDetailUseCase() }

    factory { GetOrderDetailManagerUseCase() }

    factory { GetListOrderStaffUseCase() }

    factory { UpdateLocationUseCase() }

    factory { GetManagerCallHistoryUseCase() }

    factory { UpdateOrderStatus() }

    factory { UpdateProfileUseCase() }

    factory { RegisterRoomUseCase() }

    factory { RejectOrderUseCase() }

    factory { SetReportReadUseCase() }

    factory { GetRejectUseCase() }

    factory { GetListChangeCodeUseCase() }

    factory { GetListBlackListUseCase() }

    factory { UpdateRoomUseCase() }

    factory { DeleteRoomUseCase() }

    factory { GetFraudAlertUseCase() }

    factory { SetSurveyUseCase() }

    factory { CheckSurveyUseCase() }

    factory { LogoutUseCase() }

    factory { ReportUseCase() }

    factory { StaffOrderUseCase() }

    factory { IncomeFilterUseCase() }

    factory { ActionReportUseCase(get()) }

    factory { ChangeManagerCodeUseCase(get()) }

    factory { UpdateFeeAllUseCase(get()) }

    factory { UpdateFeeOneUseCase(get()) }

    factory { SendStarUseCase(get()) }

    factory { RegisterBarUserCase() }

    factory { ConfigBarUserCase() }

    factory { DeleteBarUserCase() }

    factory { GetRegisteredBar() }

    factory { GetRegisteredBarByName() }
}