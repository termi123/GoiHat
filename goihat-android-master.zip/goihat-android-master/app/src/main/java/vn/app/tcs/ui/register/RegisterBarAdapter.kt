package vn.app.tcs.ui.register

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ItemRegisterBarListBinding

class RegisterBarAdapter(data: ArrayList<Bar>) : BaseAdapter<Bar>(data) {
    lateinit var onActionBarListener: OnActionBarListener

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return BarViewHolder(parent?.inflateExt(R.layout.item_register_bar_list)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BarViewHolder) {
            holder.onBind(list[position])
            holder.binding.ivEdit.onClick {
                if (::onActionBarListener.isInitialized) onActionBarListener.onEdit(list[position])
            }
        }

    }

    class BarViewHolder(view: View) : BaseViewHolder<Bar, ItemRegisterBarListBinding>(view) {
        override fun onBind(item: Bar) {
            binding.bar = item

        }

    }

    interface OnActionBarListener {
        fun onEdit(bar: Bar)
    }
}