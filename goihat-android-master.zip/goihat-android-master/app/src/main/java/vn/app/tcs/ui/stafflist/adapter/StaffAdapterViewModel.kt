package vn.app.tcs.ui.stafflist.adapter

import androidx.lifecycle.MutableLiveData
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import org.koin.core.inject
import timber.log.Timber
import vn.app.tcs.base.BaseItemViewModel
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.ui.stafflist.StaffListViewModel
import vn.app.tcs.utils.databinding.notifyObserver

class StaffAdapterViewModel : BaseItemViewModel<StaffListViewModel>() {
    val database: DatabaseReference by inject()
    var staff = MutableLiveData<ListStaff.Staff>()


    fun setUpStaff(data: ListStaff.Staff) {
        staff.value = data
        database.child("users/${data.id}/status")
            .addValueEventListener(object : ValueEventListener {
                override fun onCancelled(databaseError: DatabaseError) {
                    Timber.d("loadPost:%s",databaseError.toException())
                }

                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (!dataSnapshot.exists()) return
                    Timber.e("%s%s", dataSnapshot.toString(), data.id)
                    if (staff.value!!.activity != dataSnapshot.value) {
                        staff.value!!.activity = dataSnapshot.value as String
                        staff.notifyObserver()
                    }
                }
            })
    }
}