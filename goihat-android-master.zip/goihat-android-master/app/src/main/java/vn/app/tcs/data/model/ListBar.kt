package vn.app.tcs.data.model


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ListBar(
    @SerializedName("per_page")
    var perPage: Int? = 0,
    @SerializedName("total")
    var total: Int? = 0,
    @SerializedName("lists")
    var lists: ArrayList<Bar>,
    @SerializedName("last_page")
    var lastPage: Int? = 0,
    @SerializedName("current_page")
    var currentPage: Int? = 0
) : Parcelable

@Parcelize
data class Bar(
    @SerializedName("address")
    val address: String? = "",
    @SerializedName("manager_id")
    val managerId: Int? = 0,
    @SerializedName("latitude")
    val latitude: String? = "",
    @SerializedName("name")
    val name: String? = "",
    @SerializedName("discount")
    val discount: Int? = 0,
    @SerializedName("description")
    val description: String? = "",
    @SerializedName("created_at")
    val createdAt: String? = "",
    @SerializedName("id")
    val id: Int? = 0,
    @SerializedName("avatar")
    var avatar: String? = "",
    @SerializedName("fee")
    var fee: String? = "",
    @SerializedName("longitude")
    val longitude: String? = "",
    @SerializedName("is_registered")
    val isRegistered: String? = "",
    @SerializedName("rooms")
    var rooms: ListRoom? = ListRoom(),
    var checked: Boolean = false
) : Parcelable {
    fun getAvatarLink() = avatar

    fun isRegisterBar(): Boolean {
        return isRegistered.equals("yes", true)
    }

    @Parcelize
    data class ListRoom(
        @SerializedName("lists")
        var listRoom: ArrayList<Room> = arrayListOf()
    ) : Parcelable {

        fun getBarName(): String {
            if (listRoom.isNullOrEmpty()) return ""
            var s = ""
            listRoom.forEach {
                s += ("${it.name},")
            }
            if (s.length > 1) return s.substring(0, s.length - 1)
            return s
        }
    }

    @Parcelize
    data class Room(
        @SerializedName("id")
        var id: String? = "",
        @SerializedName("name")
        var name: String? = "",
        @SerializedName("created_at")
        val createdAt: String? = ""
    ) : Parcelable

}


