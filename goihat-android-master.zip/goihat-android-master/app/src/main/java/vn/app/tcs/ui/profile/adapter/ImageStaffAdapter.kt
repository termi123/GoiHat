package vn.app.tcs.ui.profile.adapter

import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseLifecycleAdapter
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.base.adapter.BaseVMAdapter
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.ItemImageStaffBinding
import vn.app.tcs.ui.profile.ProfileActivity
import java.io.File

class ImageStaffAdapter(var activity: FragmentActivity, listImage: ArrayList<WrapperImageStaff>) :

    BaseVMAdapter<WrapperImageStaff, ImageStaffItemViewModel>(listImage) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffImageViewHolder(parent?.inflateExt(R.layout.item_image_staff)!!, activity, this)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffImageViewHolder) {
            list[position].apply {
                if (!viewModelProvide.contains(id)) {
                    viewModelProvide.put(id, ImageStaffItemViewModel())
                }
                holder.onBind(this, viewModelProvide.get(id), position)
            }
        }
    }

    fun getUploadImage(): ArrayList<File> {
        val listUpload = ArrayList<File>()
        list.filter {
            it.imageStaff != null && it.imageStaff!!.isLocalImage
        }.forEach { item ->
            listUpload.add(File(item.imageStaff!!.uri.path))
        }
        return listUpload
    }

    class StaffImageViewHolder(
        view: View,
        activity: FragmentActivity,
        var adapter: ImageStaffAdapter
    ) :
        BaseLifecycleAdapter<WrapperImageStaff, ItemImageStaffBinding, ImageStaffItemViewModel>(
            view,
            activity
        ) {
        var positionItem = -1

        fun onBind(item: WrapperImageStaff, viewModelItem: ImageStaffItemViewModel, position: Int) {
            this.viewModel = viewModelItem
            this.positionItem = position
            viewModel.mainViewModel = (activity as ProfileActivity).viewModel
            onBind(item)
        }

        override fun onBind(item: WrapperImageStaff) {
            super.onBind(item)
            viewModel.staffImage.value = item
        }

        override fun onReceiveEvent(event: Int, item: WrapperImageStaff) {
            super.onReceiveEvent(event, item)
            if (event == EventConstant.EVENT_DELETE_PICK_IMAGE_STAFF) {
                if (positionItem == -1) return
                adapter.apply {
                    list[positionItem].imageStaff?.let {
                        if (!it.isLocalImage)
                            viewModel.mainViewModel.deleteIds.add(it.id.toInt())
                    }
                    list.removeAt(positionItem)
                    notifyItemRemoved(positionItem)
                    notifyItemRangeChanged(positionItem, list.size)

                }
            }
        }


    }
}