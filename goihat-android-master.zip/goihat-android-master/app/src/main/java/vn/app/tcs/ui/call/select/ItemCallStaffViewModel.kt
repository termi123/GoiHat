package vn.app.tcs.ui.call.select

import android.os.CountDownTimer
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.constant.AppConstant
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import org.koin.core.inject
import timber.log.Timber
import vn.app.tcs.base.BaseItemViewModel
import vn.app.tcs.data.karaconstant.DEFAULT_TIME
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.data.remote.usecase.FavoriteUseCase
import vn.app.tcs.data.remote.usecase.SelectStaffUseCase
import vn.app.tcs.data.remote.usecase.UnSelectStaffUseCase
import vn.app.tcs.data.request.FavoriteRequest
import vn.app.tcs.utils.databinding.notifyObserver

class ItemCallStaffViewModel : BaseItemViewModel<SelectStaffViewModel>() {
    var staff = MutableLiveData<ListStaff.Staff>()
    var countText = MutableLiveData<String>()
    var isCountDowning = MutableLiveData<Boolean>()
    val selectStaffUseCase: SelectStaffUseCase by inject()
    val unSelectStaffUseCase: UnSelectStaffUseCase by inject()
    val favoriteUseCase: FavoriteUseCase by inject()
    var timer: CountDownTimer? = null
    val database: DatabaseReference by inject()
    var isFavorite = false


    var selectStaffResult = Transformations.map(selectStaffUseCase.result) {
        handleCommonApi(it)
    }
    var unSelectStaffResult = Transformations.map(unSelectStaffUseCase.result) {
        handleCommonApi(it)
    }

    init {
        cancelTimer()
    }

    fun setUpStaff(data: ListStaff.Staff) {
        staff.value = data
        startTimer(data.endTimeSelect)
        database.child("users/${data.id}/status")
            .addValueEventListener(object : ValueEventListener {
                override fun onCancelled(databaseError: DatabaseError) {
                    Timber.d("loadPost:%s", databaseError.toException())
                }

                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (!dataSnapshot.exists()) return
                    Timber.e("%s%s", dataSnapshot.toString(), data.id)
                    if (staff.value!!.activity != dataSnapshot.value) {
                        staff.value!!.activity = dataSnapshot.value as String
                        notifyChangeData()
                    }
                }
            })
    }

    fun cancelTimer() {
        if (timer != null) {
            timer?.cancel()
            countText.value = (DEFAULT_TIME).toString()
            isCountDowning.value = false
        }
        staff.value?.endTimeSelect = 0
        notifyChangeData()
    }

    fun startTimer(endTime: Long) {
        cancelTimer()
        if(endTime < System.currentTimeMillis()) return
        timer = object : CountDownTimer(endTime - System.currentTimeMillis(), 1000L) {
            override fun onFinish() {
                isCountDowning.value = false
                unSelectStaff()
                Timber.e("Finish Cancel ${staff.value!!.id}")
            }

            override fun onTick(millisUntilFinished: Long) {
                isCountDowning.value = true
                countText.value = (millisUntilFinished / 1000).toString()
            }
        }
        staff.value?.endTimeSelect = endTime
        notifyChangeData()
        timer?.start()
    }

    fun selectStaff() {
        if (staff.value == null) return
        selectStaffUseCase.apply {
            list = staff.value?.id!!
        }.executeZip({
            staff.value!!.checked = true
            mainViewModel.selectedSet.add(staff.value?.id!!)
            mainViewModel.sendEvent(EventConstant.EVENT_CHANGE_STAFF_CALL)
            notifyChangeData()
            startTimer(System.currentTimeMillis() + DEFAULT_TIME * 1000)
        }, {
            removeCallCount()
        })
    }

    fun unSelectStaff() {
        if (staff.value == null) return
        removeCallCount()
        unSelectStaffUseCase.apply {
            list = staff.value?.id!!
        }.executeZip({
            removeStaff()
        }, {
            removeStaff()
        })
    }

    private fun removeStaff() {
        mainViewModel.sendEvent(EventConstant.EVENT_CHANGE_STAFF_CALL)
        staff.value!!.checked = false
        mainViewModel.selectedSet.remove(staff.value?.id!!)
        notifyChangeData()
        cancelTimer()
    }

    fun onSelectStaff() {
        staff.value?.let {
            if (it.checked) {
                unSelectStaff()
                return@let
            }
            mainViewModel.itemCall++
            if(it.activity == AppConstant.Activity.Offline.name){
                sendEvent(EventConstant.EVENT_CANT_CALL_OFFLINE)
                removeCallCount()
                return@let
            }
            if(it.activity == AppConstant.Activity.Selecting.name){
                sendEvent(EventConstant.EVENT_CANT_CALL)
                removeCallCount()
                return@let
            }
            if(mainViewModel.itemCall > mainViewModel.maxCallPosition){
                mainViewModel.sendEvent(EventConstant.EVENT_LIMIT_CALL)
                removeCallCount()
                return@let
            }
            selectStaff()
        }
    }

    private fun removeCallCount(){
        if(mainViewModel.itemCall > 0) mainViewModel.itemCall--
    }

    fun onFavoriteStaff() {
        Timber.e("Favorite")
        if(!isFavorite){
            favoriteStaff()
        }
    }

    private fun favoriteStaff() {
        favoriteUseCase.apply {
            favoriteRequest = FavoriteRequest(
                staff.value!!.id.toString(),
                if (!staff.value!!.isFavorite()) "Yes" else "No"
            ) //Available values : Yes, No
        }.executeZip({
            staff.value?.isFavorite = if (!staff.value!!.isFavorite()) "Yes" else "No"
//            mainViewModel.needRefreshFavorite = true
            notifyChangeData()
        }, {
        })
    }

    fun notifyChangeData() {
        staff.notifyObserver()
    }

    fun showAvatar(){
        mainViewModel.avartarStaffShow = staff.value
        mainViewModel.sendEvent(EventConstant.EVENT_SHOW_AVATAR_STAFF)
    }

}