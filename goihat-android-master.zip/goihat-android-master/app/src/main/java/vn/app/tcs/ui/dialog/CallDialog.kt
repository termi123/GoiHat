package vn.app.tcs.ui.dialog

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import com.base.common.base.dialog.BaseDialog
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.CallDialogBinding

class CallDialog : BaseDialog<CallDialogBinding, CallDialogViewModel>() {
    override val viewModel: CallDialogViewModel by inject()
    override val layoutId: Int
        get() = R.layout.call_dialog

    override fun updateUI(savedInstanceState: Bundle?) {

    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_BACK -> {
                dismiss()
                viewModel.publishRxEvent(RxEvent.EventCloseDialog(AppConstant.DialogState.Back, viewModel.content.value?.tag))
            }
            EventConstant.EVENT_CALL -> {
                dismiss()
                viewModel.publishRxEvent(RxEvent.EventCloseDialog(AppConstant.DialogState.Call, viewModel.content.value?.tag))
            }
        }
    }

    companion object {
        fun newInstance(mess: MessageDialog) = CallDialog().apply {
            viewModel.content.value = MessageDialog(mess.title, mess.content, mess.confirmButton, mess.cancelButton, mess.tag)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }
}