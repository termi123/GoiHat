package vn.app.tcs.data.remote

import io.reactivex.Single
import okhttp3.RequestBody
import retrofit2.http.*
import vn.app.tcs.data.model.*
import vn.app.tcs.data.request.*

interface UserManagementSource {

    @POST("/api/user/register")
    fun register(
        @Body userRegisterRequest: RequestBody
        , @Query("name") name: String
        , @Query("phone") phone: String
        , @Query("password") password: String
        , @Query("role") role: String
        , @Query("referral_code") referral_code: String?
    ): Single<List<String>>

    @POST("/api/user/{id}/location")
    fun updateLocation(@Path("id") id: String, @Body locationRequest: LocationRequest): Single<List<String>>

    @GET("/api/user/{id}")
    fun getUserInfo(@Path("id") id: String): Single<UserProfile>

    @GET("/api/user/profile")
    fun getProfile(): Single<UserProfile>

    @POST("/api/user/update-profile")
    fun updateProfile(
        @Body body: RequestBody?
        , @Query("name") name: String, @Query("gallery_ids[]") listDelete : ArrayList<Int>
    ): Single<UserProfile>

    @GET("/api/user/my-staffs")
    fun getStaffs(@Query("page") page: Int): Single<ListStaff>

    @GET("/api/user/my-favorite-staffs")
    fun getFavoriteStaff(@Query("page") page: Int, @Query("option") option: String, @Query("bar_id") barId: String): Single<ListStaff>

    @POST("/api/user/update-activity")
    fun updateActivity(@Body activity: ActivityRequest): Single<List<String>> //Available values : Offline, Online, Busy

    @POST("/api/order/unselect-staff")
    fun unSelectStaff(@Body activity: SelectStaffRequest): Single<List<String>>

    @POST("/api/order/unselect-staffs")
    fun unSelectStaffs(@Body activity: UnSelectStaffRequest): Single<List<String>>

    @POST("/api/user/favorite")
    fun favorite(@Body activity: FavoriteRequest): Single<List<String>>

    @POST("/api/order/choose-staff")
    fun chooseStaff(@Body activity: SelectStaffRequest): Single<List<String>>

    @GET("/api/user/activity")
    fun getStaffActivity(): Single<StaffActivityResponse>

    @POST("/api/user/change-owner-code")
    fun changeOwnerCode(@Query("new_owner_code") newOwnerCode: String?): Single<List<String>>

    @POST("/api/user/update-fee-order-all")
    fun updateFeeAll(@Query("fee") fee: Int): Single<List<String>>

    @POST("/api/user/update-fee-order-one")
    fun updateFeeOne(@Query("fee") fee: Int, @Query("staff_id") staffId: Int): Single<List<String>>

    @POST("/api/user/transfer-money")
    fun sendStar(@Query("code") code: String?, @Query("money") money: Int, @Query("password") password : String?): Single<List<String>>

    @GET("/api/statistic/income")
    fun getIncomeFilter(@Query("time") time: String?, @Query("from") from: String?, @Query("to") to: String?): Single<IncomeResponse>

    @GET("/api/statistic/bookings")
    fun actionReport(
        @Query("page") page: Int, @Query("from") from: String?, @Query("to") to: String?, @Query(
            "option"
        ) option: String?, @Query("time") time: String?
    ): Single<ActionReportResponse>
}