package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.NotificationRepository

class SetMarkAllNotification : UseCase<List<String>>() {
    private val notificationRepository: NotificationRepository by inject()
    override fun buildUseCaseObservable(): Single<List<String>> {
        return notificationRepository.setRead()
    }
}