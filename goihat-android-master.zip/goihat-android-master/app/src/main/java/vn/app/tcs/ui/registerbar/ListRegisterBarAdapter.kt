package vn.app.tcs.ui.registerbar

import android.util.SparseBooleanArray
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ItemRegisterBarBinding

class ListRegisterBarAdapter (data: ArrayList<Bar>) : BaseAdapter<Bar>(data) {
    lateinit var onActionBarListener: OnActionBarListener
    private val itemStateArray = SparseBooleanArray()

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return BarViewHolder(parent?.inflateExt(R.layout.item_register_bar)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BarViewHolder) {
            holder.onBind(list[position])
            holder.binding.root.onClick() {
                selectBar(position)
            }
        }

    }

    fun selectBar(position : Int){
        if (!itemStateArray.get(position, false)) {
            list[position].checked = true
            itemStateArray.put(position, true)
        } else  {
            list[position].checked = false
            itemStateArray.put(position, false)
        }
        notifyItemChanged(position)
    }

    class BarViewHolder(view: View) : BaseViewHolder<Bar, ItemRegisterBarBinding>(view) {
        override fun onBind(item: Bar) {
            binding.bar = item
        }

    }

    interface OnActionBarListener {
        fun onEdit(bar: Bar)
    }
}