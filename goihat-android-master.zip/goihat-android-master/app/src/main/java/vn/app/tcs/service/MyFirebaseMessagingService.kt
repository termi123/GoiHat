package vn.app.tcs.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.base.common.constant.AppConstant
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.koin.core.KoinComponent
import org.koin.core.inject
import timber.log.Timber
import vn.app.tcs.KaraApplication
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant.KEY_FROM_FB
import vn.app.tcs.data.karaconstant.EventConstant.KEY_ORDER_DETAIL
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerActivity
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffActivity
import vn.app.tcs.utils.sound.AlarmController
import vn.app.tcs.utils.sound.VibratorController
import java.util.*


class MyFirebaseMessagingService : FirebaseMessagingService(), KoinComponent {

    val userManager: UserManager by inject()

    override fun onMessageReceived(remoteMessage: RemoteMessage) {

        Timber.d("From: ${remoteMessage.from}")

        // Check if message contains a data payload.
        remoteMessage.data.isNotEmpty().let {
            Timber.d("Message data payload: %s", remoteMessage.data)
            sendNotification(remoteMessage)
            //{body=Quản lý le te đang yêu cầu bạn cho quán OK ok 2., category=order, badge=32, sound=default, title=, bar_avatar=/images/bars/1562168216.jpg, order_id=84}
            if (remoteMessage.data.keys.contains("order_id") && remoteMessage.data.keys.contains("category")) {
                if (remoteMessage.data["order_id"] != null && remoteMessage.data["category"] != null) {
                    if (remoteMessage.data["category"] == "order" && !remoteMessage.data["order_id"].isNullOrBlank()) {
                        RxBus.publish(
                            RxEvent.EventReload(
                                remoteMessage.data["order_id"]!!,
                                remoteMessage.data["status"] == "New"
                            )
                        )
                        if (remoteMessage.data["status"] == "New") {
                            AlarmController.playSound(KaraApplication.instance, "order")
                            VibratorController.setVibrate(KaraApplication.instance)
                            Handler(Looper.getMainLooper()).postDelayed({
                                stopNotify()
                            }, (30 * 1000).toLong())
                        }
                        return@let
                    }
                }
            }
            if (remoteMessage.data.keys.contains("category") && !remoteMessage.data["category"].isNullOrBlank()) {
                AlarmController.playSound(KaraApplication.instance, remoteMessage.data["category"])
                VibratorController.setVibrate(KaraApplication.instance)
                Handler(Looper.getMainLooper()).postDelayed({
                    stopNotify()
                }, (5 * 1000).toLong())
            }
            RxBus.publish(RxEvent.EventReloadDetail())
        }
    }

    override fun onNewToken(token: String) {
        Timber.d("Refreshed token: $token")
        userManager.setFireBaseToken(token)
    }

    private fun scheduleJob() {
        // [START dispatch_job]
        val work = OneTimeWorkRequest.Builder(MyWorker::class.java).build()
        WorkManager.getInstance().beginWith(work).enqueue()
        // [END dispatch_job]
    }

    /**
     * Handle time allotted to BroadcastReceivers.
     */
    private fun handleNow(orderId: String) {
        val role = userManager.getUserInfo()?.role
        if (role != null && role == AppConstant.Role.Staff.name) {
            Timber.d("Short lived task is done.")
            val dialogIntent = Intent(this, OrderDetailStaffActivity::class.java)
            dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            dialogIntent.putExtra(KEY_ORDER_DETAIL, orderId.toInt())
            dialogIntent.putExtra(KEY_FROM_FB, true)
            this.startActivity(dialogIntent)
        }
    }

    /**
     * Create and show a simple notification containing the received FCM message.
     *
     * @param messageBody FCM message body received.
     */
    private fun sendNotification(messageBody: RemoteMessage) {
        if (messageBody.data["body"] == null) return
        val id = (Date().time / 1000L % Integer.MAX_VALUE).toInt()

        val intent: Intent = getIntent(messageBody)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pendingIntent = PendingIntent.getActivity(
            this, id, intent,
            PendingIntent.FLAG_ONE_SHOT
        )

        val channelId = "kara"
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_noti_logo)
            .setContentTitle(getString(vn.app.tcs.R.string.app_name))
            .setContentText(messageBody.data["body"])
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setDefaults(Notification.DEFAULT_ALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)

        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Since android Oreo notification channel is needed.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NotificationChannel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
            notificationBuilder.priority = NotificationCompat.PRIORITY_HIGH
        }

        notificationManager.notify(id, notificationBuilder.build())
    }

    private fun getIntent(messageBody: RemoteMessage): Intent {
        var intent = Intent(this, KaraApplication::class.java)
        if (messageBody.data["category"] == null) {
            return intent
        }
        if (messageBody.data.keys.contains("order_id") && messageBody.data.keys.contains("category")) {
            if (messageBody.data["order_id"] != null && messageBody.data["category"] != null) {
                if (messageBody.data["category"] == "order" &&
                    !messageBody.data["order_id"].isNullOrBlank()
                ) {
                    val role = userManager.getUserInfo()?.role
                    if (role != null && role == AppConstant.Role.Staff.name) {
                        intent = Intent(this, OrderDetailStaffActivity::class.java)
                    } else {
                        intent = Intent(this, OrderDetailManagerActivity::class.java)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.putExtra(KEY_ORDER_DETAIL, (messageBody.data["order_id"])!!.toInt())
                    intent.putExtra(KEY_FROM_FB, true)
                }
            }
        }
        return intent
    }


    private fun stopNotify() {
        AlarmController.stopSound()
        VibratorController.stopAlert()
    }

    companion object {

    }
}