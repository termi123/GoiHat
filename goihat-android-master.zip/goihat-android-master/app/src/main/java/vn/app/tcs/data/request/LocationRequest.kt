package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class LocationRequest(
    @SerializedName("latitude") var latitude: String,
    @SerializedName("longitude") var longitude: String
)
