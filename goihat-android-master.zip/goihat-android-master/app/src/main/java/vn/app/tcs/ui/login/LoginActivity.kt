package vn.app.tcs.ui.login

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.widget.ArrayAdapter
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.bumptech.glide.Glide
import com.zing.zalo.zalosdk.oauth.ZaloSDK
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_login.*
import org.jetbrains.anko.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.ActivityLoginBinding
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffActivity
import vn.app.tcs.ui.forgetpass.ForgetPassActivity
import vn.app.tcs.ui.home.dialog.CallSupportDialog
import vn.app.tcs.ui.home.manager.MainManagerActivity
import vn.app.tcs.ui.home.owner.MainOwnerActivity
import vn.app.tcs.ui.home.staff.MainStaffActivity
import vn.app.tcs.ui.register.RegisterActivity

class LoginActivity : BaseKaraActivity<ActivityLoginBinding, LoginViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_login
    override val viewModel: LoginViewModel by viewModel()

    private val listRoles = arrayOf(
        AppConstant.Role.Manager.name,
        AppConstant.Role.Owner.name,
        AppConstant.Role.Staff.name
    )
    private val listRolesDisplay: Array<String> by lazy {
        arrayOf(
            getString(R.string.manager_event),
            getString(R.string.manager_singer),
            getString(R.string.singer)
        )
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initSpinnerAdapter()
//        ZaloSDK.Instance.unauthenticate()
//        ZaloSDK.Instance.authenticate(this, LoginVia.APP_OR_WEB, this)
        Glide.with(this@LoginActivity).load(R.drawable.ic_tcs)
            .into(imageView8)
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Call -> {
                CallSupportDialog.getInstance().show(supportFragmentManager, "")
            }
            else -> {
            }
        }
    }

    private fun initSpinnerAdapter() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item, listRolesDisplay
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spRole.adapter = adapter
    }

    override fun setUpObserver() {
        super.setUpObserver()

        viewModel.getStaffActivityRequest.observe(this, Observer {
            it?.let { response ->
                if (response.data?.orderId != null) {
                    run {
                        startActivity<OrderDetailStaffActivity>(
                            EventConstant.KEY_ORDER_DETAIL to response.data.orderId,
                            EventConstant.KEY_FROM_SPLASH to true
                        )
                    }
                } else {
                    startActivity<MainStaffActivity>(EventConstant.KEY_FROM_LOGIN to true)
                }
                finish()
            }
        })
        viewModel.userProfile.observe(this, Observer { userProfile ->
            userProfile?.let {
                viewModel.saveUserInfor(it)
                when (it.profile.role) {
                    AppConstant.Role.Manager.name -> startActivity<MainManagerActivity>(EventConstant.KEY_FROM_LOGIN to true)
                    AppConstant.Role.Owner.name -> startActivity<MainOwnerActivity>(EventConstant.KEY_FROM_LOGIN to true)
                    AppConstant.Role.Staff.name -> {
                        viewModel.getStaffActivity()
                        return@Observer
                    }
                }
                finish()
            }
        })
    }


    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_LOGIN -> handleLogin(etUserName.text.toString(), etPassword.text.toString())
            EventConstant.EVENT_REGISTER -> startActivity<RegisterActivity>()
            EventConstant.EVENT_FORGOT_PASS -> callSupport()
            EventConstant.EVENT_CALL_SUPPORT -> callSupport()
        }
    }

    private fun callSupport() {
        Handler().postDelayed({
            showDialog2ButtonMessage(
                MessageDialog(
                    "Thông tin liên hệ", "Xin vui lòng liên hệ tới tổng đài sau.<br><br>CSKH 1 : <a href=\"tel:0337411655\"><font color=#F6358A>0337411655</font></a><br><br>CSKH 2 : <a href=\"tel:0326544338\"><font color=#F6358A>0326544338</font></a><br><br>CSKH 3 : <a href=\"tel:0335699277\"><font color=#F6358A>0335699277</font></a>",
                    "", "OK"
                ).apply {
                    tag = "Call_Support"
                }
            )
        }, 200)
    }

    private fun handleLogin(username: String, password: String) {
        if (TextUtils.isEmpty(username)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_USERNAME))
            return
        }
        if (username.trim().run {
                length < 1 || length > 16
            }) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_USERNAME))
            return
        }
        if (TextUtils.isEmpty(password)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_PASS))
            return
        }
        if (password.trim().run {
                length < 6 || length > 10
            }) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_PASS))
            return
        }
        viewModel.login(username, password, listRoles[spRole.selectedItemPosition])
    }

    //2. override onActivityResult
    override fun onActivityResult(reqCode: Int, resCode: Int, d: Intent?) {
        super.onActivityResult(reqCode, resCode, d)
        ZaloSDK.Instance.onActivityResult(this, reqCode, resCode, d)
    }
}
