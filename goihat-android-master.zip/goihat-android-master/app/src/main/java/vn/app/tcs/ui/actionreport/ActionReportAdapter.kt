package vn.app.tcs.ui.actionreport

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.StaffAction
import vn.app.tcs.databinding.ItemActionReportBinding

class ActionReportAdapter(data: ArrayList<StaffAction>) : BaseAdapter<StaffAction>(data) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffActionViewHolder(parent?.inflateExt(R.layout.item_action_report)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffActionViewHolder) {
            holder.onBind(list[position])
        }

    }

    class StaffActionViewHolder(view: View) :
        BaseViewHolder<StaffAction, ItemActionReportBinding>(view) {
        override fun onBind(item: StaffAction) {
            binding.staff = item

        }

    }
}


