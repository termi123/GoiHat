package vn.app.tcs.ui.home.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R

class CallSupportDialog : BottomSheetDialogFragment() {
    lateinit var binding: vn.app.tcs.databinding.DialogCallSupportBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.dialog_call_support, container, false)
        binding = DataBindingUtil.bind(view)!!
        binding.btCancel.onClick {
            dismiss()
        }
        return view
    }

    companion object {
        fun getInstance(): CallSupportDialog {
            return CallSupportDialog()
        }
    }
}