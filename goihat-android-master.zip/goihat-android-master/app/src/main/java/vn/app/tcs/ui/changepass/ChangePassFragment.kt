package vn.app.tcs.ui.changepass

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.fragment_change_pass.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.FragmentChangePassBinding
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.login.LoginActivity

class ChangePassFragment : BaseKaraFragment<FragmentChangePassBinding, ChangePassViewModel>() {
    override val layoutId: Int
        get() = R.layout.fragment_change_pass
    override val viewModel: ChangePassViewModel by inject()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.changePassResult.observe(viewLifecycleOwner, Observer { result ->
            run {
                result?.let {
                    (activity as MainActivity).showDialogMessage(
                            MessageDialog(
                                    "Thông báo",
                                    "Bạn đã thay đổi mật khẩu thành công.\nXin mời đăng nhập lại.",
                                    tag = "CHANGE_PASS"
                            )
                    )
                }
            }
        })
    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        run {
            if (event?.tag == "CHANGE_PASS") {
                viewModel.removeData()
                startActivity<LoginActivity>()
                requireActivity().finish()
            }
        }
    }


    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_CHANGE_PASS) {
            if (etOldPass.text.toString().trim().run {
                        length < 6 || length > 10
                    }) {
                showDialogMessage(MessageDialog("Lỗi", AppConstant.WRONG_PASS, confirmButton = "OK"))
                return
            }
            if (etNewPass.text.toString().trim().run {
                        length < 6 || length > 10
                    }) {
                showDialogMessage(MessageDialog("Lỗi", AppConstant.WRONG_NEW_PASS, confirmButton = "OK"))
                return
            }
            if (etNewPass.text.toString() != etReNewPass.text.toString()) {
                showDialogMessage(MessageDialog("Lỗi", AppConstant.PASS_N_MATCH, confirmButton = "OK"))
                return
            }
            viewModel.changePassword(
                    etOldPass.text.toString(),
                    etNewPass.text.toString(),
                    etReNewPass.text.toString()
            )
        }
    }

    companion object {
        val TAG = ChangePassFragment::class.java.simpleName
        fun newInstance(): ChangePassFragment {
            return ChangePassFragment()
        }
    }
}
