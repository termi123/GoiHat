package vn.app.tcs.data.request

import vn.app.tcs.data.model.Bar
import java.io.File

class AddBarRequest {
    var name: String = ""
    var address: String = ""
    var managerId: String = ""
    var description: String = ""
    var avatarUrl: String? = ""
    var discount: Double = 0.0
    var longitude: Double = 0.0
    var latitude: Double = 0.0
    var avatar: File? = null
    var id: String = ""
    var fee: String = ""
    var listRoom: ArrayList<Bar.Room> = arrayListOf()
    var listRoomName: ArrayList<String> = arrayListOf()

    fun getAvatarLink() = avatarUrl

    fun getBarName(): String {
        if (listRoom.isNullOrEmpty()) return ""
//        var s = ""
//        listRoom.forEach {
//            s += ("${it.name},")
//        }
//        if (s.length > 1) return s.substring(0, s.length - 1)
        return "Có " + listRoom.size + " phòng hát"
    }

    fun showFee() = if(fee.isBlank() || fee == "0") "Không mất phí" else fee

    fun getBarNames(): ArrayList<String> {
        listRoomName.clear()
        listRoom.forEach {
            it.name?.let { name ->
                listRoomName.add(name)

            }
        }
        return listRoomName
    }
}