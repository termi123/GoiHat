package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.data.remote.BankManagement

class RegisterBankUseCase : UseCase<List<String>>() {

    private val barManagementRepository: BankManagement by inject()
    lateinit var addBarRequest: ListBank.BankInfo

    override fun buildUseCaseObservable(): Single<List<String>> {
        return barManagementRepository.registerBank(addBarRequest)
    }

}