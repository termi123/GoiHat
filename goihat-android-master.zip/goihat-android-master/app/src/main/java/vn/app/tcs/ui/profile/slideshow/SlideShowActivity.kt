package vn.app.tcs.ui.profile.slideshow

import android.os.Bundle
import android.os.Handler
import androidx.databinding.Observable
import androidx.viewpager2.widget.ViewPager2
import com.rd.animation.type.AnimationType
import kotlinx.android.synthetic.main.activity_slide_show_activity.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.model.ImageStaffResponse
import vn.app.tcs.databinding.ActivitySlideShowActivityBinding
import vn.app.tcs.ui.intro.ViewPagerFragmentAdapter
import vn.app.tcs.ui.profile.detail.ImageStaffDetailFragment

class SlideShowActivity : BaseKaraActivity<ActivitySlideShowActivityBinding, SlideShowViewModel>() {
    override val layoutId = R.layout.activity_slide_show_activity
    override val viewModel: SlideShowViewModel by viewModel()
    var listImage: List<ImageStaffResponse> = ArrayList()
    var position: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getIntentData()
        val adapter = ViewPagerFragmentAdapter(this)
        listImage.forEach {
            adapter.addFragment(ImageStaffDetailFragment.newInstance(it.path))
        }
        slideShow.adapter = adapter
        pageIndicatorView.count = adapter.itemCount
        pageIndicatorView.setAnimationType(AnimationType.WORM)
        slideShow.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                pageIndicatorView.selection = position
                viewModel.progress.value = "${position + 1}/${listImage.size} "
            }
        })
        if (position != 0 && position < listImage.size) {
            Handler().postDelayed({
                slideShow.setCurrentItem(position, false)
            }, 100)
        }
    }

    private fun getIntentData() {
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    listImage = ex.get(EventConstant.KEY_LIST_IMAGE) as List<ImageStaffResponse>
                    position = ex.getInt(EventConstant.KEY_LIST_IMAGE_POSITION, 0)
                }
            }
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        super.onReceiverMessage(sender, propertyId)
        when (propertyId) {
            EventConstant.EVENT_FINISH -> finish()
            EventConstant.EVENT_NEXT -> if (slideShow.currentItem + 1 <= listImage.size - 1) slideShow.setCurrentItem(
                slideShow.currentItem + 1,
                true
            )
            EventConstant.EVENT_PREVIOUS -> if (slideShow.currentItem > 0) slideShow.setCurrentItem(
                slideShow.currentItem-1,
                true
            )
        }
    }
}
