package vn.app.tcs.ui.stafflist

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_staff_list.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraListFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.FragmentStaffListBinding
import vn.app.tcs.ui.staffdetail.StaffDetailActivity
import vn.app.tcs.ui.stafflist.adapter.StaffAdapter

class StaffListFragment :
    BaseKaraListFragment<FragmentStaffListBinding, StaffListViewModel, ListStaff.Staff>() {

    override val recyclerView: RecyclerView by lazy { rvManager }
    override val viewModel: StaffListViewModel by viewModel()
    override val layoutId = R.layout.fragment_staff_list

    var data = ArrayList<ListStaff.Staff>()
    override val adapter: StaffAdapter by lazy { StaffAdapter(requireActivity(), data) }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_UPDATE_STATUS) {
            viewModel.employees.value?.staff?.let { adapter.setDataList(it) }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.employees.observe(viewLifecycleOwner, Observer { staffList ->
            run {
                staffList?.let {
                    adapter.totalPage = it.lastPage
                    it.staff.map { item -> item.isShowFee = true }
                    handlerLoadData(it.staff)
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        viewModel.reset()
    }

    override fun onClickRecycleViewItem(item: ListStaff.Staff) {
        startActivity<StaffDetailActivity>(EventConstant.KEY_STAFF_DETAIL to item.id.toString())
    }

    companion object {
        val TAG = StaffListFragment::class.java.getName()
        fun newInstance(): StaffListFragment {
            val fragment = StaffListFragment()
            return fragment
        }
    }
}

