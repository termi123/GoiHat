package vn.app.tcs.ui.managercallhistory.history

import android.os.Bundle
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_history_event.toolbar
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.databinding.ActivityHistoryEventBinding
import vn.app.tcs.ui.managercallhistory.ManagerCallHistoryFragment

class HistoryEventActivity : BaseKaraToolbarActivity<ActivityHistoryEventBinding,HistoryEventViewModel>() {
    override fun getToolBar(): Toolbar = toolbar
    override val layoutId: Int
        get() = R.layout.activity_history_event
    override val viewModel: HistoryEventViewModel by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showManagementFragment(ManagerCallHistoryFragment.newInstance(true),ManagerCallHistoryFragment.TAG)
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }

    private fun showManagementFragment(fragment: Fragment, tag: String) {
        supportFragmentManager
            .beginTransaction()
            .disallowAddToBackStack()
            .replace(R.id.container, fragment, tag)
            .commit()
    }

}
