package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.IncomeResponse
import vn.app.tcs.data.remote.UserManagerRepository

class IncomeFilterUseCase : UseCase<IncomeResponse>() {
    val userManagerRepository : UserManagerRepository by inject()
    var time : String? = null
    var to : String? = null
    var from : String? = null
    override fun buildUseCaseObservable(): Single<IncomeResponse> {
        return userManagerRepository.filterIncome(time, from, to)
    }
}