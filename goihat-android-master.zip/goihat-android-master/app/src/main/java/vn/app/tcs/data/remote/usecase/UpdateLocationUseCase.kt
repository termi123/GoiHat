package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.UserManagerRepository
import vn.app.tcs.data.request.LocationRequest

class UpdateLocationUseCase : UseCase<List<String>>() {
    private val userRepository: UserManagerRepository by inject()
    var id: String = ""
    lateinit var locationRequest: LocationRequest

    override fun buildUseCaseObservable(): Single<List<String>> {
        return userRepository.updateLocation(id, locationRequest)
    }
}