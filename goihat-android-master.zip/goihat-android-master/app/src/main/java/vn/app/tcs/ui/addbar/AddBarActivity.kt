package vn.app.tcs.ui.addbar

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.bumptech.glide.Glide
import com.schibstedspain.leku.LATITUDE
import com.schibstedspain.leku.LOCATION_ADDRESS
import com.schibstedspain.leku.LONGITUDE
import com.schibstedspain.leku.LocationPickerActivity
import com.tbruyelle.rxpermissions2.RxPermissions
import kotlinx.android.synthetic.main.activity_add_bar.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_ORIGIN
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_TYPE
import vn.app.tcs.data.karaconstant.EventConstant.KEY_LIST_ROOM
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ActivityAddBarBinding
import vn.app.tcs.service.LocationService
import vn.app.tcs.ui.addbar.fee.FeeActivity
import vn.app.tcs.ui.addbar.room.AddRoomActivity
import vn.app.tcs.ui.dialog.CallDialog
import vn.app.tcs.utils.databinding.notifyObserver
import vn.app.tcs.utils.imagepicker.ImagePicker
import java.io.File

private const val MAP_BUTTON_REQUEST_CODE = 1
private const val ADD_BAR_REQUEST_CODE = 3

class AddBarActivity : BaseKaraToolbarActivity<ActivityAddBarBinding, AddBarViewModel>() {
    override fun getToolBar(): Toolbar = toolbar

    override val layoutId: Int
        get() = R.layout.activity_add_bar
    override val viewModel: AddBarViewModel by viewModel()

    private var imagePicker: ImagePicker? = null
    private val originBar: Bar? by lazy { intent?.extras?.get(KEY_BAR_ORIGIN) as Bar? }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getIntentData()
        addDisposable(RxEvent.SelectFee::class.java) {
            handleSelectFee(it)
        }
    }

    private fun handleSelectFee(event: RxEvent.SelectFee?) {
        event?.let {
            viewModel.apply {
                addBarRequestLiveData.value?.apply {
                    fee = event.fee
                }
            }
            viewModel.addBarRequestLiveData.notifyObserver()
        }
    }

    override fun setUpObserver() {
        super.setUpObserver()
        viewModel.deleteBar.observe(this, Observer {
            it?.let {
                finish()
                viewModel.publishRxEvent(RxEvent.BarEvent(AppConstant.BarActionType.Edit))
            }
        })
    }

    private fun getIntentData() {
        viewModel.type = intent?.extras?.get(KEY_BAR_TYPE) as AppConstant.BarActionType
        originBar?.let {
            viewModel.addBarRequestLiveData.value?.apply {
                name = it.name!!
                description = if (it.description == null) "" else it.description
                id = it.id.toString()
                managerId = it.managerId.toString()
                latitude = it.latitude!!.toDouble()
                longitude = it.longitude!!.toDouble()
                address = it.address ?: ""
                avatarUrl = it.avatar
                fee = it.fee ?: "0"
                listRoom = it.rooms!!.listRoom
            }
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_ADD_BAR -> {
                viewModel.apply {
                    addBarRequestLiveData.value?.apply {
                        name = etBarName.text.toString()
                        description = etDescription.text.toString()
                    }
                }
                if (!isValidate()) return
                viewModel.addBar()
            }
            EventConstant.EVENT_EDIT_BAR -> {
                viewModel.apply {
                    addBarRequestLiveData.value?.apply {
                        name = etBarName.text.toString()
                        description = etDescription.text.toString()
                        id = originBar?.id.toString()
                    }
                }
                if (!isValidate()) return
                viewModel.updateBar()
            }
            EventConstant.EVENT_PICK_IMAGE -> handlePickImage()
            EventConstant.EVENT_PICK_LOCATION -> handlePickLocation()
            EventConstant.EVENT_PICK_FEE -> handlePickFee()
            EventConstant.EVENT_PICK_ROOM -> handlePickRoom()
            EventConstant.EVENT_ADD_BAR_SUCCESS -> {
                finish()
                viewModel.publishRxEvent(RxEvent.BarEvent(AppConstant.BarActionType.Add))
            }
            EventConstant.EVENT_UPDATE_BAR_SUCCESS -> {
                finish()
                RxBus.publish(RxEvent.BarEvent(AppConstant.BarActionType.Edit))
            }
            EventConstant.EVENT_DELETE_BAR -> {
                originBar?.let {
                    CallDialog.newInstance(
                        MessageDialog(
                            "Xoá cơ sở",
                            "Bạn có chắc chắn xóa cơ sở",
                            confirmButton = "Huỷ",
                            cancelButton = "OK"
                        )
                    )
                        .show(supportFragmentManager, it.id.toString())
                }
            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if (event.dialogState == AppConstant.DialogState.Back) {
            viewModel.deleteBar(originBar?.id.toString())
            viewModel.publishRxEvent((RxEvent.BarEvent(AppConstant.BarActionType.Edit)))
        }
    }

    private fun handlePickFee() = startActivity<FeeActivity>()

    private fun isValidate(): Boolean {
        if (TextUtils.isEmpty(etBarName.text.toString())) {
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    "Yêu cầu nhập tên cơ sở."
                )
            )
            return false
        }
        if (viewModel.addBarRequestLiveData.value?.listRoom.isNullOrEmpty()) {
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    "Yêu cầu nhập tên phòng."
                )
            )
            return false
        }
        return true
    }

    private fun handlePickRoom() {
        val intent = Intent(this, AddRoomActivity::class.java)
        intent.putExtra(KEY_BAR_TYPE, viewModel.type)
        intent.putExtra(KEY_BAR_ORIGIN, originBar)
        startActivityForResult(intent, ADD_BAR_REQUEST_CODE)
    }

    @SuppressLint("CheckResult")
    private fun handlePickLocation() {
        RxPermissions(this).request(Manifest.permission.ACCESS_COARSE_LOCATION)
            .subscribe { granted ->
                if (granted) {
                    LocationService.init(this@AddBarActivity)
                    LocationService.getLocation(this, {
                        val locationPickerIntent = LocationPickerActivity.Builder()
                            .withLocation(it.latitude, it.longitude)
                            .withGeolocApiKey(getString(R.string.google_maps_key))
                            .shouldReturnOkOnBackPressed()
                            .withGooglePlacesEnabled()
                            .withVoiceSearchHidden()
                            .build(applicationContext)
                        startActivityForResult(locationPickerIntent, MAP_BUTTON_REQUEST_CODE)
                    }, {

                    })
                }
            }
    }

    @SuppressLint("CheckResult")
    private fun handlePickImage() {
        RxPermissions(this).request(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
            .subscribe { granted ->
                if (granted) {
                    imagePicker = ImagePicker(this)
                    imagePicker?.apply {
                        setListener(object : ImagePicker.ImagePickerListener {
                            override fun onPickSuccess(uri: Uri?, tag: String) {
                                viewModel.addBarRequestLiveData.value?.avatar = File(uri?.path)
                                Glide.with(this@AddBarActivity)
                                    .load(viewModel.addBarRequestLiveData.value?.avatar)
                                    .into(ivUpload)
                            }
                        })
                        setAuthority("vn.app.tcs.provider")
                        needCropAfterPick(true)
                        showAlertDialog()
                    }
                } else {
                    toast("need read external permission")
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        imagePicker?.onActivityResult(imagePicker!!, requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && data != null) {
            viewModel.addBarRequestLiveData.value?.apply {
                name = etBarName.text.toString()
            }
            if (requestCode == MAP_BUTTON_REQUEST_CODE) {
                viewModel.addBarRequestLiveData.value?.apply {
                    latitude = data.getDoubleExtra(LATITUDE, 0.0)
                    longitude = data.getDoubleExtra(LONGITUDE, 0.0)
                    address = data.getStringExtra(LOCATION_ADDRESS)
                }
                viewModel.addBarRequestLiveData.notifyObserver()
            }
            if (requestCode == ADD_BAR_REQUEST_CODE) {
                viewModel.addBarRequestLiveData.value?.apply {
                    listRoom =
                        data.getParcelableArrayListExtra<Bar.Room>(KEY_LIST_ROOM) as ArrayList<Bar.Room>
                }
                viewModel.addBarRequestLiveData.notifyObserver()
            }
        }
    }
}
