package vn.app.tcs.ui.home

interface NavigationListener {
    fun setNavigationOnClick(menuItemId: Int)
}