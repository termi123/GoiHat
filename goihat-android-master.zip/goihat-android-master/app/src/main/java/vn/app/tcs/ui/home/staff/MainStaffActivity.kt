package vn.app.tcs.ui.home.staff

import android.Manifest
import android.annotation.SuppressLint
import android.os.Bundle
import androidx.databinding.Observable
import androidx.fragment.app.Fragment
import com.base.common.constant.AppConstant
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.tbruyelle.rxpermissions2.RxPermissions
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.startActivity
import timber.log.Timber
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.service.LocationService
import vn.app.tcs.ui.fraud.FraudAlertFragment
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.notify.NotifyFragment
import vn.app.tcs.ui.registerbar.FragmentRegisterBar
import vn.app.tcs.ui.staffhistorycall.StaffCallHistoryFragment
import vn.app.tcs.ui.staffhome.StaffHomeFragment

class MainStaffActivity : MainActivity() {

    override fun getDefaultFragmentTag(): String {
        return StaffCallHistoryFragment.TAG
    }

    override fun getNavigationMenu(): Int {
        return R.menu.drawer_staff
    }

    override fun getDefaultFragment(): Fragment {
        toolbarTitle.text = "Quản lý cuộc gọi"
        return StaffCallHistoryFragment.newInstance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LocationService.init(this)
        viewModel.setUpLocationSchedule()
        updateStatusMenu(true)
        database.child("users").child(userManager.getUserInfo()?.id.toString()).child("status")
            .addValueEventListener(object : ValueEventListener {
                override fun onCancelled(databaseError: DatabaseError) {
                    Timber.d("loadPost:%s", databaseError.toException())
                }

                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (!dataSnapshot.exists()) return
                    val p = userManager.getUserInfo()
                    p?.activity = dataSnapshot.getValue(String::class.java).toString()
                    updateStatusMenu(p?.activity == AppConstant.Activity.Online.name)
                }
            })

    }

    override fun openDefaultFragment() {
        toolbarTitle.text = "Ca sĩ"
        showManagementFragment(StaffHomeFragment.newInstance(), StaffHomeFragment.TAG)
    }

    override fun setNavigationOnClick(menuItemId: Int) {
        when (menuItemId) {
            R.id.navPayment -> {
                toolbarTitle.text = "Ca sĩ"
                showManagementFragment(StaffHomeFragment.newInstance(), StaffHomeFragment.TAG)
            }
            R.id.callHistory -> {
                toolbarTitle.text = "Quản lý cuộc gọi"
                showManagementFragment(
                    StaffCallHistoryFragment.newInstance(),
                    StaffCallHistoryFragment.TAG
                )
            }
            R.id.fraudAlert -> {
                toolbarTitle.text = "Cảnh báo Hệ thống"
                showManagementFragment(FraudAlertFragment.newInstance(), FraudAlertFragment.TAG)
            }
            R.id.sysAlert -> {
                toolbarTitle.text = "Danh sách thông báo"
                showManagementFragment(NotifyFragment.newInstance(), NotifyFragment.TAG)
            }
            R.id.callRegister -> {
                startActivity<FragmentRegisterBar>()
            }
        }
    }

    @SuppressLint("CheckResult")
    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        super.onReceiverMessage(sender, propertyId)
        if (propertyId == EventConstant.EVENT_GET_LOCATION) {
            RxPermissions(this).request(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
                .subscribe { granted ->
                    if (granted) {
                        LocationService.getLocation(this, {
                            viewModel.sendLocation(it.latitude, it.longitude)
                        }, {

                        })
                    }
                }
        }
    }

}