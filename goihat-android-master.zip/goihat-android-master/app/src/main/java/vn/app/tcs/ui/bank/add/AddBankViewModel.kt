package vn.app.tcs.ui.bank.add

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.constant.AppConstant
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.data.remote.usecase.DeleteBankUseCase
import vn.app.tcs.data.remote.usecase.RegisterBankUseCase
import vn.app.tcs.data.remote.usecase.UpdateBankUseCase
import vn.app.tcs.data.request.AddBarRequest

class AddBankViewModel : BaseViewModel() {
    private val registerBankUseCase: RegisterBankUseCase by inject()
    private val updateBankUseCase: UpdateBankUseCase by inject()
    private val deleteBarUseCase: DeleteBankUseCase by inject()

    var type: AppConstant.BarActionType = AppConstant.BarActionType.Add
    var addBankRequestLiveData = MutableLiveData<ListBank.BankInfo>()
    var deleteBar = MutableLiveData<Int>()

    var updateBankResult: LiveData<List<String>> = Transformations.map(updateBankUseCase.result) {
        handleCommonApi(it)
    }
    var addBankResult: LiveData<List<String>> = Transformations.map(registerBankUseCase.result) {
        handleCommonApi(it)
    }
    var deleteBarResult: LiveData<List<String>> = Transformations.map(deleteBarUseCase.result) {
        handleCommonApi(it)
    }
    init {
        addBankRequestLiveData.value = ListBank.BankInfo()
    }

    fun setRequest(bank: ListBank.BankInfo) {
        addBankRequestLiveData.value = bank;
    }

    fun updateBar(id: Int?) {
        updateBankUseCase.apply {
            idBank = id ?: 0
            addBarRequest = addBankRequestLiveData.value!!
        }.executeZip({
            sendEvent(EventConstant.EVENT_UPDATE_BAR_SUCCESS)
        }, {})
    }

    fun addBank() {
        registerBankUseCase.apply {
            addBarRequest = addBankRequestLiveData.value!!
        }.executeZip({
            sendEvent(EventConstant.EVENT_ADD_BAR_SUCCESS)
        }, {})
    }

    fun deleteBar(idBar: Int) {
        deleteBarUseCase.apply { id = idBar }.executeZip(
            {
                deleteBar.postValue(idBar)
            }, {}
        )
    }

    fun doActionBar() = when (type) {
        AppConstant.BarActionType.Add -> sendEvent(EventConstant.EVENT_ADD_BAR)
        AppConstant.BarActionType.Edit, AppConstant.BarActionType.View -> sendEvent(EventConstant.EVENT_EDIT_BAR)
    }

    fun doDelete() = sendEvent(EventConstant.EVENT_DELETE_BAR)
}