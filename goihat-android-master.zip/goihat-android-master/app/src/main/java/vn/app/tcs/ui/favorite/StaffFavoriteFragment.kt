package vn.app.tcs.ui.favorite

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.base.common.constant.AppConstant
import kotlinx.android.synthetic.main.fragment_staff_list.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraListFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.FragmentStaffFavoriteListBinding
import vn.app.tcs.ui.staffdetail.StaffDetailActivity
import vn.app.tcs.ui.stafflist.adapter.StaffAdapter

class StaffFavoriteFragment : BaseKaraListFragment<FragmentStaffFavoriteListBinding, StaffFavoriteViewModel,ListStaff.Staff>() {
    override val recyclerView: RecyclerView by lazy { rvManager }
    override val viewModel: StaffFavoriteViewModel  by viewModel()
    override val layoutId: Int
        get() = R.layout.fragment_staff_favorite_list

    var data = ArrayList<ListStaff.Staff>()
    override val adapter : StaffAdapter by lazy {  StaffAdapter(requireActivity(),data) }
    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_UPDATE_STATUS) {
            viewModel.favorite.value?.staff?.let { adapter.setDataList(it) }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.favorite.observe(viewLifecycleOwner, Observer { staffList ->
            run {
                staffList?.let {
                    adapter.totalPage = it.lastPage
                    handlerLoadData(it.staff)
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        viewModel.reset()
    }

    override fun onClickRecycleViewItem(item: ListStaff.Staff) {
        super.onClickRecycleViewItem(item)
        startActivity<StaffDetailActivity>(
            EventConstant.KEY_STAFF_DETAIL to item.id.toString(),
            EventConstant.KEY_STAFF_FAVORITE to true
        )
    }

    companion object {
        val TAG = StaffFavoriteFragment::class.java.getName()
        fun newInstance(): StaffFavoriteFragment {
            val fragment = StaffFavoriteFragment()
            return fragment
        }
    }

}