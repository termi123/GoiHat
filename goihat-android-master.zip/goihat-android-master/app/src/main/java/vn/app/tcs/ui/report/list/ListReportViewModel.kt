package vn.app.tcs.ui.report.list

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.data.karaconstant.DEFAULT_PAGE
import vn.app.tcs.data.model.ListBlackList
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.remote.usecase.*

class ListReportViewModel : BaseListViewModel() {
//    private val getListBlackListUseCase: GetListBlackListUseCase by inject()
//    val listBlackList: LiveData<ListBlackList> = Transformations.map(getListBlackListUseCase.result) {
//        handleCommonApi(it)
//    }
    private val getListChangeCodeUseCase: GetListChangeCodeUseCase by inject()
    val listChangeCode: LiveData<ListChangeCode> = Transformations.map(getListChangeCodeUseCase.result) {
        handleCommonApi(it)
    }
//    private val getListRejectUseCase: GetRejectUseCase by inject()
//    val listReject: LiveData<ListRejectOrder> = Transformations.map(getListRejectUseCase.result) {
//        handleCommonApi(it)
//    }

    private val setReportReadUseCase: SetReportReadUseCase by inject()

    val emptyList = MutableLiveData<Boolean>()
    val refreshing = MutableLiveData<Boolean>()

    init {
//        getListBlackList()
        getListChangeCode()
//        getListReject()
    }

//    private fun getListBlackList() {
//        getListBlackListUseCase.apply {
//            pageList = page
//        }.executeZip({
//            emptyList.value = it.lists?.isEmpty()
//            refreshing.value = false
//        }, {
//            refreshing.value = false
//        })
//    }

    private fun getListChangeCode() {
        getListChangeCodeUseCase.apply {
            pageList = page
        }.executeZip({
            emptyList.value = it.lists?.isEmpty()
            refreshing.value = false
        }, {
            refreshing.value = false
        })
    }

//    private fun getListReject() {
//        getListRejectUseCase.apply {
//            pageList = page
//        }.executeZip({
//            emptyList.value = it.lists?.isEmpty()
//            refreshing.value = false
//        }, {
//            refreshing.value = false
//        })
//    }

    fun refresh(position: Int){
        page = DEFAULT_PAGE
        when(position) {
//            0 -> getListBlackList()
//            1 -> getListReject()
            0 -> getListChangeCode()
        }
    }

    fun loadList(position: Int){
        when(position) {
//            0 -> getListBlackList()
//            1 -> getListReject()
            0 -> getListChangeCode()
        }
    }

    fun setRead(id: Int, type: String) {
        setReportReadUseCase.apply {
            idReport = id
            typeReport = type
        }.execute()
    }
}