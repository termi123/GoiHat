package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class ActivityRequest(
    @SerializedName("activity")
    var activity: String
) {
//    override fun equals(other: Any?): Boolean {
//        if (this === other) return true
//        if (javaClass != other?.javaClass) return false
//
//        other as ActivityRequest
//
//        if (activity != other.activity) return false
////        if (!staffId.contentEquals(other.staffId)) return false
//
//        return true
//    }

//    override fun hashCode(): Int {
//        var result = activity.hashCode()
//        result = 31 * result + staffId.contentHashCode()
//        return result
//    }
}