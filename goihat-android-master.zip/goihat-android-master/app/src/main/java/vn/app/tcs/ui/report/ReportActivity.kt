package vn.app.tcs.ui.report

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_report.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.DEFAULT_REPORT_TIME
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.ActivityReportBinding

class ReportActivity : BaseKaraToolbarActivity<ActivityReportBinding, ReportViewModel>() {
    override fun getToolBar(): Toolbar = toolbar
    override val layoutId: Int
        get() = R.layout.activity_report
    override val viewModel: ReportViewModel by inject()
    val order: Int by lazy { intent!!.extras!!.getInt(EventConstant.KEY_ORDER_DETAIL) }
    val createDate: String? by lazy { intent!!.extras!!.getString(EventConstant.KEY_CREATE_DATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.order = order
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if (event.tag == "REPORT" || event.tag == "TIME_OUT") {
            finish()
        }
    }

    override fun setUpObserver() {
        super.setUpObserver()
        viewModel.reportResult.observe(this, Observer {

        })
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_SEND_REPORT -> validReport()
            EventConstant.EVENT_CHECK_REPORT -> showDialogMessage(MessageDialog(content = "Hệ thống đã ghi nhận Báo Cáo của bạn. Chúng tôi sẽ phản hồi trong thời gian sớm nhất").apply {
                tag = "REPORT"
            })
        }
    }

    private fun validReport() {
        if (createDate != null) {
            if (System.currentTimeMillis() > (createDate!!.toLong() + DEFAULT_REPORT_TIME) * 1000) {
                showDialogMessage(MessageDialog(content = "Đã quá thời gian cho phép báo cáo (24 giờ từ lúc sự kiện được tạo), bạn không thể BÁO CÁO sự kiện này nữa").apply {
                    tag = "TIME_OUT"
                })
                return
            }
        }
        if (etTitle.text.isNullOrBlank()) {
            showDialogMessage(MessageDialog(content = "Xin vui lòng điền tiêu đề báo cáo"))
            return
        }
        if (etDescription.text.isNullOrBlank()) {
            showDialogMessage(MessageDialog(content = "Xin vui lòng điền nội dung báo cáo"))
            return
        }
        viewModel.sendReport(etTitle.text.toString(), etDescription.text.toString())
    }
}
