package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.BarManagementRepository
import vn.app.tcs.data.request.AddBarRequest

class RegisterBarUseCase : UseCase<ArrayList<String>>() {

    private val barManagementRepository: BarManagementRepository by inject()
    lateinit var addBarRequest: AddBarRequest
    override fun buildUseCaseObservable(): Single<ArrayList<String>> {
        return barManagementRepository.registerBar(addBarRequest)
    }
}