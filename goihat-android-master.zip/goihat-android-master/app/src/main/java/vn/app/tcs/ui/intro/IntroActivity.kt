package vn.app.tcs.ui.intro

import android.os.Bundle
import androidx.databinding.Observable
import androidx.viewpager2.widget.ViewPager2
import com.base.common.base.activity.BaseMVVMActivity
import com.base.common.constant.AppConstant
import com.rd.animation.type.AnimationType
import kotlinx.android.synthetic.main.activity_intro.*
import org.jetbrains.anko.sdk27.coroutines.onClick
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.databinding.ActivityIntroBinding
import vn.app.tcs.ui.intro.detail.DetailIntroFragment


class IntroActivity : BaseMVVMActivity<ActivityIntroBinding, IntroViewModel>() {
    override val layoutId: Int
        get() = R.layout.activity_intro
    override val viewModel: IntroViewModel by inject()
    val userManager: UserManager by inject()
    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val adapter = ViewPagerFragmentAdapter(this)
        viewModel.isFromMenu.value = false
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    viewModel.isFromMenu.value = ex.getBoolean(EventConstant.KEY_GUIDE, false)
                }
            }
        }
        adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.term))
        when (userManager.getUserInfo()?.role) {
            AppConstant.Role.Staff.name -> {
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_staff_1))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_staff_2))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_staff_3))
            }
            AppConstant.Role.Owner.name -> {
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_owner1))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_owner2))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_owner3))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_owner4))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_owner5))
            }
            AppConstant.Role.Manager.name -> {
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager1))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager2))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager3))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager4))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager5))
                adapter.addFragment(DetailIntroFragment.newInstance(R.drawable.tutor_manager6))
            }
        }
        vpIntro.adapter = adapter
        pageIndicatorView.count = adapter.itemCount
        pageIndicatorView.setAnimationType(AnimationType.WORM)
        vpIntro.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                pageIndicatorView.selection = position
                viewModel.showStart.value = (adapter.itemCount == position + 1) && viewModel.isFromMenu.value == false
            }
        })


        btStart.onClick {
            userManager.setHideIntro()
            finish()
        }
        btClose.onClick {
            finish()
        }
    }


}
