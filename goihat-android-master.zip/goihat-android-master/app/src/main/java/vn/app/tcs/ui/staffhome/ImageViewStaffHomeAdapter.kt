package vn.app.tcs.ui.staffhome

import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseLifecycleAdapter
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.base.adapter.BaseVMAdapter
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.ItemViewStaffBinding

class ImageViewStaffHomeAdapter (var activity: FragmentActivity, var fragment: StaffHomeFragment, listImage: ArrayList<WrapperImageStaff>) :

    BaseVMAdapter<WrapperImageStaff, ImageViewModel>(listImage) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffImageViewHolder(parent?.inflateExt(R.layout.item_view_staff)!!, activity, this)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffImageViewHolder) {
            list[position].apply {
                if (!viewModelProvide.contains(id)) {
                    viewModelProvide.put(id, ImageViewModel())
                }
                holder.onBind(this, fragment, viewModelProvide.get(id), position)
            }
        }
    }

    class StaffImageViewHolder(
        view: View,
        activity: FragmentActivity,
        var adapter: ImageViewStaffHomeAdapter
    ) :
        BaseLifecycleAdapter<WrapperImageStaff, ItemViewStaffBinding, ImageViewModel>(
            view,
            activity
        ) {
        var positionItem = -1

        fun onBind(item: WrapperImageStaff, fragment: StaffHomeFragment, viewModelItem: ImageViewModel, position: Int) {
            this.viewModel = viewModelItem
            this.positionItem = position
            viewModel.mainViewModel = fragment.viewModel
            onBind(item)
        }

        override fun onBind(item: WrapperImageStaff) {
            super.onBind(item)
            viewModel.staffImage.value = item
        }
    }
}