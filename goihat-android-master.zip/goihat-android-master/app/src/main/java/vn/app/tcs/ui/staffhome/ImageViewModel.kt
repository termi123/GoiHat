package vn.app.tcs.ui.staffhome

import vn.app.tcs.ui.profile.adapter.ImageStaffItemBaseViewModel

class ImageViewModel : ImageStaffItemBaseViewModel<StaffHomeViewModel>() {
}