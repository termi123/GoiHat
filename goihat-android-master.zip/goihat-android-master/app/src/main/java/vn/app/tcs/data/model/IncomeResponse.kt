package vn.app.tcs.data.model

import com.google.gson.annotations.SerializedName

data class IncomeResponse(@SerializedName("revenue") var revenue: String,@SerializedName("profile") var profile: UserProfile.Profile) {
}