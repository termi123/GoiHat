package vn.app.tcs.ui.report.list

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter.OnClickItemListener
import com.base.common.data.event.MessageDialog
import com.flyco.tablayout.listener.OnTabSelectListener
import kotlinx.android.synthetic.main.staff_call_history_fragment.*
import org.jetbrains.anko.support.v4.onRefresh
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.databinding.ReportListFragmentBinding
import vn.app.tcs.ui.home.staff.MainStaffActivity

class ListReportFragment :
    BaseKaraFragment<ReportListFragmentBinding, ListReportViewModel>(), OnTabSelectListener {
//    private val gson: Gson by inject()
    override val layoutId: Int
        get() = R.layout.report_list_fragment
    override val viewModel: ListReportViewModel by inject()
    private var currentTab = 0

    //    private val adapterBlackList: BlackListAdapter by lazy {
//        BlackListAdapter(
//            ArrayList()
//        )
//    }
//    private val adapterReject: RejectListAdapter by lazy {
//        RejectListAdapter(
//            ArrayList()
//        )
//    }
    private val adapterChangeCode: ChangeCodeListAdapter by lazy {
        ChangeCodeListAdapter(
            ArrayList()
        )
    }

    val tabData = arrayOf(/*"Gian lận", "Bị out", */"Đổi mã")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        setUpBlackListAdapter()
        setUpChangeCodeAdapter()
        viewModel.emptyList.observe(viewLifecycleOwner, Observer {
//            if (currentTab == 0 && adapterBlackList.getPageCount() == 1) {
//                tvEmpty.text = "Không có hành vi gian lận nào từ ca sĩ"
//            }
            if (currentTab == 0 && adapterChangeCode.getPageCount() == 1) {
                tvEmpty.text = "Không có yêu cầu"
                tvEmpty.visibility = View.VISIBLE
            } else {
                tvEmpty.visibility = View.GONE
            }
        })
//        viewModel.listBlackList.observe(viewLifecycleOwner, Observer { list ->
//            run {
//                list?.let {
//                    if (it.lists == null) return@let
//                    adapterBlackList.totalPage = it.lastPage
//                    if (viewModel.page < it.lastPage && it.lists.isNotEmpty()) viewModel.page++
//                    if (it.currentPage == 1) {
//                        adapterBlackList.setDataList(it.lists as ArrayList<ListBlackList.BlackList>)
//                    } else {
//                        adapterBlackList.addLoadMoreData(it.lists as ArrayList<ListBlackList.BlackList>)
//                    }
//                }
//            }
//        })
        viewModel.listChangeCode.observe(viewLifecycleOwner, Observer { list ->
            run {
                list?.let {
                    if (it.lists == null) return@let
                    adapterChangeCode.totalPage = it.lastPage
                    if (viewModel.page < it.lastPage && it.lists.isNotEmpty()) viewModel.page++
                    if (it.currentPage == 1) {
                        adapterChangeCode.setDataList(it.lists as ArrayList<ListChangeCode.ChangeCode>)
                    } else {
                        adapterChangeCode.addLoadMoreData(it.lists as ArrayList<ListChangeCode.ChangeCode>)
                    }
                }
            }
        })
//        viewModel.listReject.observe(viewLifecycleOwner, Observer { list ->
//            run {
//                list?.let {
//                    if (it.lists == null) return@let
//                    adapterReject.totalPage = it.lastPage
//                    if (viewModel.page < it.lastPage && it.lists.isNotEmpty()) viewModel.page++
//                    if (it.currentPage == 1) {
//                        adapterReject.setDataList(it.lists as ArrayList<ListRejectOrder.RejectOrder>)
//                    } else {
//                        adapterReject.addLoadMoreData(it.lists as ArrayList<ListRejectOrder.RejectOrder>)
//                    }
//                }
//            }
//        })

        viewModel.refreshing.observe(this, Observer {
            if (swRefresh.isRefreshing) {
                swRefresh.isRefreshing = false
            }
        })
        swRefresh.onRefresh {
            refresh()
        }
        tabOption.setTabData(tabData)
        tabOption.setOnTabSelectListener(this)

    }

//    private fun setUpBlackListAdapter() {
//        rvHistory.layoutManager =
//            LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
//        rvHistory.adapter = adapterBlackList
//        adapterBlackList.setOnClickListener(object : OnClickItemListener<ListBlackList.BlackList> {
//            override fun onClickItem(item: ListBlackList.BlackList, position : Int) {
//                showDialogMessage(MessageDialog(getString(R.string.app_name), item.getFullDes(), confirmButton = "OK"))
//                if (!item.readAt.isBlank()) return
//                viewModel.setRead(item.id, "blacklist")
//                val index = adapterBlackList.getDataList().indexOf(item)
//                if (index != -1) {
//                    adapterBlackList.getDataList()[index].readAt = System.currentTimeMillis().toString()
//                    adapterBlackList.notifyItemChanged(index)
//                }
//            }
//
//        })
//        adapterBlackList.setUpRecycleViewLoadMore(rvHistory)
//        adapterBlackList.loadMore().observe(viewLifecycleOwner, Observer {
//            loadList()
//        })
//    }
//
//    private fun setUpRejectAdapter() {
//        rvHistory.layoutManager =
//            LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
//        rvHistory.adapter = adapterReject
//        adapterReject.setOnClickListener(object : OnClickItemListener<ListRejectOrder.RejectOrder> {
//            override fun onClickItem(item: ListRejectOrder.RejectOrder, position : Int) {
//                if (item.readAt.isBlank()) {
//                    viewModel.setRead(item.id, "reject-order")
//                    val index = adapterReject.getDataList().indexOf(item)
//                    if (index != -1) {
//                        adapterReject.getDataList()[index].readAt =
//                            System.currentTimeMillis().toString()
//                        adapterReject.notifyItemChanged(index)
//                    }
//                }
//                startActivity<ReportDetailActivity>(
//                    EventConstant.KEY_REPORT_REJECT_DETAIL to gson.toJson(item)
//                )
//            }
//
//        })
//        adapterReject.setUpRecycleViewLoadMore(rvHistory)
//        adapterReject.loadMore().observe(viewLifecycleOwner, Observer {
//            loadList()
//        })
//    }

    private fun setUpChangeCodeAdapter() {
        rvHistory.layoutManager =
            LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        rvHistory.adapter = adapterChangeCode
        adapterChangeCode.setOnClickListener(object :
            OnClickItemListener<ListChangeCode.ChangeCode> {
            override fun onClickItem(item: ListChangeCode.ChangeCode, position: Int) {
                showDialogMessage(
                    MessageDialog(
                        "Thông báo",
                        item.getFullDes(),
                        confirmButton = "OK"
                    )
                )
                if (!item.readAt.isBlank()) return
                viewModel.setRead(item.id, "change-code-request")
                val index = adapterChangeCode.getDataList().indexOf(item)
                if (index != -1) {
                    adapterChangeCode.getDataList()[index].readAt =
                        System.currentTimeMillis().toString()
                    adapterChangeCode.notifyItemChanged(index)
                }
            }

        })
        adapterChangeCode.setUpRecycleViewLoadMore(rvHistory)
        adapterChangeCode.loadMore().observe(viewLifecycleOwner, Observer {
            loadList()
        })
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }

    companion object {
        val TAG = ListReportFragment::class.java.simpleName
        fun newInstance(): ListReportFragment {
            return ListReportFragment()
        }
    }

    override fun onTabSelect(position: Int) {
        currentTab = position
        setUpAdapter(position)
        refresh()
        viewModel.emptyList.value = false
//        adapterBlackList.resetPage()
        adapterChangeCode.resetPage()
//        adapterReject.resetPage()
    }

    private fun setUpAdapter(position: Int) {
//        when (position) {
//            0 -> setUpBlackListAdapter()
//            1 -> setUpRejectAdapter()
//            2 -> setUpChangeCodeAdapter()
//        }
        setUpChangeCodeAdapter()
    }

    override fun onTabReselect(position: Int) {}

    override fun onResume() {
        super.onResume()
        if (activity is MainStaffActivity) {
            (activity as MainStaffActivity).viewDataBinding?.ivTop?.visibility = View.GONE
        }
        refresh()
    }

    private fun refresh() {
        if (activity == null || !isAdded) {
            return
        }
        viewModel.refresh(currentTab)
    }

    private fun loadList() {
        if (activity == null || !isAdded) {
            return
        }
        viewModel.loadList(currentTab)
    }
}