package vn.app.tcs.ui.profile.detail

import android.os.Bundle
import android.view.View
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.databinding.ImageStaffDetailFragmentBinding

class ImageStaffDetailFragment : BaseKaraFragment<ImageStaffDetailFragmentBinding,ImageStaffDetailViewModel>() {
    override val layoutId: Int
        get() = R.layout.image_staff_detail_fragment
    override val viewModel: ImageStaffDetailViewModel by inject()

    companion object {
        fun newInstance(resources : String) = ImageStaffDetailFragment().apply {
            viewModel.resource.value = resources
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


}
