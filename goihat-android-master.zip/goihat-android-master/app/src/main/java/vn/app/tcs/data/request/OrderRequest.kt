package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class OrderRequest(
    @SerializedName("bar_id")
    var barId: Int = 0,
    @SerializedName("number_staffs_required ")
    var numberStaffsRequired: Int = 0,
    @SerializedName("staff_id")
    var staffDd: Array<Int>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as OrderRequest

        if (barId != other.barId) return false
        if (numberStaffsRequired != other.numberStaffsRequired) return false
        if (!staffDd.contentEquals(other.staffDd)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = barId
        result = 31 * result + numberStaffsRequired
        result = 31 * result + staffDd.contentHashCode()
        return result
    }
}
