package vn.app.tcs.ui.register

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.widget.ArrayAdapter
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.StringUtils
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.bumptech.glide.Glide
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_register.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.toast
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.request.UserRegisterRequest
import vn.app.tcs.databinding.ActivityRegisterBinding
import vn.app.tcs.ui.home.dialog.CallSupportDialog
import vn.app.tcs.ui.term.TermActivity
import vn.app.tcs.utils.imagepicker.ImagePicker
import java.io.File

class RegisterActivity : BaseKaraToolbarActivity<ActivityRegisterBinding, RegisterViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_register

    override val viewModel: RegisterViewModel by viewModel()
    private var imagePicker: ImagePicker? = null

    private val listRoles = arrayOf(
        AppConstant.Role.Manager.name,
        AppConstant.Role.Owner.name,
        AppConstant.Role.Staff.name
    )

    private val listRolesDisplay: Array<String> by lazy {
        arrayOf(
            getString(R.string.manager_event),
            getString(R.string.manager_singer),
            getString(R.string.singer)
        )
    }

    private var agreeTerms = false

    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initSpinnerAdapter()
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Back -> finish()
            AppConstant.DialogState.Call -> {
                if(event.tag == "Call_Support"){
                    CallSupportDialog.getInstance().show(supportFragmentManager, "")
                }
            }
            else -> { }
        }
    }

    private fun initSpinnerAdapter() {
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item, listRolesDisplay
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spRole.adapter = adapter
    }

    @SuppressLint("RestrictedApi")
    override fun setUpObserver() {
        super.setUpObserver()
        viewModel.categoryList = listRoles.toList()
        viewModel.itemPosition.observe(this, Observer {
            viewDataBinding?.needShowRefCode = it == 2
        })
        viewModel.agreeTerms.observe(this, Observer {
            agreeTerms = it
            btLogin.supportBackgroundTintList = ContextCompat.getColorStateList(this,if(it) R.color.Dark_Slate_Blue else R.color.Gray  )
        })
        viewModel.userRegister.observe(this, Observer { userProfile ->
            userProfile?.let {
                showDialog2ButtonMessage(
                    MessageDialog(
                        getString(R.string.app_name), getString(R.string.register_successfully),
                        "Gọi CSKH", "Ok"
                    ).apply {
                        tag = "Call_Support"
                    }
                )
            }
        })
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_REGISTER -> handleLogin(
                etUserName.text.toString(),
                etPhone.text.toString(),
                etPassword.text.toString(),
                etConfirmPassword.text.toString(),
                listRoles[spRole.selectedItemId.toInt()],
                etRef.text.toString()
            )
            EventConstant.EVENT_PICK_IMAGE -> handlePickImage()
            EventConstant.EVENT_TERM -> startActivity<TermActivity>()
        }
    }

    @SuppressLint("CheckResult")
    private fun handlePickImage() {
        RxPermissions(this).request(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
            .subscribe { granted ->
                if (granted) {
                    imagePicker = ImagePicker(this)
                    imagePicker?.apply {
                        setListener(object : ImagePicker.ImagePickerListener {
                            override fun onPickSuccess(uri: Uri?,tag : String) {
                                viewModel.avatar = File(uri?.path)
                                Glide.with(this@RegisterActivity).load(viewModel.avatar)
                                    .into(ivUpload)
                            }
                        })
                        setAuthority("vn.app.tcs.provider")
                        needCropAfterPick(true)
                        showAlertDialog()
                    }
                } else {
                    toast("need read external permission")
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        imagePicker?.onActivityResult(imagePicker!!, requestCode, resultCode, data)
    }

    private fun handleLogin(
        username: String,
        phone: String,
        password: String,
        confirmPassword: String,
        role: String,
        refCode: String
    ) {
        if (TextUtils.isEmpty(username)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_USERNAME))
            return
        }
        if (username.trim().run {
                length < 1 || length > 16
            }) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_USERNAME))
            return
        }
        if (TextUtils.isEmpty(phone)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_PHONE))
            return
        }
        if (phone.run { length != 10 }) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_PHONE))
            return
        }
        if(phone.length != 10){
            showDialogMessage(MessageDialog(getString(R.string.app_name),"Số điện thoại không chính xác. Xin vui lòng nhập lại."))
            return
        }
        if(phone.length != 10){
            showDialogMessage(MessageDialog(getString(R.string.app_name),"Số điện thoại không chính xác. Xin vui lòng nhập lại."))
            return
        }
        if (TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_PASS))
            return
        }
        if (password.trim().run {
                length < 6 || length > 10
            }) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.WRONG_PASS))
            return
        }
        if (password != confirmPassword) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.PASS_MATCH))
            return
        }
        if (TextUtils.isEmpty(role)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_ROLE))
            return
        }
        if (role == AppConstant.Role.Staff.name && TextUtils.isEmpty(refCode)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_REF))
            return
        }
        if (role == AppConstant.Role.Staff.name && !StringUtils.isValidREF(refCode)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_REF))
            return
        }
        if (!agreeTerms) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_TERM))
            return
        }
        if (viewModel.avatar == null) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.EMPTY_AVATAR))
            return
        }
        viewModel.register(UserRegisterRequest(username, phone, password, role, refCode))
    }
}
