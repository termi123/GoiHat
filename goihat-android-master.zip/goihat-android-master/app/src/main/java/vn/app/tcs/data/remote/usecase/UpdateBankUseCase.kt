package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.data.remote.BankManagement

class UpdateBankUseCase : UseCase<List<String>>() {

    lateinit var addBarRequest: ListBank.BankInfo
    var idBank: Int = 0

    private val barManagementRepository: BankManagement by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return barManagementRepository.updateBank(idBank, addBarRequest)
    }

}