package vn.app.tcs.ui.call.select


import androidx.fragment.app.FragmentActivity
import vn.app.tcs.data.model.ListStaff

class StaffFavoriteAvailableAdapter(
    activity: FragmentActivity,
    data: ArrayList<ListStaff.Staff>
) :
    BaseSelectStaffAdapter(activity, data) {
    override val isFavorite: Boolean
        get() = true

}