package vn.app.tcs.ui.managercallhistory

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.manager_call_history_fragment.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraListFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.model.Order
import vn.app.tcs.databinding.ManagerCallHistoryFragmentBinding
import vn.app.tcs.ui.call.CallStaffActivity
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerActivity
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.managercallhistory.adapter.ManagerCallAdapter
import vn.app.tcs.ui.managercallhistory.history.HistoryEventActivity

class ManagerCallHistoryFragment :
    BaseKaraListFragment<ManagerCallHistoryFragmentBinding, ManagerCallHistoryViewModel, Order>() {

    override val recyclerView: RecyclerView by lazy { rvHistoryManager }
    override val layoutId: Int
        get() = R.layout.manager_call_history_fragment
    override val viewModel: ManagerCallHistoryViewModel by viewModel()
    var lists: ArrayList<Bar> = ArrayList()
    var isSurvey = false
    var isFirsTime = true

    override val adapter: ManagerCallAdapter by lazy {
        ManagerCallAdapter(
            ArrayList()
        )
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.isSurvey = isSurvey
        viewModel.showCall.value = !isSurvey
        viewModel.listOrderStaff.observe(viewLifecycleOwner, Observer { orderManager ->
            run {
                orderManager?.let {
                    adapter.totalPage = it.lastPage
                    handlerLoadData(it.lists)
                }
            }
        })
        viewModel.bars.observe(this, Observer { listBar ->
            run {
                listBar?.let {
                    viewDataBinding?.hasBar = !listBar.lists.isNullOrEmpty()
                    lists = it.lists
                }
            }
        })
        if (activity is MainActivity) {
            (activity as MainActivity).showHistory(true) {
                startActivity<HistoryEventActivity>()
            }
        }
        viewModel.reset()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (activity is MainActivity) {
            (activity as MainActivity).showHistory(false) {
                startActivity<HistoryEventActivity>()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if(isFirsTime || !isSurvey) {
            isFirsTime = false
            return
        }
        viewModel.reset()
        viewModel.getListBar()
    }

    override fun onClickRecycleViewItem(item: Order) {
        super.onClickRecycleViewItem(item)
        startActivity<OrderDetailManagerActivity>(EventConstant.KEY_ORDER_DETAIL to item.orderId)
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_CALL_STAFF) {
            startActivity<CallStaffActivity>(EventConstant.KEY_BAR_ORIGIN to lists)
        }
    }

    companion object {
        val TAG = ManagerCallHistoryFragment::class.java.getName()
        fun newInstance(survey: Boolean = false): ManagerCallHistoryFragment {
            return ManagerCallHistoryFragment().apply {
                this.isSurvey = survey
            }
        }
    }


}
