package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.remote.BarManagementRepository
import vn.app.tcs.data.request.AddBarRequest

class UpdateBarUseCase : UseCase<Bar>() {
    lateinit var addBarRequest: AddBarRequest
    private val barManagementRepository: BarManagementRepository by inject()
    override fun buildUseCaseObservable(): Single<Bar> {
        return barManagementRepository.updateBar(addBarRequest)
    }
}