package vn.app.tcs.ui.report.list

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.databinding.ItemListRejectBinding

class RejectListAdapter(data: ArrayList<ListRejectOrder.RejectOrder>) :
    BaseAdapter<ListRejectOrder.RejectOrder>(data) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffViewHolder(parent?.inflateExt(R.layout.item_list_reject)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffViewHolder) {
            holder.onBind(list[position])
        }

    }

    class StaffViewHolder(view: View) :
        BaseViewHolder<ListRejectOrder.RejectOrder, ItemListRejectBinding>(view) {
        override fun onBind(item: ListRejectOrder.RejectOrder) {
            binding.notify = item
        }

    }
}