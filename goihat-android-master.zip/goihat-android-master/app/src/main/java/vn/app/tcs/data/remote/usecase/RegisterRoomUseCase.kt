package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.remote.RoomManagementRepository

class RegisterRoomUseCase() : UseCase<Bar.ListRoom>() {

    var bar_id: Int = 0
    lateinit var listRoom: List<String>

    private val roomManagerRepository: RoomManagementRepository by inject()

    override fun buildUseCaseObservable(): Single<Bar.ListRoom> {
        return roomManagerRepository.registerRoom(bar_id, listRoom)
    }
}