package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.OrderRepository

class SetSurveyUseCase : UseCase<List<String>>() {
    private val orderRepositoryImpl: OrderRepository by inject()

    var orderId: Int = 0
    var numberStaffsRequired: Int = 0
    var numberStaffsNeeded: Int = 0

    override fun buildUseCaseObservable(): Single<List<String>> {
        return orderRepositoryImpl.setSurvey(orderId, numberStaffsRequired, numberStaffsNeeded)
    }
}