package vn.app.tcs.ui.changepass

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.ChangePasswordUseCase
import vn.app.tcs.data.request.ChangePassRequest
import vn.app.tcs.data.usermanager.UserManager

class ChangePassViewModel : BaseViewModel() {
    private val changePasswordUseCase: ChangePasswordUseCase by inject()
    var changePassResult: LiveData<ArrayList<String>>
    val userManager: UserManager by inject()

    fun doChangePass() = sendEvent(EventConstant.EVENT_CHANGE_PASS)
    init {
        changePassResult = Transformations.map(changePasswordUseCase.result) {
            handleCommonApi(it)
        }
    }
    fun changePassword(oldPass: String, newPass: String, confirmPass: String) {
        changePasswordUseCase.apply {
            changePassRequest = ChangePassRequest(oldPass, confirmPass, newPass)
        }.execute()
    }
    fun removeData() {
        userManager.setUserInfo(null)
        userManager.setIsUserLogin(false)
    }
}