package vn.app.tcs.ui.staffdetail

import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_staff_detail.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ImageStaffResponse
import vn.app.tcs.data.model.WrapperImageStaff
import vn.app.tcs.databinding.ActivityStaffDetailBinding
import vn.app.tcs.ui.dialog.EditDialog
import vn.app.tcs.ui.profile.slideshow.SlideShowActivity
import vn.app.tcs.utils.TimeUtil
import vn.app.tcs.utils.databinding.notifyObserver

class StaffDetailActivity : BaseKaraToolbarActivity<ActivityStaffDetailBinding, StaffViewModel>(),
    BaseAdapter.OnClickItemListener<WrapperImageStaff> {

    override fun onClickItem(item: WrapperImageStaff, position: Int) {
        startActivity<SlideShowActivity>(
            EventConstant.KEY_LIST_IMAGE to viewModel.staffInfo.value?.profile?.galleries,
            EventConstant.KEY_LIST_IMAGE_POSITION to position
        )
    }

    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_staff_detail
    override val viewModel: StaffViewModel by viewModel()
    private val tagEditFee = "editFee"

    val staff: String by lazy { intent!!.extras!!.getString(EventConstant.KEY_STAFF_DETAIL) }
    val needShowFavorite: Boolean by lazy { intent!!.extras!!.getBoolean(EventConstant.KEY_STAFF_FAVORITE, false) }
    private lateinit var menu: Menu
    private lateinit var favoriteMenuItem: MenuItem
    private val imageStaffAdapter: ImageViewStaffAdapter by lazy {
        ImageViewStaffAdapter(
            this, arrayListOf(
                WrapperImageStaff(null)
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initListImage()
        viewModel.staffInfo.observe(this, Observer {
            it?.let {
                if (::favoriteMenuItem.isInitialized) {
                    favoriteMenuItem.icon = ContextCompat.getDrawable(
                            this,
                            if (it.profile.isFavorite()) R.drawable.ic_favorite else R.drawable.ic_favorite_border
                    )
                }
                val list = it.profile.galleries
                val listWrap = arrayListOf<WrapperImageStaff>()
                for (item : ImageStaffResponse in list) {
                    listWrap.add(WrapperImageStaff.fromImageStaffResponse(item))
                }
                if (!listWrap.isNullOrEmpty()) {
                    rvImageStaff.visibility = View.VISIBLE
                    ivDefault.visibility = View.GONE
                    imageStaffAdapter.list = listWrap
                    imageStaffAdapter.notifyDataSetChanged()
                }
                viewModel.userStatus.value = it.profile.activity
                llStatus.post {
                    when {
                        viewModel.userStatus.value == "Online" -> llStatus.background = ContextCompat.getDrawable(this, R.drawable.bg_rounder_black_green)
                        viewModel.userStatus.value == "Offline" -> llStatus.background = ContextCompat.getDrawable(this, R.drawable.bg_round_gray_2)
                        else -> llStatus.background = ContextCompat.getDrawable(this, R.drawable.bg_rounder_yellow)
                    }
                }
                viewModel.userStatus.notifyObserver()
            }
        })
        viewModel.userStatus.observe(this, Observer {
            it?.let {
                run {
                    spStatus.text = getStatus(it)
                    tvOndesk.visibility = if(it == AppConstant.Activity.Ondesk.name) View.VISIBLE else View.GONE
                }
            }
        })
        viewModel.getInfoDetail(staff)
        viewModel.setDatabaseListener(database, staff)
        viewModel.updateFeeResult.observe(this, Observer {
            it?.let {
                if(it.isNotEmpty()){
                    viewModel.getInfoDetail(staff)
                }
            }
        })
    }

    private fun initListImage() {
        rvImageStaff.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rvImageStaff.adapter = imageStaffAdapter
        imageStaffAdapter.setOnClickListener(this)
    }

    private fun getStatus(status: String) = when (status) {
        "Online" -> "Online"
        "Offline" -> "Offline"
        "Selecting" -> "Đang được chọn"
        else -> ""
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_BACK -> finish()
            EventConstant.EVENT_FAVORITE -> {
                viewModel.getInfoDetail(staff)
            }
            EventConstant.EVENT_COPY -> {
                TimeUtil.setClipboard(viewModel.staffInfo.value?.profile?.ownerCode)
            }
            EventConstant.EVENT_COPY_USER -> {
                TimeUtil.setClipboard(viewModel.staffInfo.value?.profile?.code)
            }
            EventConstant.EVENT_CHANGE_MANAGER_FEE -> {
                showEditFee()
            }
            EventConstant.EVENT_SHOW_ALBUM -> {
                startActivity<SlideShowActivity>(
                    EventConstant.KEY_LIST_IMAGE to viewModel.staffInfo.value?.profile?.getAvatarGallery(),
                    EventConstant.KEY_LIST_IMAGE_POSITION to 0
                )
            }
        }
    }

    private fun showEditFee() {
        EditDialog.newInstance(
            MessageDialog(
                title = getString(R.string.manager_fee),
                content = "",
                cancelButton = getString(R.string.cancel),
                hint = "Nhập giá trị",
                tag = tagEditFee,
                inputType = InputType.TYPE_CLASS_NUMBER
            )
        ).show(supportFragmentManager, tagEditFee)
    }

    override fun handleEventDialog(event: RxEvent.EventDialog?) {
        super.handleEventDialog(event)
        if (event?.tag == tagEditFee && event.data is String) {
            if ((event.data as String).isEmpty()) {
                showDialogMessage(MessageDialog(content = "Phí quản lý không hợp lệ vui lòng thử lại"))
                return
            }
            try {
                viewModel.editManagerFee((event.data as String).toInt())
            } catch (e: NumberFormatException) {
                showDialogMessage(MessageDialog(content = "Phí quản lý không hợp lệ vui lòng thử lại"))
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (needShowFavorite) {
            menuInflater.inflate(R.menu.drawer_favorite, menu)
            this.menu = menu
            favoriteMenuItem = menu.findItem(R.id.favorite)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.favorite -> {
                viewModel.staffInfo.value?.let {
                    viewModel.favoriteStaff(staff, it.profile.getInvertFavorite())
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
