package vn.app.tcs.ui.staffhistorycall


import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.flyco.tablayout.listener.OnTabSelectListener
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.staff_call_history_fragment.*
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.runOnUiThread
import org.jetbrains.anko.support.v4.startActivity
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.karaconstant.DEFAULT_COUNT_DOWN_TIME
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_ORDER_DETAIL
import vn.app.tcs.data.model.Order
import vn.app.tcs.databinding.StaffCallHistoryFragmentBinding
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffActivity
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.home.staff.MainStaffActivity
import vn.app.tcs.ui.staffhistorycall.adapter.CallHistoryAdapter
import vn.app.tcs.ui.stafforder.StaffOrderActivity

class StaffCallHistoryFragment :
        BaseKaraFragment<StaffCallHistoryFragmentBinding, StaffCallHistoryViewModel>(),
        BaseAdapter.OnClickItemListener<Order>, OnTabSelectListener, CallHistoryAdapter.OnFinish {

    override fun onFinish() {
        orderId = 0
        isCalling = false
    }

    override val layoutId: Int
        get() = R.layout.staff_call_history_fragment
    override val viewModel: StaffCallHistoryViewModel by inject()
    private var currentTab = 0
    private var needSound: Boolean = false

    private val adapter: CallHistoryAdapter by lazy {
        CallHistoryAdapter(
                ArrayList()
        )
    }
    val tabData = arrayOf("Đang xử lý", "Đã kết thúc")
    private var lists: ArrayList<Order> = arrayListOf()
    private var orderId: Int = 0
    private var isCalling: Boolean = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvHistory.layoutManager =
                LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        rvHistory.adapter = adapter
        adapter.setOnClickListener(this)
        adapter.setOnFinish(this)
        adapter.setUpRecycleViewLoadMore(rvHistory)
        adapter.loadMore().observe(viewLifecycleOwner, Observer {
            viewModel.getList(viewModel.currentOption)
        })
        viewModel.getStaffActivityRequest.observe(this, Observer {
            it?.let { response ->
                response.data?.let {
                    run {
                        startActivity<OrderDetailStaffActivity>(
                            KEY_ORDER_DETAIL to it.orderId,
                            EventConstant.KEY_FROM_SPLASH to false
                        )
                        return@Observer
                    }
                }
            }
        })
        addDisposable(RxEvent.GetStaffRecentActivity::class.java) {
            viewModel.getStaffActivity()
        }
        viewModel.listOrderStaff.observe(viewLifecycleOwner, Observer { orderManager ->
            run {
                orderManager?.let {
                    adapter.totalPage = it.lastPage
                    lists = it.lists as ArrayList<Order>
                    val callItem = lists.find {
                        it.status == "New" && (it.createdAt.toLong() + DEFAULT_COUNT_DOWN_TIME) * 1000 > System.currentTimeMillis()
                    }
                    if (callItem != null && needSound) {
                        needSound = false
//                        startNotify()
                    }
                    if (orderId != 0 && isCalling) {
                        runOnUiThread {
                            lists.filter {
                                it.orderId == orderId
                            }.onEach { l -> l.isCalling = isCalling }
                            if (it.currentPage == 1) {
                                adapter.setDataList(lists)
                            } else {
                                adapter.addLoadMoreData(lists)
                            }
                        }
                        return@Observer
                    }
                    if (it.currentPage == 1) {
                        adapter.setDataList(lists)
                    } else {
                        adapter.addLoadMoreData(lists)
                    }
                }
            }
        })

        viewModel.refreshing.observe(this, Observer {
            if (swRefresh.isRefreshing) {
                swRefresh.isRefreshing = false
            }
        })
        swRefresh.onRefresh {
            viewModel.refresh(viewModel.currentOption)
        }
        tabOption.setTabData(tabData)
        tabOption.setOnTabSelectListener(this)
        addDisposable(RxEvent.EventReloadDetail::class.java) {
            handleReloadDetail()
        }
        addDisposable(RxEvent.EventReload::class.java) { event ->
            handleReload(event)
        }
    }

    private fun handleReloadDetail() {
        if(activity == null || !isAdded || isDetached){
            return
        }
        runOnUiThread {
            needSound = true
            orderId = 0
            isCalling = false
            lists.onEach { l -> l.isCalling = false }
            adapter.setDataList(lists)
            getList()
        }
    }

    private fun handleReload(event: RxEvent.EventReload) {
        if(activity == null || !isAdded || isDetached){
            return
        }
        if (orderId == event.orderId.toInt() && isCalling == event.isNew) {
            return
        }
        orderId = event.orderId.toInt()
        isCalling = event.isNew
        if (!isCalling) {
            orderId = 0
            isCalling = false
        }
        val find = lists.find { it.orderId == orderId }
        if (find != null) {
            runOnUiThread {
                lists.filter {
                    it.orderId == orderId
                }.onEach { l -> l.isCalling = isCalling }
                adapter.setDataList(lists)
            }
            return
        }
        getList()
    }

    override fun onClickItem(item: Order, position : Int) {
        startActivity<OrderDetailStaffActivity>(KEY_ORDER_DETAIL to item.orderId)
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_SELF_CALL_STAFF) {
            startActivity<StaffOrderActivity>()
        }
    }

    companion object {
        val TAG = StaffCallHistoryFragment::class.java.simpleName
        fun newInstance(): StaffCallHistoryFragment {
            return StaffCallHistoryFragment()
        }
    }

    override fun onTabSelect(position: Int) {
        when (position) {
            0 -> viewModel.refresh(arrayListOf("New", "Approve", "Processing"))
            1 -> viewModel.refresh(arrayListOf("Complete", "Missed", "Cancel", "Rejected"))
        }
        currentTab = position
        viewModel.emptyList.value = false
        adapter.resetPage()
    }

    override fun onTabReselect(position: Int) {}

    override fun onResume() {
        super.onResume()
        if (activity is MainStaffActivity) {
            (activity as MainStaffActivity).viewDataBinding?.ivTop?.visibility = View.GONE
        }
        getList()
    }

    private fun getList() {
        if(activity == null || !isAdded || isDetached){
            return
        }
        runOnUiThread {
            Handler().postDelayed({
                when (currentTab) {
                    0 -> viewModel.refresh(arrayListOf("New", "Approve", "Processing"))
                    1 -> viewModel.refresh(arrayListOf("Complete", "Missed", "Cancel", "Rejected")
                    )
                }
            }, 1000)
        }
    }
}
