package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class ReportRequest(
    @SerializedName("order_id")
    var orderId: Int = 0,
    @SerializedName("title")
    var title : String,
    @SerializedName("body")
    var body : String

)