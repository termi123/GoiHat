package vn.app.tcs.ui.call.detail.manager

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_order_manager_detail.*
import org.jetbrains.anko.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_ORDER_DETAIL_FROM_NOTI
import vn.app.tcs.data.model.OrderManagerDetail
import vn.app.tcs.databinding.ActivityOrderManagerDetailBinding
import vn.app.tcs.ui.staffdetail.StaffDetailActivity
import vn.app.tcs.utils.WakeUpUtils

class OrderDetailManagerActivity : BaseKaraActivity<ActivityOrderManagerDetailBinding, OrderDetailManagerViewModel>() {

    override val layoutId: Int
        get() = R.layout.activity_order_manager_detail
    override val viewModel: OrderDetailManagerViewModel by viewModel()
    private lateinit var adapter: OrderAdapter
    private var orderId: Int = 0
    private var fromNoti: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        WakeUpUtils.setUpWakeUp(this)
        super.onCreate(savedInstanceState)
        getIntentData()
        viewModel.orderInfoRequest.observe(this, Observer {
            it?.let {
                viewModel.orderInfo.value = it
                if (it.orderDetails.isNullOrEmpty()) return@Observer
                adapter.setDataList(it.orderDetails)
            }
        })
        viewModel.setSurveyRequest.observe(this, Observer {
            it?.let {
                finish()
                RxBus.publish(RxEvent.CallFinish())
            }
        })
        initBarList()
        addDisposable(RxEvent.EventReloadDetail::class.java) {
            viewModel.getInfoDetail(orderId)
        }
        addDisposable(RxEvent.EventReload::class.java) {
            viewModel.getInfoDetail(orderId)
        }
        addDisposable(RxEvent.EventMultipleDialog::class.java) {
            viewModel.setSurvey(
                orderId,
                if (it.data.toString().isBlank()) 0 else it.data.toString().toInt(),
                if (it.data2.toString().isBlank()) 0 else it.data2.toString().toInt()
            )
        }
    }

    private fun initBarList() {
        adapter = OrderAdapter(ArrayList())
        rvBarList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rvBarList.adapter = adapter
        adapter.setOnClickListener(object : BaseAdapter.OnClickItemListener<OrderManagerDetail.Detail> {
            override fun onClickItem(item: OrderManagerDetail.Detail, position : Int) {
                startActivity<StaffDetailActivity>(
                    EventConstant.KEY_STAFF_DETAIL to item.staffId.toString(),
                    EventConstant.KEY_STAFF_FAVORITE to true
                )
            }

        })
    }

    private fun getIntentData() {
        intent.let {
            it.extras.let { ex ->
                if (ex != null) {
                    orderId = ex.getInt(EventConstant.KEY_ORDER_DETAIL, 0)
                    fromNoti = ex.getBoolean(KEY_ORDER_DETAIL_FROM_NOTI)
                    viewModel.getInfoDetail(orderId)
                }
            }
        }
    }

    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        getIntentData()
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_BACK -> {
                finish()
                RxBus.publish(RxEvent.CallFinish())
            }
            EventConstant.EVENT_FINISH -> {
//                val mess = MessageDialog(
//                    "Nhập thông số sự kiện",
//                    "",
//                    tag = EventConstant.KEY_MULTI_EDIT,
//                    inputType = InputType.TYPE_CLASS_NUMBER
//                )
//                showDialogMultiEditMessage(mess)
                viewModel.setSurvey(
                    orderId,0,0)
            }
        }
    }

    override fun onBackPressed() {
        if (!fromNoti) {
            RxBus.publish(RxEvent.CallFinish())
        }
        super.onBackPressed()
    }
}