package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class UserLogInRequest(
    @SerializedName("username") var username: String,
    @SerializedName("password") var password: String,
    @SerializedName("role") var role: String
)