package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import vn.app.tcs.data.model.ListBank

interface BankManagement {

    @GET("/api/bank-account/list")
    fun getListBank(): Single<ListBank>

    @POST("/api/bank-account/register")
    fun registerBank(@Body bank : ListBank.BankInfo): Single<List<String>>

    @POST("/api/bank-account/update/{bank_account_id}")
    fun updateBank(@Path("bank_account_id") id: Int, @Body bank: ListBank.BankInfo): Single<List<String>>

    @GET("/api/bank-account/detail/{bank_account_id}")
    fun getBankDetail(@Path("bank_account_id") id: Int): Single<ListBank.Bank>

    @POST("/api/bank-account/delete/{bank_account_id}")
    fun deleteBank(@Path("bank_account_id") id: Int): Single<List<String>>
}