package vn.app.tcs.data.model


import com.google.gson.annotations.SerializedName

data class OrderResponse(
    @SerializedName("success")
    val success: String,
    @SerializedName("order_id")
    val orderId: Int
)