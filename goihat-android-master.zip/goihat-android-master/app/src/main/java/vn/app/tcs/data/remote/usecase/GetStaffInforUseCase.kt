package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.UserManagerRepository

class GetStaffInforUseCase : UseCase<UserProfile>() {
    private val userManagerRepository: UserManagerRepository by inject()
    lateinit var idUser: String
    override fun buildUseCaseObservable(): Single<UserProfile> {
        return userManagerRepository.getUserInfo(idUser)
    }
}