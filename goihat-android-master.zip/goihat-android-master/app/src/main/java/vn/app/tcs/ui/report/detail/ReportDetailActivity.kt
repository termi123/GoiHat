package vn.app.tcs.ui.report.detail

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.data.result.ErrorApi2
import com.base.common.utils.rx.bus.RxEvent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_staff_detail.*
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.databinding.ActivityReportDetailBinding

class ReportDetailActivity : BaseKaraToolbarActivity<ActivityReportDetailBinding, ReportDetailViewModel>() {
    private val gson: Gson by inject()

    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_report_detail
    override val viewModel: ReportDetailViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val type = object : TypeToken<ListRejectOrder.RejectOrder>() {}.type
        viewModel.order.value = gson.fromJson(intent!!.extras!!.getString(EventConstant.KEY_REPORT_REJECT_DETAIL), type)
        viewModel.rejectOrder.observe(this, Observer {
            it?.let {
                finish()
            }
        })
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Call -> {

            }
            AppConstant.DialogState.Back -> {
                when (event.tag) {
                    EventConstant.EVENT_REJECT_ORDER_ACCEPT.toString() -> viewModel.rejectOrder("Y")
                    EventConstant.EVENT_REJECT_ORDER_DENY.toString() -> viewModel.rejectOrder("N")
                }
            }
            else -> {
            }
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_BACK -> finish()
            EventConstant.EVENT_REJECT_ORDER_ACCEPT -> showAcceptDialog()
            EventConstant.EVENT_REJECT_ORDER_DENY -> showDenyDialog()
        }
    }

    private fun showDenyDialog() {
        showDialog2ButtonMessage(
            MessageDialog(
                content = "Bạn có chắc từ chối yêu cầu xử lý bị Out không?",
                confirmButton = "Huỷ",
                cancelButton = "OK",
                tag = EventConstant.EVENT_REJECT_ORDER_DENY.toString()
            )
        )
    }

    private fun showAcceptDialog() {
        showDialog2ButtonMessage(
            MessageDialog(
                content = "Đồng ý yêu cầu xử lý bị Out sẽ hoàn ⭐ cho Ca sĩ. <br />Bạn chắc chắn đồng ý chứ ?",
                confirmButton = "Huỷ",
                cancelButton = "OK",
                tag = EventConstant.EVENT_REJECT_ORDER_ACCEPT.toString()
            )
        )
    }
}