package vn.app.tcs.ui.call.select

import android.annotation.SuppressLint
import android.app.Activity
import android.util.SparseArray
import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseLifecycleAdapter
import com.base.common.utils.ext.inflateExt
import com.google.android.libraries.places.internal.id
import org.jetbrains.anko.toast
import timber.log.Timber
import vn.app.tcs.R
import vn.app.tcs.base.adapter.BaseVMAdapter
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.ItemStaffListBinding

abstract class BaseSelectStaffAdapter(
    var activity: FragmentActivity,
    data: ArrayList<ListStaff.Staff>
) :
    BaseVMAdapter<ListStaff.Staff,ItemCallStaffViewModel>(data) {

    abstract val isFavorite: Boolean

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffCallViewHolder(parent?.inflateExt(R.layout.item_staff_list)!!, activity, this)
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffCallViewHolder) {
            list[position].apply {
                if (!viewModelProvide.contains(id)) {
                    viewModelProvide.put(id,ItemCallStaffViewModel())
                }
                holder.onBind(this,viewModelProvide.get(id))
            }
        }
    }

    fun onSelectItem(staff : ListStaff.Staff){
        if(viewModelProvide.contains(staff.id)){
            viewModelProvide.get(staff.id).onSelectStaff()
        }
    }

    fun reset() {
        list.map { item ->
            item.checked = false
            item.endTimeSelect = 0
        }
        notifyDataSetChanged()
    }

    class StaffCallViewHolder(
        view: View,
        activity: FragmentActivity,
        var adapter: BaseSelectStaffAdapter
    ) :
        BaseLifecycleAdapter<ListStaff.Staff, ItemStaffListBinding,ItemCallStaffViewModel>(view,activity) {

        fun onBind(item: ListStaff.Staff, viewModelItem: ItemCallStaffViewModel) {
            viewModel = viewModelItem
            onBind(item)
        }

        override fun onBind(item: ListStaff.Staff) {
            super.onBind(item)
            viewModel.setUpStaff(item)
            viewModel.isFavorite = adapter.isFavorite
            viewModel.mainViewModel = (activity as SelectStaffActivity).viewModel
            viewModel.unSelectStaffResult.observe(getLifecycleOwner(), Observer { })
            viewModel.selectStaffResult.observe(getLifecycleOwner(), Observer { })
        }

        override fun onReceiveEvent(event: Int, item: ListStaff.Staff) {
            super.onReceiveEvent(event, item)
            if (event == EventConstant.EVENT_CANT_CALL) {
                getLifecycleOwner().toast("Ca sĩ \"${item.name}\" đang được chọn")
            }
            if (event == EventConstant.EVENT_CANT_CALL_OFFLINE) {
                getLifecycleOwner().toast("Ca sĩ \"${item.name}\" đang offline")
            }
        }
    }
}