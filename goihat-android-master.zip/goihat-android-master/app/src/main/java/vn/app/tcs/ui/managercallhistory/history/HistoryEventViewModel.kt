package vn.app.tcs.ui.managercallhistory.history

import com.base.common.base.viewmodel.BaseViewModel

class HistoryEventViewModel : BaseViewModel() {

}