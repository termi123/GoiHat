package vn.app.tcs.base

import androidx.databinding.ViewDataBinding
import com.base.common.base.fragment.BaseMVVMFragment
import com.base.common.base.viewmodel.BaseViewModel
import com.base.common.data.event.MessageDialog
import org.jetbrains.anko.support.v4.startActivity
import org.koin.android.ext.android.inject
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.ui.dialog.CommonDialog
import vn.app.tcs.ui.login.LoginActivity

abstract class BaseKaraFragment<T : ViewDataBinding, V : BaseViewModel> : BaseMVVMFragment<T, V>() {
    private val userManager: UserManager by inject()

    override fun onSessionTimeOut(message: String) {
        if (userManager.isUserLoggedIn()) {
            userManager.setIsUserLogin(false)
            userManager.saveUserToken("")
            startActivity<LoginActivity>()
            requireActivity().finish()
        }
    }

    override fun showDialogMessage(message: MessageDialog) {
        super.showDialogMessage(message)
        CommonDialog.newInstance(message).show(childFragmentManager, message.tag)
    }

}