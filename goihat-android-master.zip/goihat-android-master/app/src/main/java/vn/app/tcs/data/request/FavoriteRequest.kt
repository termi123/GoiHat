package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class FavoriteRequest(
    @SerializedName("staff_id") var staffId: String,
    @SerializedName("type") var type: String
)