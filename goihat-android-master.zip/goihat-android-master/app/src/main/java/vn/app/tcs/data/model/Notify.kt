package vn.app.tcs.data.model


import com.google.gson.annotations.SerializedName
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.CategoryNotification
import vn.app.tcs.utils.TimeUtil

data class Notify(
    @SerializedName("per_page")
    val perPage: Int = 0,
    @SerializedName("total")
    val total: Int = 0,
    @SerializedName("lists")
    val lists: List<NotifyItem>?,
    @SerializedName("last_page")
    val lastPage: Int = 0,
    @SerializedName("current_page")
    val currentPage: Int = 0
)


data class DataItem(
    @SerializedName("notification")
    val notification: Notification?,
    @SerializedName("data")
    val data: Data?
)

data class Data(
    @SerializedName("order_id")
    val orderId: String = "",
    @SerializedName("category")
    val category: String = "",
    @SerializedName("bar_avatar")
    val barAvatar: String = "",
    @SerializedName("badge")
    val badge: String = "",
    @SerializedName("body")
    val body: String = ""
) {
    fun getIconNotify(): Int {
        if (category == CategoryNotification.order.category) {
            return R.drawable.default_bar
        }
        if (category == CategoryNotification.money.category) return R.drawable.money
        if (category == CategoryNotification.warning.category) return R.drawable.warning
        return R.drawable.ic_user
    }

    fun isWarning() = category == CategoryNotification.warning.category
}


data class NotifyItem(
    @SerializedName("data")
    val dataItem: DataItem,
    @SerializedName("read_at")
    var readAt: String = "",
    @SerializedName("created_at")
    val createdAt: Long = 0,
    @SerializedName("id")
    val id: String = "",
    @SerializedName("notifiable_id")
    val notifiableId: Int = 0
) {
    fun getTime() = TimeUtil.milliSecondToDate(createdAt, TimeUtil.DATE_FOMART_NOTI)
}


data class Notification(
    @SerializedName("badge")
    val badge: Int = 0,
    @SerializedName("sound")
    val sound: String = "",
    @SerializedName("title")
    val title: String = "",
    @SerializedName("body")
    val body: String = ""
)


