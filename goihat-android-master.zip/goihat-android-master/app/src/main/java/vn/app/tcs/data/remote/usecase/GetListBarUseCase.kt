package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.remote.BarManagementRepository

class GetListBarUseCase : UseCase<ListBar>() {
    var id: String = ""
    private val barManagementRepository: BarManagementRepository by inject()
    override fun buildUseCaseObservable(): Single<ListBar> {
        return barManagementRepository.getListBar(id)
    }
}