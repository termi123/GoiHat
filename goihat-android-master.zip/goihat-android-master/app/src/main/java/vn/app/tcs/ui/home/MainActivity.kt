package vn.app.tcs.ui.home

import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.KeyEvent
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.GravityCompat
import androidx.databinding.DataBindingUtil
import androidx.databinding.Observable
import androidx.databinding.ViewDataBinding
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.base.common.BR
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import com.google.android.material.navigation.NavigationView
import com.zing.zalo.zalosdk.auth.internal.i
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.image
import org.jetbrains.anko.startActivity
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import timber.log.Timber
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.data.firebase.User
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_GUIDE
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.databinding.ActivityMainBinding
import vn.app.tcs.ui.changepass.ChangePassFragment
import vn.app.tcs.ui.home.dialog.CallSupportDialog
import vn.app.tcs.ui.income.IncomeFragment
import vn.app.tcs.ui.intro.IntroActivity
import vn.app.tcs.ui.login.LoginActivity
import vn.app.tcs.ui.managercallhistory.ManagerCallHistoryFragment
import vn.app.tcs.ui.managerhome.FragmentManagerHome
import vn.app.tcs.ui.profile.ProfileActivity
import vn.app.tcs.ui.sendstar.SendStarFragment
import vn.app.tcs.ui.staffhome.StaffHomeFragment
import vn.app.tcs.utils.databinding.notifyObserver


abstract class MainActivity : BaseKaraActivity<ActivityMainBinding, MainViewModel>(),
    NavigationListener {

    override val layoutId: Int
        get() = R.layout.activity_main
    override val viewModel: MainViewModel by viewModel()

    private lateinit var mNavigationView: NavigationView
    private lateinit var mDrawerToggle: ActionBarDrawerToggle

    abstract fun getDefaultFragment(): Fragment

    abstract fun openDefaultFragment()

    abstract fun getDefaultFragmentTag(): String

    abstract fun getNavigationMenu(): Int

    var list: ArrayList<User?> = ArrayList()

    val userManager: UserManager by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setUp()
        showManagementFragment(getDefaultFragment(), "DEFAULT")
        viewModel.loutOut.observe(this, Observer {
            it?.let {
                startActivity<LoginActivity>()
                finish()
            }
        })
        showIntro()
    }

    fun showIntro() {
        if(intent.extras == null) return
        if(intent?.extras?.containsKey(EventConstant.KEY_FROM_LOGIN)!!){
            startActivity<IntroActivity>()
        }
    }

    fun showHistory(needShow : Boolean, icon : Int = R.drawable.request_history, onClick : () -> Unit = {}){
        ivHistory.apply {
            image = AppCompatResources.getDrawable(context, icon)
            visibility = if(needShow) View.VISIBLE else View.GONE
            setOnClickListener {
                onClick.invoke()
            }
        }
    }

    fun showSave(needShow : Boolean, label : String = "Lưu", onClick : () -> Unit = {}){
        ivRight.apply {
            text = label
            visibility = if(needShow) View.VISIBLE else View.GONE
            setOnClickListener {
                onClick.invoke()
            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Call -> {
                if (event.tag == "Call_Support") {
                    CallSupportDialog.getInstance().show(supportFragmentManager, "")
                }
            }
            AppConstant.DialogState.Back -> {
                event.tag?.let { tag ->
                    if (tag == "LOG_OUT") {
                        viewModel.logOut()
                    }
                }
            }
            else -> {
            }
        }
    }

    private fun setUp() {
        viewDataBinding!!.navigationView.menu.clear()
        navigationView.inflateMenu(getNavigationMenu())
        mNavigationView = viewDataBinding!!.navigationView
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        mDrawerToggle = object : ActionBarDrawerToggle(
            this,
            drawerView,
            toolbar,
            R.string.open_drawer,
            R.string.close_drawer
        ) {}
        drawerView.addDrawerListener(mDrawerToggle)
        mDrawerToggle.isDrawerIndicatorEnabled = false
        mDrawerToggle.setHomeAsUpIndicator(R.drawable.ic_action_home)
        mDrawerToggle.setToolbarNavigationClickListener {
            if (drawerView.isDrawerVisible(GravityCompat.START)) {
                drawerView.closeDrawer(GravityCompat.START)
            } else {
                drawerView.openDrawer(GravityCompat.START)
            }
        }
        mDrawerToggle.syncState()
        setupNavMenu()
    }

    fun updateStatusMenu(isOnline: Boolean) {
        if (userManager.getUserInfo()?.role == AppConstant.Role.Staff.name) {
            mDrawerToggle.setHomeAsUpIndicator(if (isOnline) R.drawable.ic_green_icon else R.drawable.ic_red_menu)
        }
    }

    lateinit var navHeaderMainBinding: ViewDataBinding

    private fun setupNavMenu() {
        navHeaderMainBinding = DataBindingUtil.inflate(
            layoutInflater,
            R.layout.nav_header_main, viewDataBinding!!.navigationView, false
        )
        viewDataBinding!!.navigationView.addHeaderView(navHeaderMainBinding.root)
        navHeaderMainBinding.executePendingBindings()
        navHeaderMainBinding.lifecycleOwner = this
        navHeaderMainBinding.setVariable(BR.viewModel, viewModel)
        navHeaderMainBinding.root.setOnClickListener {
            openDefaultFragment()
        }
        mNavigationView.menu.findItem(R.id.fraudAlert)?.icon?.setColorFilter(
            Color.parseColor("#FF0000"),
            PorterDuff.Mode.SRC_ATOP
        )
        mNavigationView.menu.findItem(R.id.navReportList)?.icon?.setColorFilter(
            Color.parseColor("#FF0000"),
            PorterDuff.Mode.SRC_ATOP
        )
        setBoldTextMenuItem(mNavigationView.menu.findItem(R.id.callHistory))

        mNavigationView.setNavigationItemSelectedListener { item ->
            drawerView.closeDrawer(GravityCompat.START)
            when (item.itemId) {
                R.id.navChangePass -> {
                    toolbarTitle.text = "Đổi mật khẩu"
                    showManagementFragment(ChangePassFragment.newInstance(), ChangePassFragment.TAG)
                    return@setNavigationItemSelectedListener true
                }
                R.id.navSupport -> {
                    callSupport()
                    return@setNavigationItemSelectedListener true
                }
                R.id.sendStar -> {
                    showManagementFragment(SendStarFragment.newInstance(),SendStarFragment.TAG)
                    return@setNavigationItemSelectedListener true
                }
                R.id.navLogout -> {
                    logOut()
                    return@setNavigationItemSelectedListener true
                }
                R.id.guide -> {
                    showGuide()
                    return@setNavigationItemSelectedListener true
                }
                else -> {
                    setNavigationOnClick(item.itemId)
                    return@setNavigationItemSelectedListener true
                }
            }
        }
    }

    private fun setBoldTextMenuItem(findItem: MenuItem?) {
        findItem?.let {
            val spannableString = SpannableString(it.title)
            spannableString.setSpan(ForegroundColorSpan(Color.BLACK), 0, spannableString.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            spannableString.setSpan(RelativeSizeSpan(1.5f), 0, spannableString.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
//            spannableString.setSpan(StyleSpan(Typeface.BOLD), 0, spannableString.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            it.setTitle(spannableString)
        }
    }

    private fun showGuide() {
        startActivity<IntroActivity>(KEY_GUIDE to true)
    }

    fun callSupport() {
        Handler().postDelayed({
            showDialog2ButtonMessage(
                MessageDialog(
                    "Thông tin liên hệ",
                    "Xin vui lòng liên hệ tới tổng đài sau.<br><br>CSKH 1 : <a href=\"tel:0337411655\"><font color=#F6358A>0337411655</font></a><br><br>CSKH 2 : <a href=\"tel:0326544338\"><font color=#F6358A>0326544338</font></a><br><br>CSKH 3 : <a href=\"tel:0335699277\"><font color=#F6358A>0335699277</font></a>",
                    "",
                    "OK"
                ).apply {
                    tag = "Call_Support"
                }
            )
        }, 200)
    }

    fun logOut() {
        Handler().postDelayed({
            showDialog2ButtonMessage(
                MessageDialog(
                    "Đăng xuất", "Bạn có chắc muốn đăng xuất khỏi tài khoản hiện tại?",
                    "Huỷ", "OK"
                ).apply {
                    tag = "LOG_OUT"
                }
            )
        }, 200)
    }

    protected fun showManagementFragment(fragment: Fragment, tag: String) {
        lockDrawer()
        val currentFragment = supportFragmentManager.findFragmentByTag(tag)
        if (currentFragment != null && currentFragment.isVisible) return
        supportFragmentManager
            .beginTransaction()
            .disallowAddToBackStack()
            .setCustomAnimations(R.anim.slide_left, R.anim.slide_right)
            .replace(R.id.frameLayout, fragment, tag)
            .commitAllowingStateLoss()
        ivTop.visibility =
            if (arrayListOf( IncomeFragment.TAG, FragmentManagerHome.TAG, StaffHomeFragment.TAG)
                    .contains(tag)
            ) View.VISIBLE else View.GONE
    }

    private fun lockDrawer() {
        drawerView.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    private fun onFragmentDetached(tag: String) {
        val fragmentManager = supportFragmentManager
        val fragment = fragmentManager.findFragmentByTag(tag)
        if (fragment != null) {
            fragmentManager
                .beginTransaction()
                .disallowAddToBackStack()
                .setCustomAnimations(R.anim.slide_left, R.anim.slide_right)
                .remove(fragment)
                .commitNow()
            unlockDrawer()
        }
    }

    private fun unlockDrawer() {
        drawerView.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }

    override fun onResume() {
        super.onResume()
        viewModel.getProfile()
        viewModel.profile.notifyObserver()
        drawerView.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
    }

    override fun onBackPressed() {
        val fragmentManager = supportFragmentManager
        val fragment = fragmentManager.findFragmentByTag(getDefaultFragmentTag())
        if (fragment == null) {
            super.onBackPressed()
        } else {
            onFragmentDetached(getDefaultFragmentTag())
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        super.onKeyUp(keyCode, event)
        return true
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_PROFILE) {
            startActivity<ProfileActivity>()
        }
        if (propertyId == EventConstant.EVENT_OUT) {
            startActivity<LoginActivity>()
            finish()
        }
    }

//    override fun onDestroy() {
//        viewModel.updateProfile(AppConstant.Activity.Offline.name)
//        super.onDestroy()
//    }
}
