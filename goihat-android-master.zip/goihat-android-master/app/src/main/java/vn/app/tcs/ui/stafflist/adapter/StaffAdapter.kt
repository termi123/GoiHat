package vn.app.tcs.ui.stafflist.adapter

import android.view.View
import android.view.ViewGroup
import androidx.core.util.contains
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseLifecycleAdapter
import com.base.common.utils.ext.inflateExt
import vn.app.tcs.R
import vn.app.tcs.base.adapter.BaseVMAdapter
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.databinding.ItemListStaffBinding

class StaffAdapter(var activity: FragmentActivity, data: ArrayList<ListStaff.Staff>) :
    BaseVMAdapter<ListStaff.Staff, StaffAdapterViewModel>(data) {

    override fun onCreateViewHolderBase(
        parent: ViewGroup?,
        viewType: Int
    ): RecyclerView.ViewHolder {
        return StaffViewHolder(parent?.inflateExt(R.layout.item_list_staff)!!, activity)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is StaffViewHolder) {
            list[position].run {
                if (id == null) return
                if (!viewModelProvide.contains(id)) {
                    viewModelProvide.put(id, StaffAdapterViewModel())
                }
                holder.onBindViewModel(list[position], viewModelProvide.get(id))
            }
        }

    }

    class StaffViewHolder(view: View, activity: FragmentActivity) :
        BaseLifecycleAdapter<ListStaff.Staff, ItemListStaffBinding,StaffAdapterViewModel>(view, activity) {

        override fun onBind(item: ListStaff.Staff) {
            super.onBind(item)
            viewModel.setUpStaff(item)
        }

        fun onBindViewModel(item: ListStaff.Staff, viewModel: StaffAdapterViewModel) {
            this.viewModel = viewModel
            onBind(item)
        }

    }
}
