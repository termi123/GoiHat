package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListRejectOrder
import vn.app.tcs.data.remote.ReportRepository

class GetRejectUseCase : UseCase<ListRejectOrder>(){

    var pageList: Int = 1
    private val authenticateRepository: ReportRepository by inject()

    override fun buildUseCaseObservable(): Single<ListRejectOrder> {
        return authenticateRepository.getListRejectOrder(pageList)
    }
}