package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.Notify

interface NotificationRepository {

    fun getNotification(category: String?, page: Int): Single<Notify>

    fun setRead(orderId: String): Single<List<String>>

    fun setRead(): Single<List<String>>
}

class NotificationRepositoryImpl(private val notificationSource: NotificationSource) :
    NotificationRepository {

    override fun setRead(orderId: String): Single<List<String>> {
        return notificationSource.setRead(orderId)
    }

    override fun setRead(): Single<List<String>> {
        return notificationSource.setRead()
    }

    override fun getNotification(category: String?, page: Int): Single<Notify> {
        return notificationSource.getNotification(category, page)
    }
}