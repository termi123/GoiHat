package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.BarManagementRepository

class DeleteBarUseCase : UseCase<ArrayList<String>>() {
    var id: String = ""
    private val barManagementRepository: BarManagementRepository by inject()
    override fun buildUseCaseObservable(): Single<ArrayList<String>> {
        return barManagementRepository.deleteBar(id)
    }
}