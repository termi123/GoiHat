package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class UnSelectStaffRequest (
    @SerializedName("staff_id")
    var staffId: List<Int>
)