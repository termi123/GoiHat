package vn.app.tcs.data.model


import com.base.common.constant.AppConstant
import com.base.common.utils.BindingAdapters
import com.google.gson.annotations.SerializedName
import vn.app.tcs.KaraApplication
import vn.app.tcs.R
import java.io.Serializable

data class ListStaff(
    @SerializedName("lists")
    val staff: ArrayList<Staff>,
    @SerializedName("current_page")
    val currentPage: Int,
    @SerializedName("last_page")
    val lastPage: Int,
    @SerializedName("total")
    val total: Int,
    @SerializedName("per_page")
    val perPage: Int,
    @SerializedName("total_online")
    val total_online: Int,
    @SerializedName("total_offline")
    val total_offline: Int,
    @SerializedName("total_ondesk")
    val total_ondesk: Int,
    @SerializedName("total_moving")
    val total_moving: Int
) : Serializable {
    data class Staff(
        @SerializedName("id")
        val id: Int,
        @SerializedName("code")
        val code: String,
        @SerializedName("role")
        val role: String,
        @SerializedName("staffs_of_owner")
        val staffsOfOwner: String,
        @SerializedName("referral_code")
        val referralCode: String,
        @SerializedName("name")
        val name: String,
        @SerializedName("phone")
        val phone: String,
        @SerializedName("activity")
        var activity: String,
        @SerializedName("avatar")
        val avatar: String,
        @SerializedName("birthday")
        val birthday: String,
        @SerializedName("gender")
        val gender: String,
        @SerializedName("money")
        val money: Int,
        @SerializedName("created_at")
        val createdAt: Int,
        @SerializedName("fee_order")
        val feeOrder: Int,
        @SerializedName("address")
        val address: String,
        var endTimeSelect: Long = 0,
        var checked: Boolean = false,
        @SerializedName("is_favorite")
        var isFavorite: String,
        @SerializedName("distance_in_km")
        var distance: String,
        @SerializedName("gallery")
        val galleries: ArrayList<ImageStaffResponse> = arrayListOf()
    ) : Serializable {

        var isShowFee = false

        fun getAvatarGallery() = galleries.apply {
            this.add(0,ImageStaffResponse(0,"999",avatar,avatar))
        }

        fun isFavorite(): Boolean {
            return isFavorite.equals("Yes", true)
        }

        fun getStatus() = "Trạng thái : " + when (activity) {
            "Online" -> "Online"
            "Offline" -> "Offline"
            "Selecting" -> "Đang được chọn"
            "Ondesk" -> "Đang hát"
            else -> activity
        }

        fun getFeeOrderString(): String? =
//            if (isShowFee) BindingAdapters.bindMoneyFormat(
//                feeOrder.toString(), KaraApplication.instance?.getString(
//                    R.string.manager_fee_staff
//                )
//            ) else
            if (money <= 0) {
                KaraApplication.instance?.getString(R.string.main_balance).plus(" --️")
            } else {
                KaraApplication.instance?.getString(R.string.main_balance).plus(" $money ⭐️")
            }

        fun getInvertFavorite(): String {
            return if (isFavorite()) "No" else "Yes"
        }

        fun getStaffInfo() = "$code - $name"

        fun getDistanceText() = "$distance km"

        fun setInvertFavorite() {
            isFavorite = getInvertFavorite()
        }

        fun getState(): Int {
            if (checked) {
                return 1
            }
            if (activity == AppConstant.Activity.Online.name) {
                return 0
            }
            return 2
        }
    }
}