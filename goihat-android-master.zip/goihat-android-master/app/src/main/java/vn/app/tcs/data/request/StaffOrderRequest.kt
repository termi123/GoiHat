package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

class StaffOrderRequest(
    @SerializedName("description")
    var description : String
)