package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.AuthenticateRepository
import vn.app.tcs.data.request.ChangePassRequest

class ChangePasswordUseCase() : UseCase<ArrayList<String>>() {
    lateinit var changePassRequest: ChangePassRequest
    private val authenticateRepository: AuthenticateRepository by inject()

    override fun buildUseCaseObservable(): Single<ArrayList<String>> {
        return authenticateRepository.changePassword(changePassRequest)
    }
}