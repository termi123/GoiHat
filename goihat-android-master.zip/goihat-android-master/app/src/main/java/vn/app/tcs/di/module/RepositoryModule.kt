package vn.app.tcs.di.module

import org.koin.dsl.module
import retrofit2.Retrofit
import vn.app.tcs.data.remote.*

val repositoryModule = module {
    factory { AuthenticateRepositoryImpl(get()) as AuthenticateRepository }

    single { createWebService<AuthenticateSource>(get()) }

    factory { NotificationRepositoryImpl(get()) as NotificationRepository }

    single { createWebService<NotificationSource>(get()) }

    factory { UserManagerRepositoryImpl(get()) as UserManagerRepository }

    single { createWebService<UserManagementSource>(get()) }

    factory { BankRepositoryImpl(get()) as BankRepository }

    single { createWebService<BankManagement>(get()) }

    factory { OrderRepositoryImpl(get()) as OrderRepository }

    single { createWebService<OrderSource>(get()) }

    factory { BarManagementRepositoryImpl(get()) as BarManagementRepository }

    single { createWebService<ReportSource>(get()) }

    factory { ReportRepositoryImpl(get()) as ReportRepository }

    single { createWebService<BarManagementSource>(get()) }

    factory { RoomManagementRepositoryImpl(get()) as RoomManagementRepository }

    single { createWebService<RoomManagementSource>(get()) }

    single { createWebService<CallConfigSource>(get()) }

    factory { CallConfigRepositoryImpl(get()) as CallConfigRepository }
}


inline fun <reified T> createWebService(retrofit: Retrofit): T {
    return retrofit.create(T::class.java)
}