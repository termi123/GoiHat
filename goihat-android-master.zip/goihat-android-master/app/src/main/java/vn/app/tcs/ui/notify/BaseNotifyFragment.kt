package vn.app.tcs.ui.notify

import android.os.Bundle
import android.text.TextUtils
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.databinding.Observable
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.notify_fragment.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.android.ext.android.inject
import timber.log.Timber
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraActivity
import vn.app.tcs.base.BaseKaraListFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_ORDER_DETAIL_FROM_NOTI
import vn.app.tcs.data.model.NotifyItem
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.databinding.NotifyFragmentBinding
import vn.app.tcs.ui.call.detail.manager.OrderDetailManagerActivity
import vn.app.tcs.ui.call.detail.staff.OrderDetailStaffActivity
import vn.app.tcs.ui.notify.adapter.NotifyAdapter
import vn.app.tcs.utils.TimeUtil

abstract class BaseNotifyFragment<V : BaseNotifyViewModel> : BaseKaraListFragment<NotifyFragmentBinding, V, NotifyItem>() {
    override val recyclerView: RecyclerView  by lazy { rvNotify }
    val userManager: UserManager by inject()
    override val layoutId = R.layout.notify_fragment
    private var tempId = 0
    private lateinit var item: NotifyItem
    override val adapter: NotifyAdapter = NotifyAdapter(ArrayList())

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        addDisposable(RxEvent.EventReloadDetail::class.java) {
            viewModel.reset()
        }
        addDisposable(RxEvent.EventReload::class.java) {
            viewModel.reset()
        }
    }

    override fun observerData() {
        super.observerData()
        viewModel.listNotify.observe(viewLifecycleOwner, Observer { dataNotify ->
            dataNotify?.let { data ->
                adapter.totalPage = data.lastPage
                handlerLoadData(data.lists)
            }
        })
//        viewModel.markNotificationRequest.observe(viewLifecycleOwner, Observer {
//            it?.let {
//                run {
//                    handleNoti()
//                }
//            }
//        })
        viewModel.markAllNotificationRequest.observe(viewLifecycleOwner, Observer {
            viewModel.reset()
        })

    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        super.onReceiverMessage(sender, propertyId)
        when (propertyId) {
            EventConstant.EVENT_MARK_NOTIFICATION -> {
                handleNoti()
            }
        }
    }

    private fun handleNoti() {
        val pos = adapter.list.indexOf(item)
        if (pos >= 0) {
            adapter.list[pos].readAt =
                TimeUtil.milliSecondToDate(System.currentTimeMillis(), TimeUtil.DATE_FOMART_NOTI)!!
            adapter.notifyItemChanged(pos)
        }

        if (userManager.getUserInfo() == null
            || (::item.isInitialized && (item.dataItem.data?.category == "money"
                    || item.dataItem.data?.category == "warning")
                    || item.dataItem.data?.category == "alert")) return
        if (userManager.getUserInfo()?.role == AppConstant.Role.Manager.name) {
            startActivity<OrderDetailManagerActivity>(EventConstant.KEY_ORDER_DETAIL to tempId, KEY_ORDER_DETAIL_FROM_NOTI to true)
        }
        if (userManager.getUserInfo()?.role == AppConstant.Role.Staff.name && ::item.isInitialized) {
            startActivity<OrderDetailStaffActivity>(EventConstant.KEY_ORDER_DETAIL to tempId)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.reset()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.drawer_mark, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        R.id.markAsRead -> {
            viewModel.setAllMark()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }


    override fun onClickRecycleViewItem(item: NotifyItem) {
        super.onClickRecycleViewItem(item)
        this.item = item
        Timber.e("click -> ${item.dataItem.data?.category}")
        when (item.dataItem.data?.category) {
            "order", "survey" -> {
                if (item.dataItem.data.orderId.isBlank()) {
                    viewModel.setMark(item.id)
                    return
                }
                tempId = item.dataItem.data.orderId.toInt()
                if (TextUtils.isEmpty(item.readAt)) {
                    viewModel.setMark(item.id)
                } else {
                    handleNoti()
                }
            }
            "money", "warning", "alert" -> {
                if (TextUtils.isEmpty(item.readAt)) {
                    viewModel.setMark(item.id)
                }
                if (activity is BaseKaraActivity<*, *>) {
                    (activity as BaseKaraActivity<*, *>).apply {
                        if (item.dataItem.notification != null && !TextUtils.isEmpty(item.dataItem.notification.body)) {
                            showDialogMessage(
                                MessageDialog(
                                    "Thông báo",
                                    item.dataItem.notification.body
                                )
                            )
                            return@apply
                        }
                        if (!TextUtils.isEmpty(item.dataItem.data.body)) {
                            showDialogMessage(MessageDialog("Thông báo", item.dataItem.data.body))
                        }
                    }
                }
            }
        }
    }

    companion object {
        val TAG = NotifyFragment::class.java.simpleName
        fun newInstance(): NotifyFragment {
            return NotifyFragment()
        }
    }
}
