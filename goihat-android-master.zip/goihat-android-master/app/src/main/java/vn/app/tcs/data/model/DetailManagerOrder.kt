package vn.app.tcs.data.model


import com.base.common.constant.AppConstant
import com.google.gson.annotations.SerializedName

data class OrderManagerDetail(
    @SerializedName("order_id")
    val orderId: Int,
    @SerializedName("bar_id")
    val barId: Int,
    @SerializedName("bar")
    val bar: Bar,
    @SerializedName("room")
    val room: Bar.Room,
    @SerializedName("manager_id")
    val managerId: Int,
    @SerializedName("manager")
    val manager: Manager,
    @SerializedName("number_staffs_required")
    val numberStaffsRequired: Int,
    @SerializedName("order_details")
    val orderDetails: ArrayList<Detail>,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("is_survey")
    val is_survey: String
) {

    fun needShowSurvey(): Boolean {
        return is_survey != null && is_survey.toLowerCase() == "no"
    }

    fun getAcceptedCount(): String {
        if (orderDetails.isNullOrEmpty()) return "0/$numberStaffsRequired"
        val accept =
            orderDetails.filter {
                it.status == AppConstant.Status.Approve.name || it.status == AppConstant.Status.Rejected.name
                        || it.status == AppConstant.Status.Processing.name
                        || it.status == AppConstant.Status.Complete.name
            }
                .size
        return "$accept/$numberStaffsRequired"
    }

    data class Detail(
        @SerializedName("id")
        val id: Int,
        @SerializedName("staff_id")
        val staffId: Int,
        @SerializedName("staff")
        val staff: ListStaff.Staff,
        @SerializedName("order_id")
        val orderId: Int,
        @SerializedName("status")
        val status: String,
        @SerializedName("approved_at")
        val approvedAt: String,
        @SerializedName("canceled_at")
        val canceledAt: String,
        @SerializedName("rejected_at")
        val rejectedAt: String,
        @SerializedName("processing_at")
        val processingAt: String,
        @SerializedName("complete_at")
        val completeAt: String,
        @SerializedName("created_at")
        val createdAt: Int
    ) {
        fun getStaffStatus(): String = AppConstant.Status.from(status)!!.status
    }
}