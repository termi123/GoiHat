package vn.app.tcs.ui.managercallhistory

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.data.karaconstant.DEFAULT_PAGE
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.remote.usecase.GetListBarUseCase
import vn.app.tcs.data.remote.usecase.GetManagerCallHistoryUseCase
import vn.app.tcs.data.usermanager.UserManager

class ManagerCallHistoryViewModel : BaseListViewModel() {
    val userManager: UserManager by inject()
    private val getManagerCallHistoryUseCase : GetManagerCallHistoryUseCase by inject()
    private val getListBarUseCase: GetListBarUseCase by inject()
    var isSurvey = false
    var showCall = MutableLiveData<Boolean>()
    var bars: LiveData<ListBar?> = Transformations.map(getListBarUseCase.result) {
        handleCommonApi(it)
    }

    val listOrderStaff: LiveData<OrderManager> = Transformations.map(getManagerCallHistoryUseCase.result) {
        handleStateCommonApi(it)
    }

    override fun loadData() {
        super.loadData()
        getManagerCallHistory(isSurvey)
    }

    private fun getManagerCallHistory(survey : Boolean) {
        getManagerCallHistoryUseCase.apply {
            pageNum = page
            isSurvey = survey
        }.executeZip({
            isEmpty.postValue(it.lists?.isEmpty()!! && page == DEFAULT_PAGE)
            page++
        },{})
    }

    fun callStaff() = sendEvent(EventConstant.EVENT_CALL_STAFF)

    fun getListBar() {
        getListBarUseCase.apply { id = userManager.getUserInfo()?.id.toString() }.execute()
    }

    override fun reset() {
        super.reset()
        getListBar()
    }

    override fun refresh() {
        super.refresh()
        getListBar()
    }
}
