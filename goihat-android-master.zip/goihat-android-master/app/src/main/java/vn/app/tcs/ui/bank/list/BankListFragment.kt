package vn.app.tcs.ui.bank.list

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.constant.AppConstant
import kotlinx.android.synthetic.main.list_bank_fragment.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BANK
import vn.app.tcs.data.model.ListBank
import vn.app.tcs.databinding.ListBankFragmentBinding
import vn.app.tcs.ui.bank.add.AddBankActivity

class BankListFragment : BaseKaraFragment<ListBankFragmentBinding, BankListViewModel>(),
    com.base.common.base.adapter.BaseAdapter.OnClickItemListener<ListBank.Bank> {
    override val viewModel: BankListViewModel  by viewModel()
    override val layoutId: Int
        get() = R.layout.list_bank_fragment

    var data = ArrayList<ListBank.Bank>()
    val adapter : BankAdapter by lazy {
        BankAdapter(
            ArrayList()
        )
    }
    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_ADD_BANK) {
            startActivity<AddBankActivity>(EventConstant.KEY_BAR_TYPE to AppConstant.BarActionType.Add)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rvBank.layoutManager = LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        rvBank.adapter = adapter
        adapter.setOnClickListener(this)
        viewModel.banks.observe(viewLifecycleOwner, Observer { bankList ->
            run {
                bankList?.let {
                    adapter.setDataList(it.lists as ArrayList<ListBank.Bank>)
                    viewDataBinding?.hasBank = it.lists.isNotEmpty()
                }
            }
        })
        viewModel.profileRequestData.observe(viewLifecycleOwner, androidx.lifecycle.Observer {  })
        swRefresh.setOnRefreshListener {
            swRefresh.isRefreshing = false
            viewModel.getListBank()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getListBank()
        viewModel.getProfileFromApi()
    }

    override fun onClickItem(item: ListBank.Bank, position : Int) =
        startActivity<AddBankActivity>(EventConstant.KEY_BAR_TYPE to AppConstant.BarActionType.Edit, KEY_BANK to item)


    companion object {
        val TAG = BankListFragment::class.java.getName()
        fun newInstance(): BankListFragment {
            val fragment = BankListFragment()
            return fragment
        }
    }

}