package vn.app.tcs.data.model


import android.os.Parcelable
import com.base.common.constant.AppConstant
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize
import java.io.Serializable
@Parcelize
data class UserProfile(
    @SerializedName("profile")
    var profile: Profile,
    @SerializedName("access_token")
    var accessToken: String
) : Parcelable {

    @Parcelize
    open class BasicProfile : Parcelable {
        @SerializedName("name")
        var name: String = ""
        @SerializedName("phone")
        var phone: String = ""
        @SerializedName("birthday")
        var birthday: String = ""
        @SerializedName("gender")
        var gender: String = ""
        @SerializedName("address")
        var address: String = ""
        @SerializedName("role")
        var role: String = ""

        fun getRoleName(): String {
            val role = AppConstant.Role.from(role)
            return role?.roleName ?: ""
        }
    }

    @Parcelize
    class Profile : BasicProfile(), Parcelable {
        @SerializedName("id")
        var id: Int = 0
        @SerializedName("code")
        val code: String = ""
        @SerializedName("referral_code")
        val referralCode: String = ""
        @SerializedName("owner_code")
        val ownerCode: String = ""
        @SerializedName("fee_order")
        val feeOrder: Int = 50
        @SerializedName("avatar")
        val avatar: String = ""
        @SerializedName("money")
        val money: String = ""
        @SerializedName("second_money")
        val second_money: String = ""
        @SerializedName("created_at")
        val createdAt: Int = 0
        @SerializedName("staffs_of_owner")
        val staffsOfOwner: Int = 0
        @SerializedName("revenue_yesterday")
        val revenueYesterday: String = ""
        @SerializedName("revenue_today")
        val revenueToday: String = ""
        @SerializedName("revenue_7_days")
        val revenue7days: String = ""
        @SerializedName("activity")
        var activity: String = ""
        @SerializedName("is_favorite")
        var isFavorite: String = ""
        @SerializedName("has_registered_bar")
        var hasRegisteredBar: String = ""
        @SerializedName("bar")
        val bar: Bar = Bar()
        @SerializedName("room")
        val room: Bar.Room = Bar.Room()
        @SerializedName("gallery")
        val galleries: ArrayList<ImageStaffResponse> = arrayListOf()

        fun isFavorite(): Boolean {
            return isFavorite.equals("Yes", true)
        }

        fun getFeeOrderString() = feeOrder.toString()

        fun getInvertFavorite(): String {
            return if (isFavorite()) "No" else "Yes"
        }

        fun isShowStaffImage(): Boolean {
            return role == AppConstant.Role.Staff.name
        }

        fun isRegisterBar(): Boolean {
            return hasRegisteredBar.equals("on", true)
        }

        fun getAvatarGallery() = galleries.apply {
            this.add(0,ImageStaffResponse(0,"999",avatar,avatar))
        }

    }

}