package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.CheckVersionResponse
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.request.ChangePassRequest
import vn.app.tcs.data.request.CheckVersionRequest
import vn.app.tcs.data.request.TokenRequest
import vn.app.tcs.data.request.UserLogInRequest

interface AuthenticateRepository {
    fun login(userLogInRequest: UserLogInRequest): Single<UserProfile>

    fun logout(): Single<ArrayList<String>>

    fun updateToken(tokenRequest: TokenRequest): Single<ArrayList<String>>

    fun changePassword(changePassRequest: ChangePassRequest): Single<ArrayList<String>>

    fun checkVersion(versionRequest: CheckVersionRequest): Single<CheckVersionResponse>

}

class AuthenticateRepositoryImpl(private val authenticateSource: AuthenticateSource) :
    AuthenticateRepository {
    override fun logout(): Single<ArrayList<String>> {
        return authenticateSource.logOut()
    }

    override fun checkVersion(versionRequest: CheckVersionRequest): Single<CheckVersionResponse> {
        return authenticateSource.checkVersion(versionRequest.version, versionRequest.type)
    }

    override fun changePassword(changePassRequest: ChangePassRequest): Single<ArrayList<String>> {
        return authenticateSource.changePassword(changePassRequest)
    }

    override fun login(userLogInRequest: UserLogInRequest): Single<UserProfile> {
        return authenticateSource.login(userLogInRequest)
    }

    override fun updateToken(tokenRequest: TokenRequest): Single<ArrayList<String>> {
        return authenticateSource.updateToken(tokenRequest)
    }

}