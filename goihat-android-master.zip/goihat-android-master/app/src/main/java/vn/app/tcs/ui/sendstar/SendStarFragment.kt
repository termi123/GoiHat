package vn.app.tcs.ui.sendstar

import android.os.Bundle
import android.view.View
import androidx.core.text.isDigitsOnly
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.send_star_fragment.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.SendStarFragmentBinding

class SendStarFragment : BaseKaraFragment<SendStarFragmentBinding, SendStarViewModel>() {
    override val layoutId: Int = R.layout.send_star_fragment
    override val viewModel: SendStarViewModel by viewModel()
    private val sendStar = "SendStar"

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        super.onReceiverMessage(sender, propertyId)
        if(propertyId == EventConstant.EVENT_SEND_STAR){
            if(etStarAmount.text.isNullOrBlank()){
                showDialogMessage(MessageDialog(content = "Vui lòng nhập số sao cần chuyển"))
                return
            }
            if(etReceiverCode.text.isNullOrBlank()){
                showDialogMessage(MessageDialog(content = "Vui lòng nhập mã số người nhận"))
                return
            }
            if(etPassword.text.isNullOrBlank()){
                showDialogMessage(MessageDialog(content = "Vui lòng nhập mật khẩu xác nhận"))
                return
            }
            if(!etStarAmount.text.toString().isDigitsOnly()){
                showDialogMessage(MessageDialog(content = "Số ️ cần chuyển phải là chữ số. \n Xin vui lòng nhập lại."))
                return
            }
            if(!"^([a-zA-Z])([0-9]{4,7})\$".toRegex().matches(etReceiverCode.text.toString())){
                showDialogMessage(
                    MessageDialog(
                        getString(R.string.app_name),
                        AppConstant.RECEIVER_INVALID
                    )
                )
                return
            }
            viewModel.sendStar(etReceiverCode.text.toString(),etStarAmount.text.toString().toInt(),etPassword.text.toString())
        }
        if(propertyId == EventConstant.EVENT_SEND_STAR_SUCCESS){
            etPassword.setText("")
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        viewModel.getProfile()
    }

    override fun observerData() {
        super.observerData()
        viewModel.sendStarResult.observe(viewLifecycleOwner, Observer {
            it?.let {
                if(it.isNotEmpty()){
                    viewModel.publishRxEvent(RxEvent.GetProfileEvent())
                    showDialogMessage(MessageDialog(content = "Bạn đã chuyển thành công ${viewModel.lastStar}⭐️ tới tài khoản ${viewModel.lastCode}",tag = sendStar))
                }
            }
        })
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if(event.tag == sendStar){
            viewModel.publishRxEvent(RxEvent.GetProfileEvent())
        }
    }

    companion object {
        val TAG = SendStarFragment::class.java.simpleName
        fun newInstance(): SendStarFragment {
            return SendStarFragment()
        }
    }

}
