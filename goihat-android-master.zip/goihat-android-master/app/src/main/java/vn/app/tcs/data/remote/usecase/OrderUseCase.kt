package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.OrderResponse
import vn.app.tcs.data.remote.OrderRepository

class OrderUseCase : UseCase<OrderResponse>() {

    var id: Int = 0
    var numberRequired: Int = 0
    var fee: String = "0"
    var isRandom: Boolean? = null
    var list: List<Int> = emptyList()

    private val order: OrderRepository by inject()

    override fun buildUseCaseObservable(): Single<OrderResponse> =
        order.orderStaffs(id, numberRequired, fee, isRandom, list)
}