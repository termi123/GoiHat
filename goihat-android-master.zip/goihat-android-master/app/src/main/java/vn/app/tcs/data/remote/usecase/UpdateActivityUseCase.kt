package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.UserManagerRepository

class UpdateActivityUseCase : UseCase<List<String>>() {

    lateinit var activity: String

    private val userManagerRepository: UserManagerRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.updateActivity(activity)
    }
}