package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.CallConfigRepository

class ConfigBarUserCase : UseCase<List<String>>() {

    lateinit var hasConfig: String

    private val roomManagerRepository: CallConfigRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return roomManagerRepository.configSetAll(hasConfig)
    }
}