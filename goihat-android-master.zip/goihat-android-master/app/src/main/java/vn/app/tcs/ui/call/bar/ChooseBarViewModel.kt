package vn.app.tcs.ui.call.bar

import com.base.common.base.viewmodel.BaseViewModel

class ChooseBarViewModel : BaseViewModel(){


}