package vn.app.tcs.ui.addbar.fee

import com.base.common.base.viewmodel.BaseViewModel

class FeeViewModel : BaseViewModel() {
}