package vn.app.tcs.ui.call.detail.staff

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.DetailOrderStaff
import vn.app.tcs.data.remote.usecase.GetOrderDetailUseCase
import vn.app.tcs.data.remote.usecase.UpdateOrderStatus
import vn.app.tcs.data.request.OrderStatusRequest
import vn.app.tcs.data.usermanager.UserManager

class OrderDetailStaffViewModel : BaseViewModel() {

    private val getOrderUseCase: GetOrderDetailUseCase by inject()
    private val updateOrderStatus: UpdateOrderStatus by inject()
    val userManager: UserManager by inject()

    var tempStatus = ""

    var orderInfo = MutableLiveData<DetailOrderStaff>()
    var isFromFb = MutableLiveData<Boolean>()
    var isFromSP = MutableLiveData<Boolean>()
    var orderInfoRequest: LiveData<DetailOrderStaff>
    var updaetOrderInfo: LiveData<List<String>>

    init {
        orderInfoRequest = Transformations.map(getOrderUseCase.result) {
            handleCommonApi(it)
        }
        updaetOrderInfo = Transformations.map(updateOrderStatus.result) {
            handleCommonApi(it)
        }
    }

    fun getInfoDetail(id: Int) = getOrderUseCase.apply { this.id = id }.execute()

    fun doBack() = sendEvent(EventConstant.EVENT_BACK)

    /**
     * Action on view
     */
    fun updateOrder(status: String) = updateOrderStatus.apply {
        //        AlarmController.stopSound()
//        sendEvent(EventConstant.EVENT_STOP_ALERT)
        tempStatus = status
        request = OrderStatusRequest(
            orderInfo.value!!.orderId,
            userManager.getUserInfo()!!.id,
            status
        )
    }.execute()
//        .executeZip({
//        RxBus.publish(RxEvent.EventReloadDetail())
//    },{})

    fun accept() {
        sendEvent(EventConstant.EVENT_ACCEPT)
    }

    fun complete() {
        sendEvent(EventConstant.EVENT_COMPLETE)
    }

//    fun report() {
//        sendEvent(EventConstant.EVENT_REPORT)
//    }

    fun getFee(): Int = userManager.getUserInfo()!!.feeOrder
}