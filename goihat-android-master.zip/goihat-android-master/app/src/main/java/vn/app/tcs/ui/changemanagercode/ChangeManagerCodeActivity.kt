package vn.app.tcs.ui.changemanagercode

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_change_manager_code.*
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.databinding.ActivityChangeManagerCodeBinding

class ChangeManagerCodeActivity :
    BaseKaraToolbarActivity<ActivityChangeManagerCodeBinding, ChangeManagerCodeViewModel>() {
    override fun getToolBar(): Toolbar = toolbar
    override val layoutId: Int = R.layout.activity_change_manager_code
    override val viewModel: ChangeManagerCodeViewModel by viewModel()
    private val userManager: UserManager by inject()
    private val changeCodeTag = "changeCodeTag"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.changeCodeResult.observe(this, Observer {
            it?.let {
                if (it.isNotEmpty()) {
                    showDialogMessage(MessageDialog(content = "Chúng tôi đã tiếp nhận yêu cầu thay đổi Mã quản lý của bạn.\n Ban quản trị sẽ liên hệ tới những cá nhân liên quan để xác minh và xử lý yêu cầu.").apply {
                        tag = changeCodeTag
                    })
                }
            }
        })
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
        super.handleEventCloseDialog(event)
        if(event.tag == changeCodeTag){
            viewModel.publishRxEvent(RxEvent.GetProfileEvent())
            finish()
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        super.onReceiverMessage(sender, propertyId)
        when (propertyId) {
            EventConstant.EVENT_VALID_NEW_CODE -> validNewCode()
        }
    }

    private fun validNewCode() {
        if (!etOldCode.text.toString().equals(userManager.getUserInfo()?.ownerCode,true)) {
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.CODE_N_MATCH))
            return
        }
        if(etNewCode.text.isNullOrEmpty()){
            showDialogMessage(MessageDialog(getString(R.string.app_name), AppConstant.NEWCODE_EMPTY))
            return
        }

        if (etNewCode.text.toString() != etReNewCode.text.toString()) {
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    AppConstant.RECODE_N_MATCH
                )
            )
            return
        }
        if(!"^([a-zA-Z])([0-9]{4,7})\$".toRegex().matches(etNewCode.text.toString())){
            showDialogMessage(
                MessageDialog(
                    getString(R.string.app_name),
                    AppConstant.NEWCODE_INVALID
                )
            )
            return
        }
        viewModel.changeManagerCode(
            etNewCode.text.toString()
        )
    }
}
