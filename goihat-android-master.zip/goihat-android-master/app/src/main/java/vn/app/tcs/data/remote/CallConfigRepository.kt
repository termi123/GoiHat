package vn.app.tcs.data.remote

import io.reactivex.Single
import vn.app.tcs.data.model.ListBar

interface CallConfigRepository {
    fun configSetAll(hasRegister: String): Single<List<String>>//off là nhận hết bar, on là giới hạn bar

    fun getListBar(): Single<ListBar>

    fun registerBar(
        bar_ids: List<Int>
    ): Single<List<String>>

    fun deleteBar(
        bar_ids: List<Int>
    ): Single<List<String>>

    fun getListBarByName(barName: String): Single<ListBar>

}

class CallConfigRepositoryImpl(private val callSource: CallConfigSource) : CallConfigRepository {
    override fun getListBarByName(barName: String): Single<ListBar> {
        return callSource.getListBarByName(barName)
    }

    override fun getListBar(): Single<ListBar> {
        return callSource.getListBar()
    }

    override fun configSetAll(hasRegister: String): Single<List<String>> {
        return callSource.configSetAll(hasRegister)
    }

    override fun registerBar(bar_ids: List<Int>): Single<List<String>> {
        return callSource.registerBar(bar_ids)
    }

    override fun deleteBar(bar_ids: List<Int>): Single<List<String>> {
        return callSource.deleteBar(bar_ids)
    }

}