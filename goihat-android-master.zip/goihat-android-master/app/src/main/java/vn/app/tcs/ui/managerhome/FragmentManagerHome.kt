package vn.app.tcs.ui.managerhome

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.constant.AppConstant
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.fragment_manager_home.*
import org.jetbrains.anko.support.v4.startActivity
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraFragment
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_ORIGIN
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_POSITION
import vn.app.tcs.data.karaconstant.EventConstant.KEY_BAR_TYPE
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.FragmentManagerHomeBinding
import vn.app.tcs.ui.addbar.AddBarActivity
import vn.app.tcs.ui.call.CallStaffActivity
import vn.app.tcs.ui.home.manager.MainManagerActivity
import vn.app.tcs.ui.managerhome.adapter.BarAdapter
import vn.app.tcs.utils.TimeUtil

class FragmentManagerHome : BaseKaraFragment<FragmentManagerHomeBinding, FragmentManagerHomeViewModel>(),
    BaseAdapter.OnClickItemListener<Bar> {

    override val layoutId: Int
        get() = R.layout.fragment_manager_home

    override val viewModel: FragmentManagerHomeViewModel by inject()
    private lateinit var adapter: BarAdapter
    @SuppressLint("CheckResult")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.bars.observe(this, Observer { listBar ->
            run {
                listBar?.let {
                    viewDataBinding?.hasBar = !listBar.lists.isNullOrEmpty()
                    adapter.setDataList(it.lists)
                }
            }
        })

        initBarList()

        addDisposable(RxEvent.BarEvent::class.java) {
            when (it.type) {
                AppConstant.BarActionType.Add, AppConstant.BarActionType.Edit -> viewModel.getListBar()
                else -> {}
            }

        }

        addDisposable(RxEvent.GetProfileEvent::class.java) {
            viewModel.getProfile()
        }

        RxBus.listen(RxEvent.UpdateProfileEvent::class.java).subscribe {
            viewModel.updateProfile()
        }
    }

    private fun initBarList() {
        adapter = BarAdapter(ArrayList())
        rvBarList.layoutManager = LinearLayoutManager(requireContext(), RecyclerView.VERTICAL, false)
        rvBarList.adapter = adapter
        adapter.setOnClickListener(this)
        adapter.onActionBarListener = object : BarAdapter.OnActionBarListener {
            override fun onEdit(position: Int) {
                startActivity<AddBarActivity>(
                    KEY_BAR_TYPE to AppConstant.BarActionType.Edit,
                    KEY_BAR_ORIGIN to adapter.list[position]
                )
            }
        }
    }

    override fun onClickItem(item: Bar, position : Int) {
        startActivity<CallStaffActivity>(KEY_BAR_POSITION to adapter.list.indexOf(item), KEY_BAR_ORIGIN to adapter.list)
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        if (propertyId == EventConstant.EVENT_ADD_BAR) {
            startActivity<AddBarActivity>(KEY_BAR_TYPE to AppConstant.BarActionType.Add)
        }
        if (propertyId == EventConstant.EVENT_CALL_STAFF) {
            startActivity<CallStaffActivity>(KEY_BAR_ORIGIN to adapter.list)
        }
        if (propertyId == EventConstant.EVENT_COPY) {
            TimeUtil.setClipboard(viewModel.profile.value?.code)
        }
    }

    override fun onResume() {
        super.onResume()
        if (activity is MainManagerActivity) {
            (activity as MainManagerActivity).viewDataBinding?.ivTop?.visibility = View.VISIBLE
        }
        viewModel.updateProfile()
        viewModel.getListBar()
    }

    override fun onPause() {
        super.onPause()
        if (activity is MainManagerActivity) {
            (activity as MainManagerActivity).viewDataBinding?.ivTop?.visibility = View.GONE
        }
    }

    companion object {
        val TAG = FragmentManagerHome::class.java.simpleName
        fun newInstance(): FragmentManagerHome {
            return FragmentManagerHome()
        }
    }
}