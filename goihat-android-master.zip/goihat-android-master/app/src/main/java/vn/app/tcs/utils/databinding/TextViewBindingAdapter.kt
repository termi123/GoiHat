package vn.app.tcs.utils.databinding

import android.graphics.drawable.Drawable
import android.os.Build
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.text.method.*
import android.util.Log
import android.util.TypedValue
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.databinding.BindingMethod
import androidx.databinding.BindingMethods
import androidx.databinding.adapters.ListenerUtil
import vn.app.tcs.R

@BindingMethods(
    BindingMethod(type = TextView::class, attribute = "android:autoLink", method = "setAutoLinkMask"),
    BindingMethod(type = TextView::class, attribute = "android:drawablePadding", method = "setCompoundDrawablePadding"),
    BindingMethod(type = TextView::class, attribute = "android:editorExtras", method = "setInputExtras"),
    BindingMethod(type = TextView::class, attribute = "android:inputType", method = "setRawInputType"),
    BindingMethod(
        type = TextView::class,
        attribute = "android:scrollHorizontally",
        method = "setHorizontallyScrolling"
    ),
    BindingMethod(type = TextView::class, attribute = "android:textAllCaps", method = "setAllCaps"),
    BindingMethod(type = TextView::class, attribute = "android:textColorHighlight", method = "setHighlightColor"),
    BindingMethod(type = TextView::class, attribute = "android:textColorHint", method = "setHintTextColor"),
    BindingMethod(type = TextView::class, attribute = "android:textColorLink", method = "setLinkTextColor"),
    BindingMethod(type = TextView::class, attribute = "android:onEditorAction", method = "setOnEditorActionListener")
)
object TextViewBindingAdapter {
    private val TAG = "TextViewBindingAdapters"
    val INTEGER = 0x01
    val SIGNED = 0x03
    val DECIMAL = 0x05
    @BindingAdapter("android:autoText")
    fun setAutoText(view: TextView, autoText: Boolean) {
        val listener = view.keyListener
        var capitalize: TextKeyListener.Capitalize = TextKeyListener.Capitalize.NONE
        val inputType = listener?.inputType ?: 0
        if (inputType and InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS != 0) {
            capitalize = TextKeyListener.Capitalize.CHARACTERS
        } else if (inputType and InputType.TYPE_TEXT_FLAG_CAP_WORDS != 0) {
            capitalize = TextKeyListener.Capitalize.WORDS
        } else if (inputType and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES != 0) {
            capitalize = TextKeyListener.Capitalize.SENTENCES
        }
        view.keyListener = TextKeyListener.getInstance(autoText, capitalize)
    }

    @BindingAdapter("android:capitalize")
    fun setCapitalize(view: TextView, capitalize: TextKeyListener.Capitalize) {
        val listener = view.keyListener
        val inputType = listener.inputType
        val autoText = inputType and InputType.TYPE_TEXT_FLAG_AUTO_CORRECT != 0
        view.keyListener = TextKeyListener.getInstance(autoText, capitalize)
    }

    @BindingAdapter("android:bufferType")
    fun setBufferType(view: TextView, bufferType: TextView.BufferType) {
        view.setText(view.text, bufferType)
    }

    @BindingAdapter("android:digits")
    fun setDigits(view: TextView, digits: CharSequence?) {
        if (digits != null) {
            view.keyListener = DigitsKeyListener.getInstance(digits.toString())
        } else if (view.keyListener is DigitsKeyListener) {
            view.keyListener = null
        }
    }

    @BindingAdapter("android:numeric")
    fun setNumeric(view: TextView, numeric: Int) {
        view.keyListener = DigitsKeyListener.getInstance(
            numeric and SIGNED != 0,
            numeric and DECIMAL != 0
        )
    }

    @BindingAdapter("android:phoneNumber")
    fun setPhoneNumber(view: TextView, phoneNumber: Boolean) {
        if (phoneNumber) {
            view.keyListener = DialerKeyListener.getInstance()
        } else if (view.keyListener is DialerKeyListener) {
            view.keyListener = null
        }
    }

    @BindingAdapter("android:drawableBottom")
    fun setDrawableBottom(view: TextView, drawable: Drawable) {
        val drawables = view.compoundDrawables
        view.setCompoundDrawables(drawables[0], drawables[1], drawables[2], drawable)
    }

    @BindingAdapter("android:drawableLeft")
    fun setDrawableLeft(view: TextView, drawable: Drawable) {
        val drawables = view.compoundDrawables
        view.setCompoundDrawables(drawable, drawables[1], drawables[2], drawables[3])
    }

    @BindingAdapter("android:drawableRight")
    fun setDrawableRight(view: TextView, drawable: Drawable) {
        val drawables = view.compoundDrawables
        view.setCompoundDrawables(drawables[0], drawables[1], drawable, drawables[3])
    }

    @BindingAdapter("android:drawableTop")
    fun setDrawableTop(view: TextView, drawable: Drawable) {
        val drawables = view.compoundDrawables
        view.setCompoundDrawables(drawables[0], drawable, drawables[2], drawables[3])
    }

    @BindingAdapter("android:drawableStart")
    fun setDrawableStart(view: TextView, drawable: Drawable) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
            setDrawableLeft(view, drawable)
        } else {
            val drawables = view.compoundDrawablesRelative
            view.setCompoundDrawablesRelative(drawable, drawables[1], drawables[2], drawables[3])
        }
    }

    @BindingAdapter("android:drawableEnd")
    fun setDrawableEnd(view: TextView, drawable: Drawable) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
            setDrawableRight(view, drawable)
        } else {
            val drawables = view.compoundDrawablesRelative
            view.setCompoundDrawablesRelative(drawables[0], drawables[1], drawable, drawables[3])
        }
    }

    @BindingAdapter("android:imeActionLabel")
    fun setImeActionLabel(view: TextView, value: CharSequence) {
        view.setImeActionLabel(value, view.imeActionId)
    }

    @BindingAdapter("android:imeActionId")
    fun setImeActionLabel(view: TextView, value: Int) {
        view.setImeActionLabel(view.imeActionLabel, value)
    }

    @BindingAdapter("android:inputMethod")
    fun setInputMethod(view: TextView, inputMethod: CharSequence) {
        try {
            val c = Class.forName(inputMethod.toString())
            view.keyListener = c.newInstance() as KeyListener
        } catch (e: ClassNotFoundException) {
            Log.e(TAG, "Could not create input method: $inputMethod", e)
        } catch (e: InstantiationException) {
            Log.e(TAG, "Could not create input method: $inputMethod", e)
        } catch (e: IllegalAccessException) {
            Log.e(TAG, "Could not create input method: $inputMethod", e)
        }

    }

    @BindingAdapter("android:lineSpacingExtra")
    fun setLineSpacingExtra(view: TextView, value: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setLineSpacing(value, view.lineSpacingMultiplier)
        } else {
            view.setLineSpacing(value, 1f)
        }
    }

    @BindingAdapter("android:lineSpacingMultiplier")
    fun setLineSpacingMultiplier(view: TextView, value: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setLineSpacing(view.lineSpacingExtra, value)
        } else {
            view.setLineSpacing(0f, value)
        }
    }

    @BindingAdapter("android:maxLength")
    fun setMaxLength(view: TextView, value: Int) {
        var filters: Array<InputFilter?>? = view.filters
        if (filters == null) {
            filters = arrayOf(InputFilter.LengthFilter(value))
        } else {
            var foundMaxLength = false
            for (i in filters.indices) {
                val filter = filters[i]
                if (filter is InputFilter.LengthFilter) {
                    foundMaxLength = true
                    var replace = true
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        replace = filter.max != value
                    }
                    if (replace) {
                        filters[i] = InputFilter.LengthFilter(value)
                    }
                    break
                }
            }
            if (!foundMaxLength) {
                // can't use Arrays.copyOf -- it shows up in API 9
                val oldFilters = filters
                filters = arrayOfNulls(oldFilters.size + 1)
                System.arraycopy(oldFilters, 0, filters, 0, oldFilters.size)
                filters[filters.size - 1] = InputFilter.LengthFilter(value)
            }
        }
        view.filters = filters
    }

    @BindingAdapter("android:password")
    fun setPassword(view: TextView, password: Boolean) {
        if (password) {
            view.transformationMethod = PasswordTransformationMethod.getInstance()
        } else if (view.transformationMethod is PasswordTransformationMethod) {
            view.transformationMethod = null
        }
    }

    @BindingAdapter("android:shadowColor")
    fun setShadowColor(view: TextView, color: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            val dx = view.shadowDx
            val dy = view.shadowDy
            val r = view.shadowRadius
            view.setShadowLayer(r, dx, dy, color)
        }
    }

    @BindingAdapter("android:shadowDx")
    fun setShadowDx(view: TextView, dx: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            val color = view.shadowColor
            val dy = view.shadowDy
            val r = view.shadowRadius
            view.setShadowLayer(r, dx, dy, color)
        }
    }

    @BindingAdapter("android:shadowDy")
    fun setShadowDy(view: TextView, dy: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            val color = view.shadowColor
            val dx = view.shadowDx
            val r = view.shadowRadius
            view.setShadowLayer(r, dx, dy, color)
        }
    }

    @BindingAdapter("android:shadowRadius")
    fun setShadowRadius(view: TextView, r: Float) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            val color = view.shadowColor
            val dx = view.shadowDx
            val dy = view.shadowDy
            view.setShadowLayer(r, dx, dy, color)
        }
    }

    @BindingAdapter("android:textSize")
    fun setTextSize(view: TextView, size: Float) {
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size)
    }

    @BindingAdapter("android:afterTextChanged")
    fun setListener(view: TextView, after: AfterTextChanged) {
        setListener(view, null, null, after)
    }

    @BindingAdapter("android:beforeTextChanged")
    fun setListener(view: TextView, before: BeforeTextChanged) {
        setListener(view, before, null, null)
    }

    @BindingAdapter("android:onTextChanged")
    fun setListener(view: TextView, onTextChanged: OnTextChanged) {
        setListener(view, null, onTextChanged, null)
    }

    @BindingAdapter("android:beforeTextChanged", "android:afterTextChanged")
    fun setListener(
        view: TextView, before: BeforeTextChanged,
        after: AfterTextChanged
    ) {
        setListener(view, before, null, after)
    }

    @BindingAdapter("android:beforeTextChanged", "android:onTextChanged")
    fun setListener(
        view: TextView, before: BeforeTextChanged,
        on: OnTextChanged
    ) {
        setListener(view, before, on, null)
    }

    @BindingAdapter("android:onTextChanged", "android:afterTextChanged")
    fun setListener(
        view: TextView, on: OnTextChanged,
        after: AfterTextChanged
    ) {
        setListener(view, null, on, after)
    }

    @BindingAdapter("android:beforeTextChanged", "android:onTextChanged", "android:afterTextChanged")
    fun setListener(
        view: TextView, before: BeforeTextChanged?,
        on: OnTextChanged?, after: AfterTextChanged?
    ) {
        val newValue: TextWatcher?
        if (before == null && after == null && on == null) {
            newValue = null
        } else {
            newValue = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                    before?.beforeTextChanged(s, start, count, after)
                }

                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    on?.onTextChanged(s, start, before, count)
                }

                override fun afterTextChanged(s: Editable) {
                    after?.afterTextChanged(s)
                }
            }
        }
        val oldValue = ListenerUtil.trackListener<TextWatcher>(view, newValue, R.id.textWatcher)
        if (oldValue != null) {
            view.removeTextChangedListener(oldValue)
        }
        if (newValue != null) {
            view.addTextChangedListener(newValue)
        }
    }

    interface AfterTextChanged {
        fun afterTextChanged(s: Editable)
    }

    interface BeforeTextChanged {
        fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int)
    }

    interface OnTextChanged {
        fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int)
    }
}