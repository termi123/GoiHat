package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.ListChangeCode
import vn.app.tcs.data.remote.ReportRepository
import vn.app.tcs.data.request.RejectOrderRequest

class RejectOrderUseCase : UseCase<List<String>>(){

    lateinit var request: RejectOrderRequest
    private val authenticateRepository: ReportRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return authenticateRepository.rejectOrder(request)
    }
}