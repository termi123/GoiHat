package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.remote.UserManagerRepository

class UnSelectStaffUseCase : UseCase<List<String>>() {

    var list: Int = 0

    private val userManagerRepository: UserManagerRepository by inject()

    override fun buildUseCaseObservable(): Single<List<String>> {
        return userManagerRepository.unSelectStaff(list)
    }
}