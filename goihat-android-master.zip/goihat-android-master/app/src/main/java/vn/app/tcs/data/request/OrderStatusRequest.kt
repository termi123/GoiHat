package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class OrderStatusRequest(
    @SerializedName("order_id")
    var orderId: Int = 0,
    @SerializedName("staff_id")
    var staffId: Int = 0,
    @SerializedName("action")
    var action: String = "" //Available values : Approve, Cancel, Rejected, Processing, Missed, Complete


)