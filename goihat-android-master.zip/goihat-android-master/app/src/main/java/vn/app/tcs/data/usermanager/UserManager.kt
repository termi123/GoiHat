package vn.app.tcs.data.usermanager

import android.text.TextUtils
import com.base.common.constant.AppConstant
import com.google.gson.Gson
import org.koin.core.KoinComponent
import org.koin.core.inject
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.utils.JsonParserUtils
import vn.app.tcs.utils.sharepref.SharedPreUtils
import java.util.*

class UserManager : KoinComponent {
    private val USER_INFO = "user_info"
    private val USER_TOKEN = "user_token"
    private val FIREBASE_TOKEN = "firebase_token"
    private val USER_ID = "user_id"
    private val IS_USER_LOGIN = "is_user_login"
    private val STAFF_FIRST_TIME = "isStaffFirstTime"
    private val OWNER_FIRST_TIME = "isOwnerFirstTime"
    private val MANAGER_FIRST_TIME = "isManagerFirstTime"

    private val gson: Gson by inject()

    fun setIsUserLogin(isUserLogin: Boolean) = SharedPreUtils.putBoolean(IS_USER_LOGIN, isUserLogin)

    fun setUserInfo(user: UserProfile?) {
        if (user == null) {
            // clear Token
            SharedPreUtils.putString(USER_INFO, "")
            saveUserToken("")
            return
        }
        setUserInfo(user.profile)
        SharedPreUtils.putString(USER_ID, user.profile.id.toString())
        saveUserToken(user.accessToken)
    }

    fun setUserInfo(profile: UserProfile.Profile) = SharedPreUtils.putString(USER_INFO, gson.toJson(profile))

    fun getUserInfo(): UserProfile.Profile? = SharedPreUtils.getString(USER_INFO).run {
        if (TextUtils.isEmpty(this)) null else JsonParserUtils.getUserProfile(this!!)
    }

    fun saveUserToken(token: String) = SharedPreUtils.putString(USER_TOKEN, token)

    fun getUserToken() = SharedPreUtils.getString(USER_TOKEN)

    fun isUserLoggedIn() = (SharedPreUtils.getBoolean(IS_USER_LOGIN, false)
            && !TextUtils.isEmpty(getUserToken()))

    fun setFireBaseToken(firebaseToken: String) = SharedPreUtils.putString(FIREBASE_TOKEN, firebaseToken)

    fun getFireBaseToken() = SharedPreUtils.getString(FIREBASE_TOKEN)!!

    fun getUUID() = UUID.randomUUID().toString();

    fun isFirstTime(): Boolean {
        var isFirstTime = false
        if (getUserInfo() != null) {
            when (getUserInfo()?.role) {
                AppConstant.Role.Staff.name -> {
                    isFirstTime = SharedPreUtils.getBoolean(STAFF_FIRST_TIME, true)
//                    SharedPreUtils.putBoolean(STAFF_FIRST_TIME, false)
                }
                AppConstant.Role.Owner.name -> {
                    isFirstTime = SharedPreUtils.getBoolean(OWNER_FIRST_TIME, true)
//                    SharedPreUtils.putBoolean(OWNER_FIRST_TIME, false)
                }
                AppConstant.Role.Manager.name -> {
                    isFirstTime = SharedPreUtils.getBoolean(MANAGER_FIRST_TIME, true)
//                    SharedPreUtils.putBoolean(MANAGER_FIRST_TIME, false)
                }
            }
        }
        return isFirstTime
    }

    fun setHideIntro() {
        if (getUserInfo() != null) {
            when (getUserInfo()?.role) {
                AppConstant.Role.Staff.name -> SharedPreUtils.putBoolean(STAFF_FIRST_TIME, false)
                AppConstant.Role.Owner.name -> SharedPreUtils.putBoolean(OWNER_FIRST_TIME, false)
                AppConstant.Role.Manager.name -> SharedPreUtils.putBoolean(MANAGER_FIRST_TIME, false)
            }
        }
    }
}