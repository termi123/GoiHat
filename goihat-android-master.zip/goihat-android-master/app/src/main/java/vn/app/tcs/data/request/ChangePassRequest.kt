package vn.app.tcs.data.request

import com.google.gson.annotations.SerializedName

data class ChangePassRequest(
    @SerializedName("old_password") var oldPassword: String,
    @SerializedName("password_confirmation") var passwordConfirmation: String,
    @SerializedName("password") var password: String
)