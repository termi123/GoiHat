package vn.app.tcs.ui.registerbar

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.fragment_manager_home.rvBarList
import kotlinx.android.synthetic.main.fragment_register_bar.*
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.startActivityForResult
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.FragmentRegisterBarBinding
import vn.app.tcs.ui.register.RegisterBarAdapter

class FragmentRegisterBar :
    BaseKaraToolbarActivity<FragmentRegisterBarBinding, FragmentRegisterBarViewModel>() {

    override fun getToolBar(): Toolbar = toolbar

    private val ADD_BAR_REQUEST_CODE = 33
    override val layoutId: Int
        get() = R.layout.fragment_register_bar

    override val viewModel: FragmentRegisterBarViewModel by inject()
    private lateinit var adapter: RegisterBarAdapter

    private var tempBar: Bar = Bar()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (supportActionBar != null) {
            val actionBar = supportActionBar
            actionBar!!.setDisplayHomeAsUpEnabled(false)
        }
        viewModel.bars.observe(this, Observer { listBar ->
            runOnUiThread {
                Handler().postDelayed({
                    listBar?.let {
                        viewDataBinding?.hasBar = !listBar.lists.isNullOrEmpty() && viewModel.changeConfig.value == "on"
                        adapter.setDataList(it.lists)
                    }
                }, 300)
            }
        })
        viewModel.config.observe(this, Observer {
            finish()
        })
        viewModel.deleteBar.observe(this, Observer {
            viewModel.getListBar()
        })

        initBarList()

        ivSave.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                if (viewModel.changeConfig.value == "on" && adapter.getDataList().isNullOrEmpty()) {
                    showDialog2ButtonMessage(
                        MessageDialog(
                            content = "Bạn cần đăng ký ít nhất 1 Cơ sở nếu muốn lọc Cơ sở",
                            tag = "ADD_FILTER",
                            title = getString(
                                R.string.change_status
                            ),
                            confirmButton = "HUỶ",
                            cancelButton = "OK"
                        )
                    )
                    return
                }
                viewModel.configBar()
            }

        })
        viewModel.getProfile()
    }

    private fun initBarList() {
        adapter = RegisterBarAdapter(ArrayList())
        rvBarList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        rvBarList.adapter = adapter
        adapter.onActionBarListener = object : RegisterBarAdapter.OnActionBarListener {
            override fun onEdit(bar: Bar) {
                tempBar = bar
                showDialog2ButtonMessage(
                    MessageDialog(
                        content = "Bạn có chắc muốn xoá cơ sở " + bar.name + " khỏi danh sách giới hạn không?",
                        tag = "REMOVE_REGISTER_BAR",
                        title = "Thông báo",
                        confirmButton = "HUỶ",
                        cancelButton = "OK"
                    )
                )
            }
        }
    }

    override fun handleEventCloseDialog(event: RxEvent.EventCloseDialog) {
//        super.handleEventCloseDialog(event)
        when (event.dialogState) {
            AppConstant.DialogState.Back -> {
                event.tag.let {
                    if (it == "REMOVE_REGISTER_BAR") {
                        tempBar.id?.let { id ->
                            viewModel.deleteBar(id)
                        }
                    }
                    if (it == "ADD_FILTER") {
                        startActivityForResult<ListRegisterBarActivity>(
                            ADD_BAR_REQUEST_CODE
                        )
                    }
                }
            }
            else -> {
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == ADD_BAR_REQUEST_CODE) {
            viewModel.configBar()
            viewModel.getListBar()
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_CHANGE_STATUS -> {
                viewModel.changeConfig.value = if(viewModel.changeConfig.value == "on") "off" else "on"
                if (viewModel.changeConfig.value == "on") {
                    viewModel.getListBar()
                }
            }
            EventConstant.EVENT_ADD_BAR -> {
                startActivity<ListRegisterBarActivity>()
            }
            EventConstant.EVENT_KEEP_STATUS -> {
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getListBar()
    }
}