package vn.app.tcs.ui.call.detail.manager

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.OrderManagerDetail
import vn.app.tcs.data.remote.usecase.GetOrderDetailManagerUseCase
import vn.app.tcs.data.remote.usecase.SetSurveyUseCase
import vn.app.tcs.data.usermanager.UserManager

class OrderDetailManagerViewModel : BaseViewModel() {

    private val getOrderUseCase: GetOrderDetailManagerUseCase by inject()
    private val setSurveyUseCase: SetSurveyUseCase by inject()
    val userManager: UserManager by inject()

    var orderInfo = MutableLiveData<OrderManagerDetail>()
    var orderInfoRequest: LiveData<OrderManagerDetail>
    var setSurveyRequest: LiveData<List<String>>

    init {
        orderInfoRequest = Transformations.map(getOrderUseCase.result) {
            handleCommonApi(it)
        }
        setSurveyRequest = Transformations.map(setSurveyUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun getInfoDetail(id: Int) = getOrderUseCase.apply { this.id = id }.execute()

    fun setSurvey(id: Int, required: Int, needed: Int) = setSurveyUseCase.apply {
        this.orderId = id
        this.numberStaffsRequired = required
        this.numberStaffsNeeded = needed
    }.execute()

    fun doBack() = sendEvent(EventConstant.EVENT_BACK)

    fun doFinish() = sendEvent(EventConstant.EVENT_FINISH)
}