package vn.app.tcs.ui.dialog

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import com.aigestudio.wheelpicker.WheelPicker
import com.base.common.base.dialog.BaseDialog
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.wheel_picker_dialog.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.WheelPickerDialogBinding

class WheelPickerDialog : BaseDialog<WheelPickerDialogBinding, WheelPickerDialogViewModel>(),
    WheelPicker.OnItemSelectedListener {
    override val layoutId: Int = R.layout.wheel_picker_dialog
    override val viewModel: WheelPickerDialogViewModel by inject()

    override fun updateUI(savedInstanceState: Bundle?) {
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tvContent.data = viewModel.data
        tvContent.setSelectedItemPosition(viewModel.originPos,false)
        tvContent.setOnItemSelectedListener(this)
    }

    override fun onItemSelected(picker: WheelPicker?, data: Any?, position: Int) {
        if (data is String) {
            viewModel.currentSelect = data
        }
    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_ACCEPT -> {
                dismissAllowingStateLoss()
                viewModel.publishRxEvent(
                    RxEvent.EventDialog(viewModel.content.value?.tag, viewModel.currentSelect!!)
                )
            }
            EventConstant.EVENT_DISMISS -> {
                dismissAllowingStateLoss()
            }
        }
    }


    companion object {
        fun newInstance(messageDialog: MessageDialog, data: ArrayList<String>, selectedPos: Int = 0) =
            WheelPickerDialog().apply {
                viewModel.content.value = messageDialog
                viewModel.data = data
                if (data.isNotEmpty()) {
                    viewModel.currentSelect = data[0]
                }
                if(selectedPos > 0){
                    viewModel.originPos = selectedPos
                }
            }
    }

}
