package vn.app.tcs.ui.staffhistorycall

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.data.karaconstant.DEFAULT_PAGE
import vn.app.tcs.data.karaconstant.EventConstant.EVENT_SELF_CALL_STAFF
import vn.app.tcs.data.model.OrderManager
import vn.app.tcs.data.model.StaffActivityResponse
import vn.app.tcs.data.remote.usecase.GetListOrderStaffUseCase
import vn.app.tcs.data.remote.usecase.GetStaffActivityUseCase

class StaffCallHistoryViewModel : BaseListViewModel() {
    private val getListOrderStaffUseCase: GetListOrderStaffUseCase by inject()
    val emptyList = MutableLiveData<Boolean>()
    val refreshing = MutableLiveData<Boolean>()
    var currentOption = arrayListOf("New", "Approve", "Processing")
    private val getStaffActivityUseCase: GetStaffActivityUseCase by inject()
    val listOrderStaff: LiveData<OrderManager> = Transformations.map(getListOrderStaffUseCase.result) {
        handleCommonApi(it)
    }
    var getStaffActivityRequest: LiveData<StaffActivityResponse> = Transformations.map(getStaffActivityUseCase.result) {
        handleCommonApi(it)
    }

    init {
        getList(arrayListOf("New", "Approve", "Processing"))
    }

    fun getList(option: List<String>) {
        currentOption = option as ArrayList<String>
        getListOrderStaffUseCase.apply {
            this.option = option
            this.currentPage = page
        }.executeZip({
            emptyList.value = it.lists?.isEmpty()
            refreshing.value = false
            page++
        }, {
            refreshing.value = false
        })
    }

    fun refresh(option: List<String>){
        page = DEFAULT_PAGE
        getList(option)
    }

    fun getStaffActivity() {
        getStaffActivityUseCase.execute()
    }

    fun report() {
        sendEvent(EVENT_SELF_CALL_STAFF)
    }
}
