package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.AuthenticateRepository
import vn.app.tcs.data.request.UserLogInRequest

class LoginUseCase() : UseCase<UserProfile>() {
    lateinit var userLogInRequest: UserLogInRequest
    private val authenticateRepository: AuthenticateRepository by inject()

    override fun buildUseCaseObservable(): Single<UserProfile> {
        return authenticateRepository.login(userLogInRequest)
    }
}