package vn.app.tcs.data.remote.usecase

import com.base.common.usecase.UseCase
import io.reactivex.Single
import org.koin.core.inject
import vn.app.tcs.data.model.CheckVersionResponse
import vn.app.tcs.data.remote.AuthenticateRepository
import vn.app.tcs.data.request.CheckVersionRequest

class CheckVersionUseCase() : UseCase<CheckVersionResponse>() {

    lateinit var checkVersionRequest: CheckVersionRequest
    private val authenticateRepository: AuthenticateRepository by inject()

    override fun buildUseCaseObservable(): Single<CheckVersionResponse> {
        return authenticateRepository.checkVersion(checkVersionRequest)
    }
}