package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import vn.app.tcs.data.model.Notify

interface NotificationSource {

    @GET("/api/notification")
    fun getNotification(@Query("category") category: String?, @Query("page") page: Int): Single<Notify>

    @POST("/api/notification/{notification_id}/read")
    fun setRead(@Path("notification_id") orderId: String): Single<List<String>>

    @POST("/api/notification/read-all")
    fun setRead(): Single<List<String>>
}