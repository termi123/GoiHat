package vn.app.tcs.data.model


import com.google.gson.annotations.SerializedName
import vn.app.tcs.utils.TimeUtil

data class ListBlackList(
    @SerializedName("lists")
    val lists: List<BlackList>?,
    @SerializedName("current_page")
    val currentPage: Int,
    @SerializedName("last_page")
    val lastPage: Int,
    @SerializedName("total")
    val total: Int,
    @SerializedName("per_page")
    val perPage: Int
) {
    data class BlackList(
        @SerializedName("id")
        val id: Int,
        @SerializedName("reason")
        val reason: String,
        @SerializedName("type")
        val type: String,
        @SerializedName("order")
        val order: Order,
        @SerializedName("staff")
        val staff: UserProfile.Profile,
        @SerializedName("read_at")
        var readAt: String = "",
        @SerializedName("created_at")
        val createdAt: Long
    ) {

        fun getTime() = TimeUtil.milliSecondToDate(createdAt, TimeUtil.DATE_FOMART_NOTI)

        data class Order(
            @SerializedName("id")
            val id: Int,
            @SerializedName("room")
            val room: Bar.Room,
            @SerializedName("bar")
            val bar: Bar
        )
        fun getDes() = "Phát hiện hành vi gian lận của Ca sĩ \"" + staff.name + "\"" + " (" + staff.code + ")"
        fun getFullDes() = getDes() + " tại Cơ sở " + "\"" + order.bar.name + " \" (phòng " + "\"" + order.room.name + "\") lúc " + getTime()

    }
}