package vn.app.tcs.ui.dialog

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import com.base.common.base.dialog.BaseDialog
import com.base.common.constant.AppConstant
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.CommonDialogBinding

class CommonDialog : BaseDialog<CommonDialogBinding, CommonDialogViewModel>() {
    override val viewModel: CommonDialogViewModel by inject()
    override val layoutId: Int
        get() = R.layout.common_dialog

    override fun updateUI(savedInstanceState: Bundle?) {

    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_DISMISS -> {
                dismiss()
                viewModel.publishRxEvent(
                    RxEvent.EventCloseDialog(
                        AppConstant.DialogState.Close,
                        viewModel.content.value?.tag
                    )
                )
                viewModel.publishRxEvent(RxEvent.EventDialog(viewModel.content.value?.tag, viewModel.content.value?.datas ?: ""))
            }
            EventConstant.EVENT_NEG_DIALOG -> {
                dismiss()
                viewModel.publishRxEvent(RxEvent.EventNegativeClick(viewModel.content.value?.tag))
            }
        }
    }

    companion object {
        fun newInstance(messageDialog: MessageDialog) = CommonDialog().apply {
            viewModel.content.value = messageDialog
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


}
