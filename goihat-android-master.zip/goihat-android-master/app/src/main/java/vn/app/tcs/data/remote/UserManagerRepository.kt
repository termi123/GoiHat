package vn.app.tcs.data.remote

import android.text.TextUtils
import io.reactivex.Single
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import vn.app.tcs.data.model.*
import vn.app.tcs.data.request.*

interface UserManagerRepository {
    fun register(userRegisterRequest: UserRegisterRequest): Single<List<String>>

    fun updateLocation(id: String, locationRequest: LocationRequest): Single<List<String>>

    fun getUserInfo(id: String): Single<UserProfile>

    fun getProfile(): Single<UserProfile>

    fun updateProfile(basicProfile: UpdateProfileRequest): Single<UserProfile>

    fun getStaffs(page: Int): Single<ListStaff>

    fun filterIncome(time: String?, from: String?, to: String?): Single<IncomeResponse>

    fun updateActivity(activity: String): Single<List<String>>

    fun unSelectStaff(listStaff: Int): Single<List<String>>

    fun unSelectStaffs(listStaff: List<Int>): Single<List<String>>

    fun chooseStaff(listStaff: Int): Single<List<String>>

    fun getFavoriteStaff(favoriteOptionRequest: FavoriteOptionRequest): Single<ListStaff>

    fun favoriteStaff(favoriteRequest: FavoriteRequest): Single<List<String>>

    fun changeOwnerCode(newCode: String?): Single<List<String>>

    fun updateFeeAll(fee: Int): Single<List<String>>

    fun updateFeeOne(fee: Int, staffId: Int): Single<List<String>>

    fun getStaffActivity(): Single<StaffActivityResponse>

    fun sendStar(code: String?, money: Int, password: String?): Single<List<String>>

    fun actionReport(
        page: Int,
        from: String?,
        to: String?,
        option: String?,
        time: String?
    ): Single<ActionReportResponse>

}

class UserManagerRepositoryImpl(private val userManagementSource: UserManagementSource) :
    UserManagerRepository {
    override fun sendStar(code: String?, money: Int, password: String?): Single<List<String>> {
        return userManagementSource.sendStar(code, money, password)
    }

    override fun updateFeeAll(fee: Int): Single<List<String>> {
        return userManagementSource.updateFeeAll(fee)
    }

    override fun updateFeeOne(fee: Int, staffId: Int): Single<List<String>> {
        return userManagementSource.updateFeeOne(fee, staffId)
    }

    override fun changeOwnerCode(newCode: String?): Single<List<String>> {
        return userManagementSource.changeOwnerCode(newCode)
    }

    override fun actionReport(
        page: Int,
        from: String?,
        to: String?,
        option: String?,
        time: String?
    ): Single<ActionReportResponse> {
        return userManagementSource.actionReport(page, from, to, option, time)
    }

    override fun filterIncome(time: String?, from: String?, to: String?): Single<IncomeResponse> {
        return userManagementSource.getIncomeFilter(time, from, to)
    }

    override fun getStaffActivity(): Single<StaffActivityResponse> {
        return userManagementSource.getStaffActivity()
    }

    override fun favoriteStaff(favoriteRequest: FavoriteRequest): Single<List<String>> {
        return userManagementSource.favorite(favoriteRequest)
    }

    override fun getFavoriteStaff(favoriteOptionRequest: FavoriteOptionRequest): Single<ListStaff> {
        return userManagementSource.getFavoriteStaff(
            favoriteOptionRequest.page.toInt(),
            favoriteOptionRequest.option,
            favoriteOptionRequest.barId
        )
    }

    override fun register(userRegisterRequest: UserRegisterRequest): Single<List<String>> {
        return userManagementSource.register(MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .apply {
                if (userRegisterRequest.avatar != null) {
                    val image = RequestBody.create(
                        "image/*".toMediaType(),
                        userRegisterRequest.avatar!!
                    )
                    addFormDataPart("avatar", userRegisterRequest.avatar?.name, image)
                }
            }
            .build()
            ,
            userRegisterRequest.name
            ,
            userRegisterRequest.phone
            ,
            userRegisterRequest.password
            ,
            userRegisterRequest.role
            ,
            if (TextUtils.isEmpty(userRegisterRequest.referral_code)) null else userRegisterRequest.referral_code
        )
    }

    override fun updateLocation(
        id: String,
        locationRequest: LocationRequest
    ): Single<List<String>> {
        return userManagementSource.updateLocation(id, locationRequest)
    }

    override fun getUserInfo(id: String): Single<UserProfile> {
        return userManagementSource.getUserInfo(id)
    }

    override fun getProfile(): Single<UserProfile> {
        return userManagementSource.getProfile()
    }

    override fun updateProfile(basicProfile: UpdateProfileRequest): Single<UserProfile> {
        return userManagementSource.updateProfile(MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .apply {
                basicProfile.images.forEach {
                    addFormDataPart(
                        "images[]",
                        it.name,
                        RequestBody.create("image/*".toMediaType(), file = it)
                    )
                }

                if (basicProfile.avatarFile != null) {
                    val image = RequestBody.create(
                        "image/*".toMediaType(),
                        basicProfile.avatarFile!!
                    )
                    addFormDataPart("avatar", basicProfile.avatarFile?.name, image)
                    return@apply
                }
                addFormDataPart("empty","")
            }
            .build(), basicProfile.name, basicProfile.gallery_ids
        )
    }

    override fun getStaffs(page: Int): Single<ListStaff> {
        return userManagementSource.getStaffs(page)
    }

    override fun updateActivity(activity: String): Single<List<String>> {
        return userManagementSource.updateActivity(ActivityRequest(activity))
    }

    override fun unSelectStaff(listStaff: Int): Single<List<String>> {
        return userManagementSource.unSelectStaff(SelectStaffRequest(listStaff))
    }

    override fun unSelectStaffs(listStaff: List<Int>): Single<List<String>> {
        return userManagementSource.unSelectStaffs(UnSelectStaffRequest(listStaff))
    }

    override fun chooseStaff(listStaff: Int): Single<List<String>> {
        return userManagementSource.chooseStaff(SelectStaffRequest(listStaff))
    }
}