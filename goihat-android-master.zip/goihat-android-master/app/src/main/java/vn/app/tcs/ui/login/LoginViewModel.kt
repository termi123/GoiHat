package vn.app.tcs.ui.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.StaffActivityResponse
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetStaffActivityUseCase
import vn.app.tcs.data.remote.usecase.LoginUseCase
import vn.app.tcs.data.request.UserLogInRequest
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.utils.sharepref.SharedPreUtils

class LoginViewModel : BaseViewModel() {
    private val loginUseCase: LoginUseCase by inject()
    var userProfile: LiveData<UserProfile?>
    private val userManager: UserManager by inject()
    val itemPosition = MutableLiveData<Int>()
    private val getStaffActivityUseCase: GetStaffActivityUseCase by inject()
    var getStaffActivityRequest: LiveData<StaffActivityResponse> = Transformations.map(getStaffActivityUseCase.result) {
        handleCommonApi(it)
    }

    init {
        userProfile = Transformations.map(loginUseCase.result) {
            handleCommonApi(it, false)
        }
//        SharedPreUtils.clearPrefs()
    }

    fun login(userName: String, password: String, role: String) {
        loginUseCase.apply { userLogInRequest = UserLogInRequest(userName, password, role) }
            .execute()
    }


    fun doLogin() = sendEvent(EventConstant.EVENT_LOGIN)

    fun goToRegister() = sendEvent(EventConstant.EVENT_REGISTER)

    fun goToForgotPass() = sendEvent(EventConstant.EVENT_FORGOT_PASS)

    fun callSupport() = sendEvent(EventConstant.EVENT_CALL_SUPPORT)

    fun goToChangePass() = sendEvent(EventConstant.EVENT_CHANGE_PASS)

    fun saveUserInfor(userProfile: UserProfile) {
        userManager.setUserInfo(userProfile)
        userManager.setIsUserLogin(true)
    }

    fun getStaffActivity() {
        getStaffActivityUseCase.execute()
    }
}