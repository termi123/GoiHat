package vn.app.tcs.base

import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.ui.call.select.SelectStaffViewModel

abstract class BaseItemViewModel<T : BaseViewModel> : BaseViewModel() {
    lateinit var mainViewModel : T
}