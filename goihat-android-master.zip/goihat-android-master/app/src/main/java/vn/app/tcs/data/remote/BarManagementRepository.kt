package vn.app.tcs.data.remote

import io.reactivex.Single
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import vn.app.tcs.KaraApplication
import vn.app.tcs.R
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.model.ListBar
import vn.app.tcs.data.request.AddBarRequest

interface BarManagementRepository {
    fun getListBar(id: String): Single<ListBar>
    fun registerBar(addBarRequest: AddBarRequest): Single<ArrayList<String>>
    fun updateBar(addBarRequest: AddBarRequest): Single<Bar>
    fun getBarDetail(id: String): Single<Bar>
    fun deleteBar(id: String): Single<ArrayList<String>>
}

class BarManagementRepositoryImpl(private var barManagementSource: BarManagementSource) :
    BarManagementRepository {
    override fun updateBar(addBarRequest: AddBarRequest): Single<Bar> {
        return barManagementSource.updateBar(addBarRequest.id,
            MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .apply {
                    if (addBarRequest.avatar != null) {
                        val image = RequestBody.create(
                            "image/*".toMediaType(),
                            addBarRequest.avatar!!
                        )
                        addFormDataPart("avatar", addBarRequest.avatar?.name, image)
                    }

                }
                .addFormDataPart("fee", addBarRequest.fee)
                .addFormDataPart("name", addBarRequest.name)
                .addFormDataPart("manager_id", addBarRequest.managerId)
                .addFormDataPart(
                    "address",
                    if (KaraApplication.instance!!.getString(R.string.address) == addBarRequest.address) "" else addBarRequest.address
                )
                .addFormDataPart("latitude", addBarRequest.latitude.toString())
                .addFormDataPart("longitude", addBarRequest.longitude.toString())
                .addFormDataPart("description", addBarRequest.description)
                .build(),
            addBarRequest.getBarNames()
        )
    }

    override fun deleteBar(id: String): Single<ArrayList<String>> {
        return barManagementSource.deleteBar(id)
    }

    override fun getBarDetail(id: String): Single<Bar> {
        return barManagementSource.getBarDetail(id)
    }

    override fun registerBar(addBarRequest: AddBarRequest): Single<ArrayList<String>> {
        return barManagementSource.registerBar(
            MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .apply {
                    if (addBarRequest.avatar != null) {
                        val image = RequestBody.create(
                            "image/*".toMediaType(),
                            addBarRequest.avatar!!
                        )
                        addFormDataPart("avatar", addBarRequest.avatar?.name, image)
                    }

                }
                .addFormDataPart("name", addBarRequest.name)
                .addFormDataPart("fee", addBarRequest.fee)
                .addFormDataPart("manager_id", addBarRequest.managerId)
                .addFormDataPart(
                    "address",
                    if (KaraApplication.instance!!.getString(R.string.address) == addBarRequest.address) "" else addBarRequest.address
                )
                .addFormDataPart("latitude", addBarRequest.latitude.toString())
                .addFormDataPart("longitude", addBarRequest.longitude.toString())
                .addFormDataPart("description", addBarRequest.description)
                .build(),
            addBarRequest.getBarNames()
        )
    }

    override fun getListBar(id: String): Single<ListBar> {
        return barManagementSource.getListBar(id)
    }

}