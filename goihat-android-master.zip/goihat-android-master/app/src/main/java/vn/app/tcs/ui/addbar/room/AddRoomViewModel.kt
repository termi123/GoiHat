package vn.app.tcs.ui.addbar.room

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.google.gson.Gson
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.data.remote.usecase.DeleteRoomUseCase
import vn.app.tcs.data.remote.usecase.RegisterRoomUseCase
import vn.app.tcs.data.remote.usecase.UpdateRoomUseCase

class AddRoomViewModel : BaseViewModel() {

    var barId: Int = 0
    private val gson: Gson by inject()

    private val registerRoomUseCase: RegisterRoomUseCase by inject()
    var registerRoomRequestData: LiveData<Bar.ListRoom>

    private val updateRoomUseCase: UpdateRoomUseCase by inject()
    var updateRoomRequestData: LiveData<Bar.ListRoom>

    private val deleteRoomUseCase: DeleteRoomUseCase by inject()
    var deleteRoomRequestData: LiveData<ArrayList<String>>

    init {
        registerRoomRequestData = Transformations.map(registerRoomUseCase.result) {
            handleCommonApi(it)
        }
        updateRoomRequestData = Transformations.map(updateRoomUseCase.result) {
            handleCommonApi(it)
        }
        deleteRoomRequestData = Transformations.map(deleteRoomUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun registerRoom(listRooms: ArrayList<String>) {
        registerRoomUseCase.apply {
            bar_id = barId
            listRoom = listRooms
        }.execute()
    }

    fun updateRoom(listRooms: ArrayList<Bar.Room>) {
        updateRoomUseCase.apply {
            bar_id = barId
            listRoom = gson.toJson(listRooms[0])
        }.execute()
    }

    fun deleteRoom(listRooms: ArrayList<Int>) {
        deleteRoomUseCase.apply {
            listRoom = listRooms
        }.execute()
    }

    fun doAddRoom() = sendEvent(EventConstant.EVENT_ADD_ROOM)
}