package vn.app.tcs.ui.staffhome

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import org.koin.core.inject
import timber.log.Timber
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.GetProfileUseCase
import vn.app.tcs.data.remote.usecase.UpdateActivityUseCase
import vn.app.tcs.data.usermanager.UserManager


class StaffHomeViewModel : BaseViewModel() {

    val userManager: UserManager by inject()
    var profile = MutableLiveData<UserProfile.Profile>()
    var profileRequestData: LiveData<UserProfile?>
    private val getProfileUseCase: GetProfileUseCase by inject()

    val updateActivityUseCase: UpdateActivityUseCase by inject()
    val status = MutableLiveData<String>()
    var updateActivty: LiveData<List<String>> = Transformations.map(updateActivityUseCase.result) {
        handleCommonApi(it)
    }

    init {
        updateProfile()
        profileRequestData = Transformations.map(getProfileUseCase.result) {
            handleCommonApi(it)
        }
        Transformations.map(updateActivityUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun setDatabaseListener(database: DatabaseReference) {
        profile.value.let {
            database.child("users").child(userManager.getUserInfo()?.id.toString()).child("status")
                .addValueEventListener(object : ValueEventListener {
                    override fun onCancelled(databaseError: DatabaseError) {
                        Timber.d("loadPost:%s", databaseError.toException())
                    }

                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (!dataSnapshot.exists()) return
                        val p = userManager.getUserInfo()
                        p?.activity = dataSnapshot.getValue(String::class.java).toString()
                        profile.value = p
                    }
                })
        }
    }

    fun getProfile() {
        getProfileUseCase.executeZip({
            userManager.setUserInfo(it.profile)
            profile.value = it.profile
        }, {})
    }

    fun updateActivity(activity: String) {
        updateActivityUseCase.apply {
            this.activity = activity
        }.executeZip({
            status.postValue(activity)
        }, {})
    }

    fun callSupport() = sendEvent(EventConstant.EVENT_CALL)

    fun copyCode() = sendEvent(EventConstant.EVENT_COPY)

    fun showAlbum() = sendEvent(EventConstant.EVENT_SHOW_ALBUM)

    fun copyRefCode() = sendEvent(EventConstant.EVENT_COPY_USER)

    fun editOwnerCode() = sendEvent(EventConstant.EVENT_CHANGE_NEW_CODE)

    fun editProfile() = sendEvent(EventConstant.EVENT_EDIT_DIALOG)

    fun updateProfile() {
        profile.value = userManager.getUserInfo()
    }
}
