package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.Body
import vn.app.tcs.data.model.*
import vn.app.tcs.data.request.OrderStatusRequest
import vn.app.tcs.data.request.ReportRequest
import vn.app.tcs.data.request.StaffOrderRequest

interface OrderRepository {
    fun getAvailableStaffs(id: Int, page: Int): Single<ListStaff>

    fun getOrderForStaffs(page: Int, option: List<String>): Single<OrderManager>

    fun getOrderDetailForStaffs(orderId: Int): Single<DetailOrderStaff>

    fun getOrderDetailForManager(orderId: Int): Single<OrderManagerDetail>

    fun getOrderForManager(page: Int, isSurvey: Boolean): Single<OrderManager>

    //unUsed
    fun getFraudAlert(page: Int): Single<OrderManager>

    fun setOrderStatus(orderId: Int, @Body orderStatusRequest: OrderStatusRequest): Single<List<String>>

    fun getSurvey(orderId: Int): Single<List<String>>

    fun staffOrder(staffOrder : StaffOrderRequest): Single<StaffOrderResponse>

    fun report(report : ReportRequest): Single<List<String>>

    fun setSurvey(
        orderId: Int,
        numberStaffsRequired: Int,
        numberStaffsNeeded: Int
    ): Single<List<String>>

    fun checkSurvey(
        barId: Int,
        roomId: Int
    ): Single<List<String>>

    fun orderStaffs(id: Int, numberRequired: Int, fee: String, isRandom: Boolean?, listStaff: List<Int>): Single<OrderResponse>

}

class OrderRepositoryImpl(private val orderSource: OrderSource) :
    OrderRepository {
    override fun staffOrder(staffOrder: StaffOrderRequest): Single<StaffOrderResponse> {
        return orderSource.staffOrder(staffOrder.description)
    }

    override fun report(report: ReportRequest): Single<List<String>> {
        return orderSource.report(report)
    }

    override fun getSurvey(orderId: Int): Single<List<String>> {
        return orderSource.getSurvey(orderId)
    }

    override fun setSurvey(orderId: Int, numberStaffsRequired: Int, numberStaffsNeeded: Int): Single<List<String>> {
        return orderSource.setSurvey(orderId, numberStaffsRequired, numberStaffsNeeded)
    }

    override fun checkSurvey(barId: Int, roomId: Int): Single<List<String>> {
        return orderSource.checkSurvey(barId, roomId)
    }

    override fun getFraudAlert(page: Int): Single<OrderManager> {
        return orderSource.getFraudAlert(page)
    }

    override fun orderStaffs(id: Int, numberRequired: Int, fee: String, isRandom: Boolean?, listStaff: List<Int>): Single<OrderResponse> {
        return orderSource.orderStaffs(
            id,
            numberRequired,
            1,
            fee,
            isRandom,
            listStaff
        )
    }

    override fun getOrderForStaffs(page: Int, option: List<String>): Single<OrderManager> {
        return orderSource.getOrderForStaffs(page, option)
    }

    override fun getOrderDetailForStaffs(orderId: Int): Single<DetailOrderStaff> {
        return orderSource.getOrderDetailForStaffs(orderId)
    }

    override fun getOrderDetailForManager(orderId: Int): Single<OrderManagerDetail> {
        return orderSource.getOrderDetailForManager(orderId)
    }

    override fun getOrderForManager(page: Int, isSurvey: Boolean): Single<OrderManager> {
        return orderSource.getOrderForManager(page, if (isSurvey) "yes" else "no")
    }

    override fun setOrderStatus(orderId: Int, orderStatusRequest: OrderStatusRequest): Single<List<String>> {
        return orderSource.setOrderStatus(orderId, orderStatusRequest)
    }

    override fun getAvailableStaffs(id: Int, page: Int): Single<ListStaff> {
        return orderSource.getAvailableStaffs(id, page)
    }
}