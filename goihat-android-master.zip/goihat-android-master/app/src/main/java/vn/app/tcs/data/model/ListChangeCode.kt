package vn.app.tcs.data.model


import com.google.gson.annotations.SerializedName
import vn.app.tcs.utils.TimeUtil

data class ListChangeCode(
    @SerializedName("lists")
    val lists: List<ChangeCode>?,
    @SerializedName("current_page")
    val currentPage: Int,
    @SerializedName("last_page")
    val lastPage: Int,
    @SerializedName("total")
    val total: Int,
    @SerializedName("per_page")
    val perPage: Int
) {
    data class ChangeCode(
        @SerializedName("id")
        val id: Int,
        @SerializedName("is_changed")
        val isChanged: String,
        @SerializedName("type")
        val type: String,
        @SerializedName("staff")
        val staff: UserProfile.Profile,
        @SerializedName("new_owner")
        val newOwner: UserProfile.Profile,
        @SerializedName("old_owner")
        val oldOwner: UserProfile.Profile,
        @SerializedName("read_at")
        var readAt: String = "",
        @SerializedName("created_at")
        val createdAt: Long
    ) {
        fun getTime() = TimeUtil.milliSecondToDate(createdAt, TimeUtil.DATE_FOMART_NOTI)
        fun getChange() = if(isChanged.isBlank() || isChanged == "N") "CHƯA XỬ LÝ" else "ĐÃ XỬ LÝ"
        fun getDes() = "Ca sĩ \"" + staff.name + "\"" + " (" + staff.code + ") " + "yêu cầu đổi Mã quản lý từ \"" + oldOwner.code + "\" sang \"" + newOwner.code + "\""
        fun getFullDes() = getDes() + " vào lúc " + getTime() + "<br/>" + getChange()
    }
}