package vn.app.tcs.ui.profile

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.remote.usecase.UpdateProfileUseCase
import vn.app.tcs.data.request.UpdateProfileRequest
import vn.app.tcs.data.usermanager.UserManager
import vn.app.tcs.ui.profile.adapter.PickerImageStaffAction

class ProfileViewModel : BaseViewModel() {
    lateinit var currentPickTag : PickerImageStaffAction
    val updateRequest: UpdateProfileRequest by lazy { UpdateProfileRequest() }
    private val updateProfileUseCase: UpdateProfileUseCase by inject()
    var profile = MutableLiveData<UserProfile.Profile>()
    val userManager: UserManager by inject()
    val updateProfile = Transformations.map(updateProfileUseCase.result){
        handleCommonApi(it)
    }
    val deleteIds = ArrayList<Int>()

    init {
        profile.value = userManager.getUserInfo()
    }

    fun updateProfile() {
        updateProfileUseCase.apply {
            this.updateProfileRequest = updateRequest
        }.executeZip({
            sendEvent(EventConstant.EVENT_UPDATE_PROFILE_SUCCESS)
            userManager.setUserInfo(it.profile)
        }, {
        })

    }

    fun doPickImage(pickerImageStaffAction: PickerImageStaffAction){
        currentPickTag = pickerImageStaffAction
        sendEvent(EventConstant.EVENT_PICK_IMAGE_STAFF)
    }

    fun doUpdateProfile() = sendEvent(EventConstant.EVENT_UPDATE_PROFILE)

    fun doPickImage() = sendEvent(EventConstant.EVENT_PICK_IMAGE)

}