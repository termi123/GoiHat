package vn.app.tcs.ui.call.bar

import android.os.Bundle
import androidx.appcompat.widget.Toolbar
import androidx.databinding.Observable
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import kotlinx.android.synthetic.main.activity_choose_bar.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import vn.app.tcs.R
import vn.app.tcs.base.BaseKaraToolbarActivity
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ActivityChooseBarBinding
import vn.app.tcs.ui.managerhome.adapter.BarAdapter
import android.content.Intent
import android.app.Activity


class ChooseBarActivity : BaseKaraToolbarActivity<ActivityChooseBarBinding, ChooseBarViewModel>(),
    BaseAdapter.OnClickItemListener<Bar> {
    override val viewModel: ChooseBarViewModel  by viewModel()
    val adapter : BarAdapter by lazy {
        BarAdapter(ArrayList()).apply { isNeedShowEdit = false }
    }
    private val listBar : List<Bar> by lazy { intent!!.extras!!.get(EventConstant.KEY_BAR_ORIGIN) as List<Bar> }
    override fun getToolBar(): Toolbar {
        return toolbar
    }

    override val layoutId: Int
        get() = R.layout.activity_choose_bar

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rvBarList.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        adapter.setOnClickListener(this)
        adapter.setDataList(listBar as ArrayList<Bar>)
        rvBarList.adapter = adapter
    }

    override fun onClickItem(item: Bar, position : Int) {
        val returnIntent = Intent()
        returnIntent.putExtra(EventConstant.KEY_BAR_ID,item)
        setResult(Activity.RESULT_OK, returnIntent)
        finish()
    }

}
