package vn.app.tcs.ui.stafforder

import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.  StaffOrderUseCase
import vn.app.tcs.data.request.StaffOrderRequest

class StaffOrderViewModel(var staffOrderUseCase: StaffOrderUseCase) : BaseViewModel() {

    var orderResult = Transformations.map(staffOrderUseCase.result){
        handleCommonApi(it)
    }

    fun doOrder() = sendEvent(EventConstant.EVENT_SEND_STAFF_ORDER)

    fun order(description : String){
        staffOrderUseCase.apply {
            staffOrderRequest = StaffOrderRequest(description)
        }.executeZip({
            sendEvent(EventConstant.EVENT_STAFF_ORDER)
        },{})
    }
}