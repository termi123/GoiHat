package vn.app.tcs.ui.addbar.room

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.base.common.base.adapter.BaseAdapter
import com.base.common.base.adapter.BaseViewHolder
import com.base.common.utils.ext.inflateExt
import org.jetbrains.anko.sdk27.coroutines.onClick
import vn.app.tcs.R
import vn.app.tcs.data.model.Bar
import vn.app.tcs.databinding.ItemRoomListBinding

class RoomAdapter(data: ArrayList<Bar.Room>) : BaseAdapter<Bar.Room>(data) {

    lateinit var onActionBarListener: OnActionBarListener

    override fun onCreateViewHolderBase(parent: ViewGroup?, viewType: Int): RecyclerView.ViewHolder {
        return BarViewHolder(parent?.inflateExt(R.layout.item_room_list)!!)
    }

    override fun onBindViewHolderBase(holder: RecyclerView.ViewHolder?, position: Int) {
        if (holder is BarViewHolder) {
            holder.onBind(list[position])
            holder.binding.ivEdit.onClick {
                if (::onActionBarListener.isInitialized) onActionBarListener.onEdit(position)
            }
        }

    }

    class BarViewHolder(view: View) : BaseViewHolder<Bar.Room, ItemRoomListBinding>(view) {
        override fun onBind(item: Bar.Room) {
            binding.bar = item
        }

    }

    interface OnActionBarListener {
        fun onEdit(position: Int)
    }
}