package vn.app.tcs.ui.stafflist

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import com.base.common.constant.AppConstant
import org.koin.core.inject
import vn.app.tcs.base.BaseListViewModel
import vn.app.tcs.base.LoadingState
import vn.app.tcs.data.model.ListStaff
import vn.app.tcs.data.remote.usecase.MyStaffUseCase

class StaffListViewModel() : BaseListViewModel() {
    private val myStaffUseCase: MyStaffUseCase by inject()


    var employees: LiveData<ListStaff?> = Transformations.map(myStaffUseCase.result) {
       handleStateCommonApi(it)

    }


    override fun loadData(){
        getListStaff()
    }

    fun getListStaff(){
        myStaffUseCase.apply {
            pageNum = page
        }.executeZip({
            page++
            isEmpty.value = (stateLoading == LoadingState.INIT || stateLoading == LoadingState.REFRESH) && it.staff.isNullOrEmpty()
        },{

        })
    }
}