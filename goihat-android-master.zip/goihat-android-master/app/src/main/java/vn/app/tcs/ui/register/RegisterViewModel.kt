package vn.app.tcs.ui.register

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import com.base.common.base.viewmodel.BaseViewModel
import org.koin.core.inject
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.data.remote.usecase.RegisterUseCase
import vn.app.tcs.data.request.UserRegisterRequest
import java.io.File

class RegisterViewModel : BaseViewModel() {

    private val registerUseCase: RegisterUseCase by inject()
    var userRegister: LiveData<List<String>>
    var avatar: File? = null
    var categoryList: List<String> = emptyList()
    val itemPosition = MutableLiveData<Int>()
    val agreeTerms = MutableLiveData<Boolean>()

    init {
        userRegister = Transformations.map(registerUseCase.result) {
            handleCommonApi(it)
        }
    }

    fun register(registerRequest: UserRegisterRequest) {
        registerUseCase.apply { userRegisterRequest = registerRequest.also { it.avatar = avatar } }
            .execute()
    }

    fun doRegister() = sendEvent(EventConstant.EVENT_REGISTER)
    fun doPickAvatar() = sendEvent(EventConstant.EVENT_PICK_IMAGE)
    fun doShowTerm() = sendEvent(EventConstant.EVENT_TERM)
}