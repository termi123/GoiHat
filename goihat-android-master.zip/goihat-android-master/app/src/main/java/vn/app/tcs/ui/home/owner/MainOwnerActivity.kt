package vn.app.tcs.ui.home.owner

import androidx.fragment.app.Fragment
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.activity_main.*
import vn.app.tcs.R
import vn.app.tcs.ui.actionreport.ActionReportFragment
import vn.app.tcs.ui.bank.list.BankListFragment
import vn.app.tcs.ui.home.MainActivity
import vn.app.tcs.ui.income.IncomeFragment
import vn.app.tcs.ui.managerhome.FragmentManagerHome
import vn.app.tcs.ui.notify.NotifyFragment
import vn.app.tcs.ui.report.list.ListReportFragment
import vn.app.tcs.ui.stafflist.StaffListFragment

class MainOwnerActivity : MainActivity() {

    override fun getDefaultFragmentTag(): String {
        return IncomeFragment.TAG
    }

    override fun getNavigationMenu(): Int {
        return R.menu.drawer_items
    }

    override fun getDefaultFragment(): Fragment {
        toolbarTitle.text = getString(R.string.singer_manager)
        return IncomeFragment.newInstance()
    }


    override fun setUpObserver() {
        super.setUpObserver()
        addDisposable(RxEvent.ShowSingerList::class.java) {
            setNavigationOnClick(R.id.navStaffList)
        }
    }
    override fun openDefaultFragment() {
        toolbarTitle.text = getString(R.string.singer_manager)
        showManagementFragment(IncomeFragment.newInstance(), IncomeFragment.TAG)
    }

    override fun setNavigationOnClick(menuItemId: Int) {
        when (menuItemId) {
            R.id.navPayment -> {
                toolbarTitle.text = getString(R.string.singer_manager)
                showManagementFragment(IncomeFragment.newInstance(), IncomeFragment.TAG)
            }
//            R.id.navBank -> {
//                toolbarTitle.text = "Tài khoản ngân hàng"
//                showManagementFragment(BankListFragment.newInstance(), BankListFragment.TAG)
//            }
            R.id.navStaffList -> {
                toolbarTitle.text = getString(R.string.singer_list)
                showManagementFragment(StaffListFragment.newInstance(), StaffListFragment.TAG)
            }
            R.id.sysAlert -> {
                toolbarTitle.text = getString(R.string.notification_list)
                showManagementFragment(NotifyFragment.newInstance(), NotifyFragment.TAG)
            }
            R.id.sysReport -> {
                toolbarTitle.text = getString(R.string.action_list)
                showManagementFragment(ActionReportFragment.newInstance(), ActionReportFragment.TAG)
            }
            R.id.navReportList -> {
                toolbarTitle.text = getString(R.string.handle_request)
                showManagementFragment(ListReportFragment.newInstance(), ListReportFragment.TAG)
            }
        }
    }

}