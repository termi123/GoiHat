package vn.app.tcs.ui.profile.adapter

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel
import vn.app.tcs.base.BaseItemViewModel
import vn.app.tcs.data.model.WrapperImageStaff

abstract class ImageStaffItemBaseViewModel<T : BaseViewModel> : BaseItemViewModel<T>() {
    var staffImage = MutableLiveData<WrapperImageStaff>()
}