package vn.app.tcs.data.remote

import io.reactivex.Single
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import vn.app.tcs.data.model.CheckVersionResponse
import vn.app.tcs.data.model.UserProfile
import vn.app.tcs.data.request.ChangePassRequest
import vn.app.tcs.data.request.TokenRequest
import vn.app.tcs.data.request.UserLogInRequest

interface AuthenticateSource {

    @POST("/api/login")
    fun login(@Body userLogInRequest: UserLogInRequest): Single<UserProfile>

    @POST("/api/logout")
    fun logOut(): Single<ArrayList<String>>

    @POST("/api/user/update-firebase-token")
    fun updateToken(@Body tokenRequest: TokenRequest): Single<ArrayList<String>>

    @POST("/api/user/change-password")
    fun changePassword(@Body changePassRequest: ChangePassRequest): Single<ArrayList<String>>

    @POST("/api/check-version-new")
    fun checkVersion(@Query("version") version: String, @Query("type") type: String): Single<CheckVersionResponse>
}