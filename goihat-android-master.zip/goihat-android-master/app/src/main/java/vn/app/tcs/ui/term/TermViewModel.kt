package vn.app.tcs.ui.term

import androidx.lifecycle.MutableLiveData
import com.base.common.base.viewmodel.BaseViewModel

class TermViewModel : BaseViewModel() {
    val url = MutableLiveData<String>()

    init {
        url.value = "http://karaapp.kiaisoft.com/terms"
    }
}