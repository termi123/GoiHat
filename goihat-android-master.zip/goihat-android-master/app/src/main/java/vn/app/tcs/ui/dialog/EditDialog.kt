package vn.app.tcs.ui.dialog

import android.os.Bundle
import android.view.View
import androidx.databinding.Observable
import com.base.common.base.dialog.BaseDialog
import com.base.common.data.event.MessageDialog
import com.base.common.utils.rx.bus.RxBus
import com.base.common.utils.rx.bus.RxEvent
import kotlinx.android.synthetic.main.edit_dialog.*
import org.koin.android.ext.android.inject
import vn.app.tcs.R
import vn.app.tcs.data.karaconstant.EventConstant
import vn.app.tcs.databinding.EditDialogBinding

class EditDialog : BaseDialog<EditDialogBinding, EditDialogViewModel>() {
    override val viewModel: EditDialogViewModel by inject()
    override val layoutId: Int
        get() = R.layout.edit_dialog

    override fun updateUI(savedInstanceState: Bundle?) {

    }

    override fun onReceiverMessage(sender: Observable?, propertyId: Int) {
        when (propertyId) {
            EventConstant.EVENT_EDIT_DIALOG -> {
                dismiss()
                RxBus.publish(
                    RxEvent.EventDialog(
                        viewModel.content.value?.tag,
                        if (tvContent.text.isNullOrBlank()) "" else tvContent.text.toString()
                    )
                )
            }
            EventConstant.EVENT_DISMISS -> {
                dismissAllowingStateLoss()
            }
        }
    }

    companion object {
        fun newInstance(messageDialog: MessageDialog) = EditDialog().apply {
            viewModel.content.value = messageDialog
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


}
